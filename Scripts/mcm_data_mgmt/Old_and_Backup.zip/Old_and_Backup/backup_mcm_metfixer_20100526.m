function [] = mcm_metfixer(year, site)
%% mcm_metfixer.m
%%% This function is designed to be run on data after being processed with
%%% mcm_metclean.  Currently, this function should be used only on data
%%% collected in 2008 or later.  This function gives the user a chance to
%%% make final, manual adjustments to the data, that may not be fixable
%%% with a simple threshold.
%%% Variables are loaded from /Cleaned3/ and saved in /Final_Cleaned/
%%% Usage: mcm_metfixer(year, site), where year is a number and site a
%%% string

% Created Mar 11, 2009 by JJB
% Revision History:
% Mar 12, 2009 - changed variables input_data and output to be the same
% size as the entire list of variables -- whether 30 min variables or not.
% This preserves the numbering of the columns of variables to be consistent


close all;
if ischar(year) == 1;
    year = str2num(year);
end
yr_str = num2str(year);

loadstart = addpath_loadstart;
%%% Header Path
hdr_path = [loadstart 'Matlab/Data/Met/Raw1/Docs/'];
%%% Load Path
load_path = [loadstart 'Matlab/Data/Met/Cleaned3/' site '/'];%[loadstart 'Matlab/Data/Met/Cleaned3/' site '/Column/30min/' site '_' year '.'];
%%% Save Path
output_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/' site '/'];

header = jjb_hdr_read([hdr_path site '_OutputTemplate.csv'], ',', 3);
%%% Take information from columns of the header file
%%% Column vector number
col_num = str2num(char(header(:,1)));
%%% Title of variable
var_names = char(header(:,2));
%%% Minute intervals
header_min = str2num(char(header(:,3)));
%%% Use minute intervals to find 30-min variables only
vars30 = find(header_min == 30);
%%% Create list of extensions needed to load all of these files
vars30_ext = create_label(col_num(vars30),3);
%%% Create list of titles that are 30-minute variables:
% names30 = var_names(vars30,:);
names30 = header(vars30,2);

names30_str = char(names30);
if isleapyear(year) == 1;
    len_yr = 17568;
else
    len_yr = 17520;
end

input_data = NaN.*ones(len_yr,length(vars30)); % will be filled by loaded variables
output = input_data;                           % will be final cleaned variables

% Column numbers, names and string of names for the final variables:
output_cols = (1:1:length(vars30))';
output_names = names30;
output_names_str = char(output_names);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 1: Cycle through all variables so the investigator can look at the
%%% data closely

j = 1;

resp3 = input('do you want to scroll through variables before fixing? <y/n> ', 's');
if strcmpi(resp3,'y') == 1
    scrollflag = 1;
else
    scrollflag = 0;
end

while j <= length(vars30)
    try
        temp_var = load([load_path site '_' yr_str '.' vars30_ext(j,:)]);
    catch
        temp_var = NaN.*ones(len_yr,1);
        disp(['unable to locate variable: ' var_names(vars30(j),:)]);
    end
    
    input_data(:,j) = temp_var;
    output(:,j) = temp_var;
    
    switch scrollflag
        case 1
            figure(1)
            clf;
            plot(temp_var);
            %     hold on;
            title([var_names(vars30(j),:) ', column no: ' num2str(j)]);
            grid on;
            
            
            %% Gives the user a chance to change the thresholds
            response = input('Press enter to move forward, enter "1" to move backward: ', 's');
            
            if isempty(response)==1
                j = j+1;
                
            elseif strcmp(response,'1')==1 && j > 1;
                j = j-1;
            else
                j = 1;
            end
        case 0
            j = j+1;
    end
    
end
clear j response accept
figure(1);
text(0,0,'Make changes in program now (if necessary) -exit script')
%%% Plot Soil Temperature and Moisture data from each pit to make sure that
%%% all data is in the right place:

% A. Soil Temperature:
%Check to see where soil temperature data starts:
Ts_cols_A = find(strncmpi(names30(:,1),'SoilTemp_A',10)==1);
Ts_cols_B = find(strncmpi(names30(:,1),'SoilTemp_B',10)==1);
TsA_labels = char(names30(Ts_cols_A,1));
TsB_labels = char(names30(Ts_cols_B,1));
clrs = colormap(lines(7));

figure(2);clf;
for i = 1:1:length(Ts_cols_A)
    subplot(2,1,1)
    hTsA(i) = plot(input_data(:,Ts_cols_A(i)),'Color',clrs(i,:)); hold on;
end
legend(hTsA,TsA_labels(:,12:end))
title('Pit A - Temperatures -- uncorrected')

for i = 1:1:length(Ts_cols_B)
    subplot(2,1,2)
    hTsB(i) = plot(input_data(:,Ts_cols_B(i)),'Color',clrs(i,:)); hold on;
end
legend(hTsB,TsB_labels(:,12:end))
title('Pit B - Temperatures -- uncorrected')


% B. Soil Moisture:
SM_cols_A = find(strncmpi(names30(:,1),'SM_A',4)==1);
SM_cols_B = find(strncmpi(names30(:,1),'SM_B',4)==1);
SMA_labels = char(names30(SM_cols_A,1));
SMB_labels = char(names30(SM_cols_B,1));

figure(3);clf;

for i = 1:1:length(SM_cols_A)
    subplot(2,1,1)
    hSMA(i) = plot(input_data(:,SM_cols_A(i)),'Color',clrs(i,:)); hold on;
end
legend(hSMA,SMA_labels(:,6:end))
title('Pit A - Moisture -- uncorrected')

for i = 1:1:length(SM_cols_B)
    subplot(2,1,2)
    hSMB(i) = plot(input_data(:,SM_cols_B(i)),'Color',clrs(i,:)); hold on;
end
legend(hSMB,SMB_labels(:,6:end))
title('Pit B - Moisture -- uncorrected')
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 2: Specific Cleans to the Data

switch site
    case 'TP39'
        % Corrections that always should be made:
        % 1: Set any negative PAR and nighttime PAR to zero:
        PAR_cols = [];
        PAR_cols = [PAR_cols; output_cols(strcmp(output_names,'DownPAR_AbvCnpy')==1)];
        PAR_cols = [PAR_cols; output_cols(strcmp(output_names,'UpPAR_AbvCnpy')==1)];
        PAR_cols = [PAR_cols; output_cols(strcmp(output_names,'DownPAR_BlwCnpy')==1)];
        %Plot uncorrected:
        figure(97);clf;
        subplot(211)
        plot(output(:,PAR_cols)); legend(output_names_str(PAR_cols,:))
        title('Uncorrected PAR');
        if year <= 2008
            [sunup_down] = annual_suntimes(site, year, -4);
        else
            [sunup_down] = annual_suntimes(site, year, 0);
        end
        ind_sundown = find(sunup_down< 1);
        figure(55);clf;
        plot(output(:,PAR_cols(1)))
        hold on;
        plot(ind_sundown,output(ind_sundown,PAR_cols(1)),'.','Color',[1 0 0])
        title('Check to make sure timing is right')
        output(output(:,PAR_cols(1)) < 10 & sunup_down < 1,PAR_cols(1)) = 0;
        output(output(:,PAR_cols(2)) < 5 & sunup_down < 1,PAR_cols(2)) = 0;
        output(output(:,PAR_cols(3)) < 10 & sunup_down < 1,PAR_cols(3)) = 0;
        output(output(:,PAR_cols(1)) < 0 , PAR_cols(1)) = 0;
        output(output(:,PAR_cols(2)) < 0 , PAR_cols(2)) = 0;
        output(output(:,PAR_cols(3)) < 0 , PAR_cols(3)) = 0;
               
        % Plot corrected data:
        figure(97);
        subplot(212);
        plot(output(:,PAR_cols)); legend(output_names_str(PAR_cols,:))
        title('Corrected PAR');
        
        % 2: Set any RH > 100 to NaN -- This is questionable whether to make
        % these values NaN or 100.  I am making the decision that in some
        % cases
        RH_cols = [];
        RH_cols = [RH_cols; output_cols(strcmp(output_names,'RelHum_AbvCnpy')==1)];
        RH_cols = [RH_cols; output_cols(strcmp(output_names,'RelHum_Cnpy')==1)];
        RH_cols = [RH_cols; output_cols(strcmp(output_names,'RelHum_BlwCnpy')==1)];
        % Adjust columns to match output:
        %     RH_cols = RH_cols - 6;
        figure(98);clf;
        subplot(211)
        plot(output(:,RH_cols)); legend(output_names_str(RH_cols,:))
        title('Uncorrected RH')
        RH_resp = input('Enter value to set RH > 100 to? (100 or NaN): ');
        for j = 1:1:length(RH_cols)
            output(output(:,RH_cols(j)) > 100,RH_cols(j)) = RH_resp;
        end
        subplot(212);
        plot(output(:,RH_cols)); legend(output_names_str(RH_cols,:))
        title('Corrected RH');
        
        switch yr_str
            %             case '2002'
            %             case '2003'
            %             case '2004'
            %             case '2005'
            %             case '2006'
            case '2007'
                %                 %% Corrects for inverted Net Radiation for a period of time
                %                 %% in the data -- due to backwards wiring of sensor into
                %                 %% datalogger.
                %                 %% use the mean of one day during the period to make sure
                %                 %% the data hasn't already been flipped once (mean of the
                %                 %% day is -24.707)
                if mean(input_data(6015:6063,18)) < 0
                    output(459:7842,1) = -1.*output(459:7842,1);
                end
                % clean Ta14m&Ta2m for bad data
                output(2758:2812,2:3) = NaN;
                % Clean bad data in blw_cnpy PAR:
                
                output(694:763,output_cols(strcmp(output_names,'DownPAR_BlwCnpy')==1)) = NaN;
                % Clean bad data in canopy and blw_cnpy CO2:
                bad_CO2_cpy = [2339:2340 3629 4306 5737 7659 14478 17372:17377]';
                output(bad_CO2_cpy, output_cols(strcmp(output_names,'CO2_Cnpy')==1)) = NaN;
                bad_CO2_blw = [4305 4724 5203 5258 5737 13126 16017 16922 17372:17377]';
                output(bad_CO2_blw, output_cols(strcmp(output_names,'CO2_BlwCnpy')==1)) = NaN;
                % Clean bad HFT data:
                bad_HFT2 = [7647:7658]';
                output(bad_HFT2, output_cols(strcmp(output_names,'SoilHeatFlux_HFT_2')==1)) = NaN;
                % Clean bad soil data:
                bad_soil_data = [694:763 7626:1:7658]';
                bad_soil_cols = [79:100]';
                output(bad_soil_data, bad_soil_cols) = NaN;
                % SM 100 B probe -- before it was installed properly.
                output(1:8200,output_cols(strcmp(output_names,'SM_B_100cm')==1)) = NaN;
                
            case '2008'
                % Fix CO2_cpy offset during late 2008 (if hasn't already been done)
                right_col = quick_find_col( names30, 'CO2_BlwCnpy');
                if output(15821,right_col) - output(15822,right_col) > 20
                    output(15822:17568,right_col) = output(15822:17568,right_col)+33;
                elseif output(15821,right_col) - output(15822,right_col) < 20
                    output(15822:17568,right_col) = output(15822:17568,right_col)-33;
                end
                clear right_col;
                % Fix SnowDepth -- remove a bad point:
                right_col = quick_find_col( names30, 'SnowDepth');
                output(9664,right_col) = output(9663,right_col); clear right_col;
                % Fix Problems with Atm. Pres sensor for a couple periods:
                right_col = quick_find_col( names30, 'Pressure');
                output(12380:13120,right_col) = NaN;
                output(13980:14480,right_col) = NaN; clear right_col;
                
                % Shift data so that it's all in UTC:
                % need to load last 8 datapoints from 2007
                for i = 1:1:length(vars30)
                    temp_var = load([load_path site '_2007.' vars30_ext(i,:)]);
                    fill_data(1:8,i) = temp_var(end-7:end);
                    clear temp_var;
                end
                output_test = [fill_data(:,:); output(1:end-8,:)];
                clear fill_data;
                clear output;
                output = output_test;
                clear output_test;
                
            case '2009'
                
                % Bad CO2_cnpy data:
                output(8940:12240,71) = NaN; % broken
                output(12241:12762,71) = output(12241:12762,71) + 236; % bad offset
                
                % Bad Snow Depth Data:
                output(9000:13000,31) = 0;
                
                % Bad SMA20cm data:
                bad_pts = [11688 12458 12613 12650:12661 13234:13251 13662 ...
                    13725:13752 13866 13915:13982 14053 14056 14101]';
                output(bad_pts,93) = NaN;
                clear bad_pts;
                
                
                % Shift data so that it's all in UTC:
                % need to load last 8 datapoints from 2008
                
                for i = 1:1:length(vars30)
                    temp_var = load([load_path site '_2008.' vars30_ext(i,:)]);
                    fill_data(1:8,i) = temp_var(end-7:end);
                    clear temp_var;
                end
                output_test = [fill_data(:,:); output(1:704,:); output(713:end,:)];
                clear fill_data;
                clear output;
                output = output_test;
                clear output_test;
                
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TP74
    case 'TP74'
        switch yr_str
            
            %             case '2007'
            
            case '2008'
                % Fix change in windspeed that results from moving wind
                % sensor to new tower halfway through season -- we'll use the windspeed
                % values from the CPEC system to fill in first half of
                % season:
                u = load([loadstart 'Matlab/Data/Flux/CPEC/TP74/Final_Cleaned/TP74_2008.u']);
                v = load([loadstart 'Matlab/Data/Flux/CPEC/TP74/Final_Cleaned/TP74_2008.v']);
                WS_CPEC = sqrt(u.^2 + v.^2);
                
                output(1:10450,4) = NaN;
                output(isnan(output(:,4)),4) = WS_CPEC(isnan(output(:,4)),1);
                clear u v WS_CPEC;
                
                
                % Remove Spike from SM data:
                output(11077:11080,12:32) = NaN;
                output(12570:12571,12:32) = NaN;
                output(9732:9733,12) = NaN;
                output(13129:13130,12) = NaN;
                output(1:10444,24) = NaN; % 80-100cm sensor doesn't work for first part of year.
                % Remove Spikes from SHF Data:
                output(1:10452,11) = NaN;
                % Remove Spikes from Ts Data (there are a lot of them):
                %                 ctr2 = 1;
                for col = 12:1:23
                    try
                        tracker = load([loadstart 'Matlab/Scripts/Met/trackers/TP74_2008_tr.0' num2str(col)]);
                        disp(['loading tracker for column ' num2str(col) '. ']);
                        
                        resp = input('Do you want to continue to edit the tracker? (<y> to edit, <n> to skip: ', 's');
                        
                        if strcmp(resp,'y') == 1;
                            output(:,col) = output(:,col).*tracker;
                            clear tracker
                            
                            [tracker] = jjb_remove_data(output(:,col));
                            
                            save([loadstart 'Matlab/Scripts/Met/trackers/TP74_2008_tr.0' num2str(col)],'tracker','-ASCII')
                        else
                        end
                        
                    catch
                        [tracker] = jjb_remove_data(output(:,col));
                        save([loadstart 'Matlab/Scripts/Met/trackers/TP74_2008_tr.0' num2str(col)],'tracker','-ASCII')
                        
                    end
                    
                    output(:,col) = output(:,col).*tracker ;
                    clear tracker
                    %                    ctr2 = ctr2+1;
                end
                
                % Remove bad HMP RH Data during 2008
                right_col = quick_find_col( names30, 'RelHum_AbvCnpy');
                output(11363:12475,right_col) = NaN; clear right_col;
                
                % Remove bad HMP Ta Data during 2008
                right_col = quick_find_col( names30, 'AirTemp_AbvCnpy');
                output(11363:12475,right_col) = NaN; clear right_col;
                
                % Shift data so that it's all in UTC:
                % need to load last 8 datapoints from 2007
                for i = 1:1:length(vars30)
                    try
                        temp_var = load([load_path site '_2007.' vars30_ext(i,:)]);
                    catch
                        disp(['could not load the 2007 variable: ' names30_str(i,:)]);
                        disp(['Check if column should exist -- making NaNs']);
                        
                        temp_var = NaN.*ones(len_yr,1);
                    end
                    
                    fill_data(1:8,i) = temp_var(end-7:end);
                    clear temp_var;
                end
                output_test = [fill_data(:,:); output(1:747,:); output(756:end,:)];
                clear fill_data;
                clear output;
                output = output_test;
                clear output_test;
                %%% Cycle through variables
                %                 for i = 1:1:length(vars30)
                %                     temp_var = load([load_path site '_2008.' vars30_ext(i,:)]);
                %                     fill_data(1:8,i) = temp_var(end-7:end);
                %                     clear temp_var;
                %                 end
                
                %                 for i = 1:1:length(vars30)
                %                     [spike_tracker] = jjb_find_spike(output(:,i), 2);
                %                 end
                
            case '2009'
                % Remove spikes in soil data:
                output(6128:8494,1:2) = NaN;
                output(2004,12) = NaN;
                bad_data = [10741:10981 12759 12765];
                output(bad_data,12:32) = NaN;
                output([10134;10135; 10217],29) = NaN;
                
        end
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TP89
    case 'TP89'
        switch yr_str
            case '2008'
                % Adjust nighttime PAR to fix offset:
                output(output(:,6) < 8,6) = 0;
                % Adjust RH to be 100 when it is >100
                output(output(:,2) > 100,2) = 100;
                
                % Shift data so that it's all in UTC:
                % need to load last 8 datapoints from 2007
                for i = 1:1:length(vars30)
                    temp_var = load([load_path site '_2007.' vars30_ext(i,:)]);
                    fill_data(1:8,i) = temp_var(end-7:end);
                    clear temp_var;
                end
                output_test = [fill_data(:,:); output(1:end-8,:)];
                clear fill_data;
                clear output;
                output = output_test;
                clear output_test;
                
                
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TP02
    case 'TP02'
        switch yr_str
            case '2008'
                
                % step 1 - remove bad data:
                output(3037:7181,1:2) = NaN; %broken HMP caused problems for HMP, Wind
                output(4753:7181,3:4) = NaN; %broken HMP caused problems for HMP, Wind
                % PAR up and down sensors backwards for short period
                temp = output(4446:4752,5);
                output(4446:4752,5) = output(4446:4752,6);
                output(4446:4752,6) = temp;
                clear temp
                
                % Remove spikes in soil variables:
                %Ts
                output([966:1:990 3357 11056 11060 11062 11063 11295],11) = NaN;
                output([966:1:990 3357 4057 5899 7181 10782],12) = NaN;
                output([966:1:990 3357 11274],13) = NaN;
                output([966:1:990 3357],16) = NaN;
                output([966:1:990 5899],17) = NaN;
                output([966:1:990 3357 11345],18) = NaN;
                output([966:1:990 3346 11345],20) = NaN;
                output([966:1:990 11295 11345 12020],21) = NaN;
                output([966:1:990 11191 11249 11297 11345],22) = NaN;
                %SM
                output([966:1:990 11191 11295 11329 12068],23) = NaN;
                output([966:1:990 6015 5903 5904 11345 11191 11295 12008],25) = NaN;
                output([966:1:990 5899 5900 5903 5904 5936:5939 6015 11191 11295 11345 11590 12008 12020 12068],26) = NaN;
                output([966:1:990 3361 5899 5900 5903 5904 11191 11345 11590 12008 12020 12068],27) = NaN;
                output([966:1:990 5903 5904 5935:5939 6015 11590 12008],28) = NaN;
                output([966:1:990 11191 12018 12068],29) = NaN;
                output([966:1:990 11590 12008],30) = NaN;
                output([966:1:990 4286 11191 11295],31) = NaN;
                
                
                % step 2 - re-arrange soil variables:
                SM80B = output(:,31); SM50B = output(:,27); SM20B = output(:,28);
                SM10B = output(:,29); SM5B = output(:,30);
                output(:,27) = SM80B; output(:,28) = SM50B; output(:,29) = SM20B;
                output(:,30) = SM10B; output(:,31) = SM5B;
                
                clear SM80B SM50B SM20B SM10B SM5B;
                
                SM5A = output(:,25); SM10A = output(:,26);
                output(:,25) = SM10A; output(:,26) = SM5A;
                clear SM5A SM10A;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %   Step 3
                % Shift data so that it's all in UTC:
                % need to load first 8 datapoint from 2007
                for i = 1:1:length(vars30)
                    try
                        temp_var = load([load_path site '_2007.' vars30_ext(i,:)]);
                    catch
                        temp_var = NaN.*ones(17520,1);
                    end
                    fill_data(1:8,i) = temp_var(end-7:end);
                    clear temp_var;
                end
                output_test = [fill_data(:,:); output(1:6319,:); NaN.*ones(2,length(vars30)); output(6320:7178,:); output(7181:11713,:); output(11744:12068,:); NaN.*ones(22,length(vars30)); output(12069:end,:)];
                clear fill_data;
                clear output;
                output = output_test;
                clear output_test;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case '2009'
                % Bad Data in HMP:
                output(4906:5650,1:2) = NaN;
                % Bad data in other variables:
                output(4906:5115,5:10) = NaN;
                
                bad_pts = [5116 10755 10984]';
                output(bad_pts, 11:31) = NaN;
                clear bad_pts;
                output(14477,23:31) = NaN;
                
                % Clean up spikes in soil data:
                %                 output(
                % run [tracker] = jjb_remove_data(output(:,col)); on
                % columns 11--22
                % spot clean 23--31.
                for col = 11:1:22
                    try
                        tracker = load([loadstart 'Matlab/Scripts/Met/trackers/TP02_2009_tr.0' num2str(col)]);
                        disp(['loading tracker for column ' num2str(col) '. ']);
                        
                        resp = input('Do you want to continue to edit the tracker? (<y> to edit, <n> to skip: ', 's');
                        
                        if strcmp(resp,'y') == 1;
                            output(:,col) = output(:,col).*tracker;
                            clear tracker
                            
                            [tracker] = jjb_remove_data(output(:,col));
                            
                            save([loadstart 'Matlab/Scripts/Met/trackers/TP02_2009_tr.0' num2str(col)],'tracker','-ASCII')
                        else
                        end
                        
                    catch
                        disp('cannot find tracker -- making a new one');
                        [tracker] = jjb_remove_data(output(:,col));
                        save([loadstart 'Matlab/Scripts/Met/trackers/TP02_2009_tr.0' num2str(col)],'tracker','-ASCII')
                        
                    end
                    
                    output(:,col) = output(:,col).*tracker ;
                    clear tracker
                    %                    ctr2 = ctr2+1;
                end
                
                % Step 4: fill gaps in data with available data from the
                % OPEC system:
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% WORKING
                Ta_temp = load([loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/TP02/Column/TP02_HHdata_2008.069']);
                Ta = [NaN.*ones(11,1); Ta_temp(1:end-11,1)];%Ta_temp(1:10778,1); NaN.*ones(5,1); Ta_temp(10779:length(Ta_temp)-8,1)];
                Ta(5800:5805,1) = NaN;
                %                 Ta(1:5796,1) = NaN;
                WS_temp = load([loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/TP02/Column/TP02_HHdata_2008.046']);
                WS = [NaN.*ones(11,1); WS_temp(1:end-11,1)];
                %                 WS = [WS_temp(1:10781,1); NaN.*ones(8,1); WS_temp(10782:length(Ta_temp)-8,1)];
                % rWS = load([loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/TP02/Column/TP02_HHdata_2008.047']);
                Wdir_temp = load([loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/TP02/Column/TP02_HHdata_2008.044']);
                Wdir = [NaN.*ones(11,1); Wdir_temp(1:end-11,1)];
                %                 Wdir = [Wdir_temp(1:10781,1); NaN.*ones(8,1); Wdir_temp(10782:length(Ta_temp)-8,1)];
                
                %%% Fill in blanks:
                output(isnan(output(:,1)),1) = Ta(isnan(output(:,1)),1);
                output(isnan(output(:,3)),3) = WS(isnan(output(:,3)),1);
                %                 output(isnan(output(:,4)),4) = Wdir(isnan(output(:,4)),1);
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % figure(88);clf;
                % plot(output(:,1),'b.-'); hold on;
                % plot(Ta,'r.-');
                %
                % figure(89);clf;
                % plot(output(:,3),'b.-'); hold on;
                % plot(WS,'r.-');
                %
                % figure(90);clf;
                % plot(output(:,4),'b.-'); hold on;
                % plot(Wdir,'r.-');
                
                
                
                % figure(22);clf
                % f = ~isnan(output(:,1).*Ta);
                % plot(Ta(f),output(f,1),'b.');
                % [p s] = polyfit(Ta(f,1),output(f,1),1);
                % rs = rsquared(Ta(f,1),output(f,1));
                %
                %  figure(23);clf
                % f = ~isnan(output(:,3).*WS);
                % plot(WS(f),output(f,3),'b.');
                % [p s] = polyfit(WS(f,1),output(f,3),1);
                % rs = rsquared(WS(f,1),output(f,3));
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                
                %             case '2007'
        end
end

%% Plot corrected/non-corrected data to make sure it looks right:
figure(4);
j = 1;
while j <= length(vars30)
    figure(4);clf;
    plot(input_data(:,j),'r'); hold on;
    plot(output(:,j),'b');
    grid on;
    %     title(var_names(vars30(j),:));
    title([var_names(vars30(j),:) ', column no: ' num2str(j)]);
    
    legend('Original','Fixed (output)');
    %% Gives the user a chance to move through variables:
    response = input('Press enter to move forward, enter "1" to move backward: ', 's');
    
    if isempty(response)==1
        j = j+1;
        
    elseif strcmp(response,'1')==1 && j > 1;
        j = j-1;
    else
        j = 1;
    end
end
clear j response accept

%% Plot Soil variables for final inspection:
figure(5);clf;
for i = 1:1:length(Ts_cols_A)
    subplot(2,1,1)
    hTsA(i) = plot(output(:,Ts_cols_A(i)),'Color',clrs(i,:)); hold on;
end
legend(hTsA,TsA_labels(:,12:end))
title('Pit A - Temperatures -- Corrected')

for i = 1:1:length(Ts_cols_B)
    subplot(2,1,2)
    hTsB(i) = plot(output(:,Ts_cols_B(i)),'Color',clrs(i,:)); hold on;
end
legend(hTsB,TsB_labels(:,12:end))
title('Pit B - Temperatures -- Corrected')


% B. Soil Moisture:
figure(6);clf;

for i = 1:1:length(SM_cols_A)
    subplot(2,1,1)
    hSMA(i) = plot(output(:,SM_cols_A(i)),'Color',clrs(i,:)); hold on;
end
legend(hSMA,SMA_labels(:,6:end))
title('Pit A - Moisture -- Corrected')

for i = 1:1:length(SM_cols_B)
    subplot(2,1,2)
    hSMB(i) = plot(output(:,SM_cols_B(i)),'Color',clrs(i,:)); hold on;
end
legend(hSMB,SMB_labels(:,6:end))
title('Pit B - Moisture -- Corrected')

%% Output
% Here is the problem with outputting the data:  Right now, all data in
% /Final_Cleaned/ is saved with the extensions corresponding to the
% CCP_output program.  Alternatively, I think I am going to leave the output
% extensions the same as they are in /Organized2 and /Cleaned3, and then
% re-write the CCP_output script to work on 2008-> data in a different
% manner.
master(1).data = output;
master(1).labels = names30_str;
save([output_path site '_met_cleaned_' yr_str '.mat'], 'master');
clear master;


resp2 = input('Are you ready to print this data to /Final_Cleaned? <y/n> ','s');
if strcmpi(resp2,'n')==1
    disp('Variables not saved to /Final_Cleaned/.');
else
    for i = 1:1:length(vars30)
        temp_var = output(:,i);
        save([output_path site '_' yr_str '.' vars30_ext(i,:)], 'temp_var','-ASCII');
        
    end
    disp('Variables saved to /Final_Cleaned/.');
    
end
mcm_start_mgmt;
end
%subfunction
% Returns the appropriate column for a specified variable name
function [right_col] = quick_find_col(names30_in, var_name_in)

right_col = find(strncmpi(names30_in,var_name_in,length(var_name_in))==1);
end

