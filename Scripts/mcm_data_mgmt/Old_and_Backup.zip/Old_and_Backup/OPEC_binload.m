%function [] = read_OPECbin(year, site, input_data, input_hdr_file, output_template)
% clear test1
% cols = 10;
% file = 'C:\HOME\MATLAB\Data\Flux\OPEC\Raw1\Met4\Hfreq\2006\Ts061001_061008m4_bin1.dat';
% test1 = read_bin(loc, cols);
clear all
close all

filen = 'C:\HOME\MATLAB\Data\Flux\OPEC\Raw1\Met4\Hfreq\2006\Ts061001_061008m4_bin1.dat';
% filen = 'C:\HOME\MATLAB\Data\Flux\OPEC\Raw1\Met4\Hfreq\2006\Ts061001_061008m4.dat';
fid = fopen(filen);

for i = 1:5
  tline = fgetl(fid);
  star_junk = find(tline == ','); 
  cols = length(star_junk);

end
 temp = fread(fid,[11 100000], 'uint32');
 temp = temp';
% eofstat = 0;

while eofstat == 0;




end



fclose(fid)