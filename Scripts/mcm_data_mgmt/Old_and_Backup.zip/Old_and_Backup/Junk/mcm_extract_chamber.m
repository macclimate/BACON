function [] = mcm_extract_chamber(site, load_path)

if ispc == 1;
    start_path = 'C:/home/';
else
    start_path = '/media/Deskie/home/';
end

data_load_path = [load_path '/MET-DATA/data/'];
        data_save_path = [start_path 'Matlab/Data/Chamber/' site '/data/'];

        hhour_load_path = [load_path '/MET-DATA/hhour/'];
        hhour_save_path = [start_path 'Matlab/Data/Chamber/' site '/hhour/'];

        % Specify the proper path to move data to the "To_Burn Folder"
        slsh = find(load_path == '/'); tag = load_path(slsh(end)+1:end);
        burn_path = [start_path 'Matlab/Data/DUMP_Data/To_Burn/' site '_Chamber/' tag '/'];


        %%%% Examine for the presence of data and hhour files/folders to be
        %%%% downloaded in the target directory:
        dir_data_in = dir(data_load_path); % checks all files in the incoming data directory
        dir_hhour_in = dir(hhour_load_path); % checks all files in the incoming data directory

        data_status(1:2,1) = NaN;
        for j = 3:length(dir_data_in)
            % check if file/folder already exists
            data_status(j) = exist([data_save_path dir_data_in(j).name]);
        end

        data_to_move = length(find((data_status(3:j,1) ~= 2) & (data_status(3:j,1) ~= 7)));

        hhour_status(1:2,1) = NaN;
        for i = 3:length(dir_hhour_in)
            % check if file/folder already exists
            hhour_status(i) = exist([hhour_save_path dir_hhour_in(i).name]);
        end

        hhour_to_move = length(find(hhour_status(3:i,1) ~= 2 & hhour_status(3:i,1) ~= 7));

        %%%% Now, move through the data, copying the necessary files:

        data_move_count = 0;
        for j = 3:length(dir_data_in)
            if data_status(j) == 2 || data_status(j) == 7
            else
                data_move_count = data_move_count + 1;
                disp(['now copying file/folder ' num2str(data_move_count) ' of ' num2str(data_to_move)])
                copyfile([data_load_path dir_data_in(j).name],[data_save_path dir_data_in(j).name])
            end
        end

        hhour_move_count = 0;
        for i = 3:length(dir_hhour_in)
            if hhour_status(i) == 2 || hhour_status(i) == 7
            else
                hhour_move_count = hhour_move_count + 1;
                disp(['now copying file/folder ' num2str(hhour_move_count) ' of ' num2str(hhour_to_move)])
                copyfile([hhour_load_path dir_hhour_in(i).name],[hhour_save_path dir_hhour_in(i).name])

            end
        end

        % Include a line in here to extract the approriate .ini files from
        % data and will have to write some code to save it with specific
        % stamp -- perhaps using the last date in the data/hhour files read
        % by program?

        % Final Step - move the copied data into the "To_Burn" Folder
        if exist(burn_path)==7
            disp('folder already exists in the "To_Burn" folder')
            resp = input('Enter <e> to exit or enter to continue',s);
            if strcmp(resp,'e')==1
                finish
            else
            end
        else
            mkdir(burn_path)
        end
        disp('Now moving folder to the "To_Burn" directory -- This may take a few minutes')
        movefile(load_path, burn_path);
        %  unix/dos commands for moving (operates outside of MATLAB)
        %%% can be used instead of 'movefile' command.
        
        %%%%% UNCOMMENT THIS AND COMMENT'movefile' for external function:
        % if ispc ==1
        % dos(['MOVE [/-Y] ',load_path, burn_path]);
        % else
        % unix(['mv [-i] ',load_path ' ', burn_path]) 
        % end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%