function [] = mcm_weekly_calc_fluxes()
to_process =    {'TP39','CPEC'; ...
                'TP74','CPEC'; ...
                'TP02','CPEC'; ...
                'TP39','chamber'};
        
            date_start =  datestr(floor(now) - 30,'yyyy,mm,dd');
            date_end = datestr(floor(now), 'yyyy,mm,dd');
            dates = {date_start; date_end};
            
for i = 1:1:size(to_process,1)
    mcm_calc_fluxes(to_process{i,1},to_process{i,2},dates);
end            
exit;

%%% This command will be run automatically once a month:
% matlab -r mcm_monthly_calc_fluxes -nodesktop -nosplash
