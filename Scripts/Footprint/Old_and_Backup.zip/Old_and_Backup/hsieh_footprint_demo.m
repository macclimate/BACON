%View_footprint_demo.m: Illustrates the use of the footprint model by Hsieh et al. (2000)
%                                     
%
%Authors:           Gaby Katul and Cheng-I Hsieh
%
%Reference:         Hsieh, C.I., G.G. Katul, and T.W. Chi, 2000,  
%                   "An approximate analytical model for footprint estimation of scalar fluxes 
%                   in thermally stratified atmospheric flows", 
%                   Advances in Water Resources, 23, 765-772.
%
%
%Input Variables:
%----------------
%h     = Canopy height (m)
%zm    = Measurement height above the zero-plane displacement (m)
%zo    = Momentum roughness height (m)
% "sample.dat": Ascii input file that has 6 columns:
%               DOY, Time, ustar, Ta, H, Rn,WD
%
%where:
%DOY & Time = Day of year, Time of day
%ustar      = friction velocity (m/s)
%H          = Sensible heat (W/m2)
%Ta         = Mean air temperature (oC)
%WD         = Wind direction (compass N)
%
%Output:
%-------
%Fc = Cumulative source contribution with distance (fraction) - vector for each run
%fp = Source-weight function (with distance) - vector for each run
%L  = Obukhov length (m)
%xp = Peak distance from measuring point to the maximum contributing source area (m)
%x  = Distance vector used in the computation of Fc, fp (m)
%F2H=Fetch to Height ratio (for 90% of flux recovery, i.e. 100:1 or 20:1)
%
%---------------------------------------------------------------------------------------------------------
ls = addpath_loadstart;
path = [ls 'Matlab/Scripts/Footprint/'];
%cd c:\work\afluxres\footprint_model\grass_2001

%------------------- Set canopy height and measurement height
h=0.5;
d=0.67*h;
zo=0.1*h;
zm=3.8-d;
%------------------- Loads the data from the file sample.dat
YY=load ([path 'hsieh_footprint_sample.dat']);
DOYm=YY(:,1);
Timem=YY(:,2);
ustarm=YY(:,3);
Tam=YY(:,4);
Hsm=YY(:,5);
Rnm=YY(:,6);
WDm=YY(:,7);
M=length(Hsm);

for i=1:M
     ustar1=ustarm(i);
     H1=Hsm(i);
     Ta1=Tam(i);
     %--------------- MATLAB FUNCTION TO COMPUTE FOOTPRINT
     [Fc, Fp, x,L,xp,F2H]=footprint_hsieh(ustar1,H1,Ta1,zm,zo);
     FETCH(i)=[(F2H*zm)];
     STAB(i)=[zm/(L)];
 end
FETCH=FETCH';
STAB=STAB';

%------------------- Plot the footprint distribution for unstable and stable atmospheric conditions
figure(1)

subplot (1,2,1)
WD1=[];
FETCH1=[];
WD1=WDm(STAB>0 & FETCH<5000);
FETCH1=FETCH(STAB>0 & FETCH<5000);
polar (WD1, FETCH1,'.')
title ('Fetch for Stable Conditions')

subplot (1,2,2)
WD1=[];
FETCH1=[];
WD1=WDm(STAB<-0.04);
FETCH1=FETCH(STAB<-0.04);
polar (WD1, FETCH1,'.')
title ('Fetch for Unstable Conditions')

