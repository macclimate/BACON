function [adj_master_file, adj_output_titles] =  metfix(orig_master_file,orig_output_titles , site, year, row_list)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% This script is designed to allow fixes to data where the changes need
%%% to be made in the middle of a year (changes that are too complicated to
%%% include in the metload program).

year_list(:,1) = make_tv(str2num(year),5);
year_list(:,2) = (1:1:105120);


%%%%%%%%%%%%%%%%%%%%%%% FIXES FOR MET 1 %%%%%%%%%%%%%%%%%%%%%
if strcmp(site,'1') == true;

if strcmp(year,'2007') == true;

    
     %%%%%%%%%%%%%%%% Corrects for insertion of CS Rain Guage into the program
 %%%%%%%%%%%%%%%% around hhour 8800
 ind_row1 = find(year_list == JJB_DL2Datenum(2007,191,1430));
 change_row1 = year_list(ind_row1,2); % convert that time to data point for the whole year

ind_time_before1 = find(row_list <= change_row1);
time_before1 = row_list(ind_time_before1);

% ind_time_after1 = find(row_list >= change_row1);
% time_after1 = row_list(ind_time_after1);
% 
% % Fix before rain guage was put in....
% %  orig_master_file(time_before1,39:110) = orig_master_file(time_before1,38:109);
orig_master_file(time_before1,38) = NaN;
 
    %%%%%%%%%%%%%%%%%
    %% Corrects for Mislabeled soil moisture sensors in Pit B, occurring
    %% both before and after re-wiring on JD 67 HHMM 1330
    
    ind_row2 = find(year_list(:,1) == JJB_DL2Datenum(2007,76,1330));  % find number entry in uploaded file where change occurs
    change_row2 = year_list(ind_row2,2); % convert that time to data point for the whole year
    

ind_time_before2 = find(row_list <= change_row2);
time_before2 = row_list(ind_time_before2);

ind_time_after2 = find(row_list >= change_row2);
time_after2 = row_list(ind_time_after2);

    %%% Correct mislabeling before re-wiring
    
    temp_M5b_b4 = orig_master_file(time_before2,106);
    temp_M10b_b4 = orig_master_file(time_before2,104);
    temp_M20b_b4 = orig_master_file(time_before2,107);
    temp_M50b_b4 = orig_master_file(time_before2,105);
    temp_M100b_b4 = orig_master_file(time_before2,108);
    
    orig_master_file(time_before2,104) = temp_M5b_b4;
    orig_master_file(time_before2,105) = temp_M10b_b4;
    orig_master_file(time_before2,106) = temp_M20b_b4;
    orig_master_file(time_before2,107) = temp_M50b_b4;
    orig_master_file(time_before2,108) = temp_M100b_b4;
    
    
    %%% Correct mislabeling after re-wiring
    temp_M5b = orig_master_file(time_after2,107);
    temp_M10b = orig_master_file(time_after2,105);
    temp_M20b = orig_master_file(time_after2,104);
    temp_M50b = orig_master_file(time_after2,106);
    temp_M100b = orig_master_file(time_after2,108);
    
    orig_master_file(time_after2,104) = temp_M5b;
    orig_master_file(time_after2,105) = temp_M10b;
    orig_master_file(time_after2,106) = temp_M20b;
    orig_master_file(time_after2,107) = temp_M50b;
    orig_master_file(time_after2,108) = temp_M100b;
    
clear ind_time

 adj_master_file = orig_master_file;
 adj_output_titles = orig_output_titles;
 
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% FIXES FOR MET 2 %%%%%%%%%%%%%%%%%%%%%
% if strcmp(site,'2') == true;
% 
% if strcmp(year,'2007') == true;
% 
% 
% 
% 
% 
% 
% end
% end



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%% FIXES FOR MET 4 %%%%%%%%%%%%%%%%%%%%%
% elseif strcmp(site,'4') == true;
% 
% if strcmp(year,'2007') == true;
%     %%%%%%%%%%%%%%%%%
%     %% Corrects for the inclusion of M80-100b in the middle of the year,
%     %% which shifted data over one place -- shifts the data back, and moves
%     %% M80-100b to the end.
%     %% July 12, 2007 by JJB
%     
%     TV_index = JJB_DL2Datenum(orig_master_file(:,2),orig_master_file(:,3), orig_master_file(:,4));
%     
%     ind_time = find(TV_index == JJB_DL2Datenum(2007,163, 1500));
%     
%     temp_80 = orig_master_file(ind_time:length(orig_master_file),33);
%     
%     orig_master_file(ind_time:length(orig_master_file),33:36) = orig_master_file(ind_time:length(orig_master_file),34:37);
%     orig_master_file(ind_time:length(orig_master_file),37)= temp_80;
%     
%     temp_title_80 = orig_output_titles(33,1);
%     orig_output_titles(33:36,1) = orig_output_titles(34:37,1);
%     orig_output_titles(37,1) = temp_title_80;
%     clear ind_time
%     
% %%%%%%%%%%%%%%%%%%%%%%%% Corrects for improperly labelled TS Pit B sensors.
%     
%     ind_time2 = find(TV_index == JJB_DL2Datenum(2007,163, 1200));
%     
%     temp_Ts2b = orig_master_file(1:ind_time2,25);
%     temp_Ts5b = orig_master_file(1:ind_time2,23);
%     temp_Ts10b = orig_master_file(1:ind_time2,24);
%     temp_Ts20b = orig_master_file(1:ind_time2,27);
%     temp_Ts50b = orig_master_file(1:ind_time2,28);
%     temp_Ts100b = orig_master_file(1:ind_time2,26);
%     
%     orig_master_file(1:ind_time2,23) = temp_Ts100b;
%     orig_master_file(1:ind_time2,24) = temp_Ts50b;
%     orig_master_file(1:ind_time2,25) = temp_Ts20b;
%     orig_master_file(1:ind_time2,26) = temp_Ts10b;
%     orig_master_file(1:ind_time2,27) = temp_Ts5b;
%     orig_master_file(1:ind_time2,28) = temp_Ts2b;
% %%%%%%%%%%%%%%%%%%%%%%%
% clear ind_time2
% 
%     adj_master_file = orig_master_file;
%     adj_output_titles = orig_output_titles;
% end
% else 
%      adj_master_file = orig_master_file;
%     adj_output_titles = orig_output_titles;



    