par = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.015']);
length(find(isnan(par)))
Ta = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.007']);
length(find(isnan(Ta)))
RH = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.008']);
length(find(isnan(RH)))

Ts2a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.087']);
length(find(isnan(Ts2a)))
Ts5a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.091']);
length(find(isnan(Ts5a)))

Ts2b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.098']);
length(find(isnan(Ts2b)))
Ts5b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.097']);
length(find(isnan(Ts5b)))


SM5a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.099']);
SM5b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.104']);

SM10a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.100']);
SM10b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.105']);

SM20a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.101']);
SM20b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.106']);

SM50a = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.102']);
SM50b = load([loadstart 'Matlab/Data/Met/Organized2/TP39/Column/30min/TP39_2008.107']);

SM_in.a5 = SM5a; SM_in.a10 = SM10a; SM_in.a20 = SM20a; SM_in.a50 = SM50a; 
SM_in.b5 = SM5b; SM_in.b10 = SM10b; SM_in.b20 = SM20b; SM_in.b50 = SM50b; 
 
[SM SMa SMb] = SM_average(SM_in) ;
SM_filled = jjb_interp_gap(SM, (1:1:length(SM))', 3);
SMa_filled = jjb_interp_gap(SMa, (1:1:length(SMa))', 3);
SMb_filled = jjb_interp_gap(SMb, (1:1:length(SMb))', 3);


length(find(isnan(SMa_filled)))


%% TP74
par_74 = load([loadstart 'Matlab/Data/Met/Organized2/TP74/Column/30min/TP74_2008.013']);
par_74 = [par_74(1:748); par_74(757:17568); NaN.*ones(8,1)];

Ta_74 = load([loadstart 'Matlab/Data/Met/Organized2/TP74/Column/30min/TP74_2008.007']);
Ta_74 = [Ta_74(1:748); Ta_74(757:17568); NaN.*ones(8,1)];

RH_74 = load([loadstart 'Matlab/Data/Met/Organized2/TP74/Column/30min/TP74_2008.008']);
RH_74 = [RH_74(1:748); RH_74(757:17568); NaN.*ones(8,1)];


[par_39_filled] = regress_fill(par, par_74);
%  ind_hole_par = find(isnan(par_39_filled));
[RH_39_filled] = regress_fill(RH,  RH_74);
[ RH_39_filled] = jjb_interp_gap(RH_39_filled, (1:1:length(RH_39_filled))', 3);

[Ta_39_filled] = regress_fill(Ta,  Ta_74);
[Ta_39_filled] = jjb_interp_gap(Ta_39_filled, (1:1:length(Ta_39_filled))', 3);

[Ts2a_filled] = jjb_interp_gap(Ts2a, (1:1:length(Ts2a))', 3);
[Ts2b_filled] = jjb_interp_gap(Ts2b, (1:1:length(Ts2b))', 3);
[Ts5a_filled] = jjb_interp_gap(Ts5a, (1:1:length(Ts5a))', 3);
[Ts5b_filled] = jjb_interp_gap(Ts5b, (1:1:length(Ts5b))', 3);

Ts2 = row_nanmean([Ts2a Ts2b]);
Ts5 = row_nanmean([Ts5a Ts5b]);

[Ts2_filled] = jjb_interp_gap(Ts2, (1:1:length(Ts2))', 3);
[Ts5_filled] = jjb_interp_gap(Ts5, (1:1:length(Ts5))', 3);
holes = length(find(isnan(Ts5_filled)));

% save variables:
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.Ta'],'Ta_39_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.RH'],'RH_39_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.PAR'],'par_39_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.Ts2'],'Ts2_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.Ts5'],'Ts5_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.SM'],'SM_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.SMa'],'SMa_filled','-ASCII');
save([loadstart 'Matlab/Data/Met/Final_Filled/TP39/TP39_2008.SMb'],'SMb_filled','-ASCII');
