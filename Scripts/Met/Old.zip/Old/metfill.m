function [] = metfill(year, site)
%% metclean.m
%%% This function is used to fill gaps in processed met data
%%% using either data from other sites or by using the MDV method.
%%

if ispc == 1
    dataloc = 'C:/HOME/'
else
    dataloc = '/home/jayb/'
end


%% Check if site is entered as string -- if not, convert it.
if ischar(site) == false
    site = num2str(site);
end
%%% Convert yr into a string
if ischar(year) == false
year = num2str(year);
end


%% Declare Paths

%%% Header path
hdr_path = [dataloc 'MATLAB/Data/Met/Raw1/Docs/'];

%%% Folder to load organize data from
load_path = [dataloc 'MATLAB/Data/Met/Cleaned3/Met' site '/Column/30min/'];

% %%% Folder to output loaded data
% output_path = [dataloc 'MATLAB/Data/Met/Cleaned3/Met' site '/'];

% %%% Folder for storing threshold files
% thresh_path = [dataloc 'MATLAB/Data/Met/Cleaned3/Threshold/'];

%%% Folder for filled files
fill_path = [dataloc 'MATLAB/Data/Met/Filled3a/Met' site '/'];
%% Load Header Files for each site

for ste = 1:1:4
hdr(ste).file = jjb_hdr_read([hdr_path 'Met' num2str(ste) '_OutputTemplate.csv'], ',', 3);

end

%% Take information from columns of the header file

for i = 1:1:4
%%% Column vector number    
col(i).num = str2num(char(hdr(i).file(:,1)));
%%% Title of variable
col(i).name = char(hdr(i).file(:,2));
%%% Minute intervals
col(i).min = str2num(char(hdr(i).file(:,3)));

%%% Use minute intervals to find 30-min variables only
col(i).vars30 = find(col(i).min(:,1) == 30);
%%% Create list of extensions needed to load all of these files
col(i).vars30_ext = create_label(col(i).num(col(i).vars30),3);
end

%% If working with Met 1 data, fill Tair, RH and PARdown data from M2:
if site == 1
    % Fill Tair
    Ta_m1 = jjb_load_var(hdr(1).file, load_path,'AirTemp_AbvCnpy');
    Ta_m2 = jjb_load_var(hdr(2).file, load_path,'AirTemp_AbvCnpy');
    Ta_m3 = jjb_load_var(hdr(3).file, load_path,'AirTemp_AbvCnpy');
    Ta_m1(isnan(Ta_m1)) = Ta_m2(isnan(Ta_m1));
    Ta_m1(isnan(Ta_m1)) = Ta_m3(isnan(Ta_m1));
    
    % Fill RH
    RH_m1 = jjb_load_var(hdr(1).file, load_path,'RelHum_AbvCnpy');
    RH_m2 = jjb_load_var(hdr(2).file, load_path,'RelHum_AbvCnpy');
    RH_m3 = jjb_load_var(hdr(3).file, load_path,'RelHum_AbvCnpy');
    RH_m1(isnan(RH_m1)) = RH_m2(isnan(RH_m1));
    RH_m1(isnan(RH_m1)) = RH_m3(isnan(RH_m1));    
    
    % Fill PAR
    PAR_m1 = jjb_load_var(hdr(1).file, load_path,'DownPAR_AbvCnpy');
    PAR_m2 = jjb_load_var(hdr(2).file, load_path,'RelHum_AbvCnpy');
    PAR_m3 = jjb_load_var(hdr(3).file, load_path,'RelHum_AbvCnpy');
    PAR_m1(isnan(PAR_m1)) = PAR_m2(isnan(PAR_m1));
    PAR_m1(isnan(PAR_m1)) = PAR_m3(isnan(PAR_m1));     
    
    
else
end

