%% Load Soil Data from M2, 2007:
tracker = [];
%% List of indiv data points to remove
remove(1).list = [14183]; remove(2).list = [17343]; remove(3).list = [13867 14183];
remove(4).list = [13681 13682]; remove(5).list = [13037 13681 13682 14566 15548 17147];
remove(6).list = [13681 13682 15539 15895 17185 17379];
remove(7).list = [13037 13681 13682 14183 14566];
remove(8).list = [13682 14566 14183 15647]; 
remove(9).list = []; remove(10).list = []; 
remove(11).list = [15287 15288];
remove(12).list = [13037 13681 14566];
%%
for p1 = 20:1:31
    ext = create_label(p1, 3);
    data = load(['C:\HOME\MATLAB\Data\Met\Cleaned3\Met2\Met2_2007.' ext]);
try
    tracker = load(['C:\HOME\MATLAB\Data\Met\Organized2\Docs\M2_2007_Ts_tracker\Met2_2007.' ext]);
data = data.*tracker;

catch
    tracker(1:length(data),1) = 1;
end
%%% Remove listed outliers
data(remove(p1-19).list) = NaN;
%%%

    figure(1); clf;
    plot(1:1:length(data),data,'k.-'); hold on;
    st = input('select starting point for manual cleaning: ');
    if isempty(st)==1
        %%% exit without doing anything

    else
        en = input('select end point: ');
        for loop2 = st:en
            if ~isnan(data(loop2,1))
            clf; plot(1:1:length(data),data,'k.-'); hold on;
            axis([loop2-10 loop2+40 min(data(st:en,1)) max(data(st:en,1))])
            plot(loop2,data(loop2,1),'MarkerEdgeColor','r','Marker','o','MarkerSize',10)
            decision = input('0 to remove, enter to keep');
            if decision == 0
                data(loop2,1) = NaN;
                tracker(loop2,1) = NaN;
            elseif decision == 3
                loop2 = loop2+30;
            else
            end
            end


        end
    end

    save(['C:\HOME\MATLAB\Data\Met\Cleaned3\Met2\Met2_2007.' ext],'data','-ASCII');
    save(['C:\HOME\MATLAB\Data\Met\Organized2\Docs\M2_2007_Ts_tracker\Met2_2007.' ext],'tracker','-ASCII');

%% Fill data by interpolation:
filled_data(:,1) = interp_nan(1:1:length(data),data);
save(['C:\HOME\MATLAB\Data\Met\Filled3a\Met2\Met2_2007.' ext],'filled_data','-ASCII');
figure(2); clf;
plot(filled_data,'k'); hold on;
plot(data,'g');
    
    clear data tracker filled_data
end



