function [] = metSHFlux(year, site, flux_source, met_source)
%% SHFlux.m
% This program is written 
% % Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option


% this program get soil surface heat flux G0 from soil heat 
% flux plates at 3cm (G3) and storage (M) between 0-3 cm 
% according to formula: G0 = G3 + M
% where M is the rate of change of heat stored in the top 3 cm
% layer per unit area and M = z*Cs*delta_T/delta_t. z is the thickness
% of layer above the flux plate (0.03m), Cs is the volumetric heat capacity 
% of the soil (J m^-3 K^-1) and delta_T/delta_t is the rate of change of 
% tht average temperature of teh top 3 cm (K s^-1). C can be calculated:
% C = 2.00*theta_m + 2.50*theta_o + 4.18*theta_w
% where theta_m, theta_o, theta_w are volume fractions of mineral soil, 
%organic matter and water respectively.
loadstart = addpath_loadstart;

%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end


%% Output location -- always the same
met_calc_path = ([loadstart '/Matlab/Data/Met/Calculated4/' site '/' site '_' year '_']);

%% Figure Output Path
fig_path = ([loadstart '/Matlab/Data/Flux/OPEC/Figs/' site '/' site '_' year '_']);

% %% Load Header File
% [hdr_cell] = jjb_hdr_read(hdr_path,',',num_hdr_cols);

%% Load needed variables %%%%%%%%%%%%%%%%%%%%%%%%%
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);
z = 0.03; %% Soil Heat Flux probes at 3 cm
delta_t = 1800; %% Half hour data


vars = jjb_flux_load('SHF', year, site, flux_source, met_source);
Ts2a = vars(:,1);
Ts2b = vars(:,2);
Ts5a = vars(:,3);
Ts5b = vars(:,4);
SHF1 = vars(:,5);
SHF2 = vars(:,6);

clear vars

if strcmp(site,'2') == 1 &&  strcmp(year,'2005') == 1
   M1_Ts5a = load([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.038']);
M1_Ts5b = load([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.044']);
M1_Ts2a = load([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.039']);
M1_Ts2b = load([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.045']);
Ts5a(4498:5736,1) = M1_Ts5a(4498:5736,1);
Ts5b(4498:5736,1) = M1_Ts5b(4498:5736,1);
Ts2a(4498:5736,1) = M1_Ts2a(4498:5736,1);
Ts2b(4498:5736,1) = M1_Ts2b(4498:5736,1);
end

%% Plot variables to investigate
figure(10); clf;
subplot(2,1,1)
plot(dt,Ts2a,'b'); hold on; plot(dt,Ts2b,'r'); plot(dt,Ts5a,'g'); plot(dt,Ts5b,'c');
legend('2a','2b','5a','5b')
subplot(2,1,2)
plot(dt,SHF1,'b'); hold on; plot(dt,SHF2,'r');
legend('SHF1','SHF2')

%% Condition Variables -- Filter and Fill Gaps
%%%%%%%%%%%%%%%%%%%%%% Soil Heat Flux %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
SHF1(SHF1 > 100 | SHF1 < -50,1) = NaN;
SHF2(SHF2 > 100 | SHF2 < -50,1) = NaN;

%%% Fill gaps
good_shf1 = find(~isnan(SHF1)==1);
good_shf2 = find(~isnan(SHF2)==1);
%% Fill in Gaps for specific years:

%%% Average both SHF if both numbers exist
[junka junkb common] = intersect(good_shf1, good_shf2);

Gavg(1:1:length(dt),1) = NaN;
Gavg(good_shf1,1) = SHF1(good_shf1);  %% put in good numbers for SHF1
Gavg(good_shf2,1) = SHF2(good_shf2);  %% put in good numbers for SHF2
Gavg(common,1) = (SHF1(common)+ SHF2(common))./2; % put in average when both are present

%%%%%%%%%%%%%%%%%%%%%%%% Soil Temperatures %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Remove erroneous data
Ts2a(Ts2a<-15 | Ts2a > 50,1) = NaN; 
Ts5a(Ts5a<-15 | Ts5a > 50,1) = NaN; 
Ts2b(Ts2b<-15 | Ts2b > 50,1) = NaN; 
Ts5b(Ts5b<-15 | Ts5b > 50,1) = NaN; 

% %%% Better cleaning
% Ts2a_m1 = Ts2a(2:length(Ts2a));
% Ts2a_diff = Ts2a(1:length(Ts2a)-1)-Ts2a_m1;
% Ts2a(Ts2a_diff>4 | Ts2a_diff < -4 ,1) = NaN;
% 
% 
% Ts2b_m1 = Ts2b(2:length(Ts2b));
% Ts2b_diff = Ts2b(1:length(Ts2b)-1)-Ts2b_m1;
% Ts2b(Ts2b_diff>4 | Ts2b_diff < -4 ,1) = NaN;


if strcmp(site,'2') == 1 && strcmp(year,'2005') == 1
Ts = Ts2b;
Ts(isnan(Ts)) = Ts5a(isnan(Ts));
Ts(isnan(Ts)) = Ts5b(isnan(Ts));
else

%%% Fill gaps in data
Ts = (Ts2a+Ts2b)./2;
Ts(isnan(Ts)) = Ts2a(isnan(Ts));
% Fill gaps in Ts2a with Ts2b
Ts(isnan(Ts)) = Ts2b(isnan(Ts));
end
% Fill small gaps with linear interpolation
Ts = jjb_interp_gap(Ts,dt,3);
% % Fill large gaps with Mean Diurnal Variation method
% Ts = jjb_MDV_gapfill(Ts,4,48);

%% %%%%%%%%%%%%%%%%%%%%% Site Specific Coefficients and Operations %%%%%%%%%%%%%%%%%%%%%%%%%%
[param]=params(year, site, 'SHF');
theta_w = param(:,1); theta_m = param(:,2); theta_o = param(:,3);

%% Shift soil temperature to calculate dT/dt..
ind_dt(:,1) = 2:length(Ts);
dTs = Ts(ind_dt,1) - Ts(ind_dt-1,1);

%% Calculations
M(1:1:length(dTs)) = NaN;
Cs = 2.*theta_m + 2.5.*theta_o + 4.18.*theta_w;

M = (z.*Cs.*(dTs./delta_t))*1.0e6;        %%%in W^m-2
M = [M(1) ;M(1:end)];

G0 = Gavg + M;

% %% Clean G0
% 
% %%% Remove Spikes
if strcmp(site,'3') == 1
G0(G0 <-25 | G0 > 30) = NaN;  
else
G0(G0 <-50 | G0 > 200) = NaN;
end
% 
G0_m1 = G0(2:length(G0));
G0_diff = G0(1:length(G0)-1) - G0_m1;
G0(abs(G0_diff)>75,1) = NaN;

%%% Fill small gaps
G0 = jjb_interp_gap(G0,dt,3);
% G0 = jjb_MDV_gapfill(G0,2,48);


%% Save Variables
save ([met_calc_path 'Ts.dat'],'Ts','-ASCII');
save ([met_calc_path 'soil_Hstor.dat'],'M','-ASCII');
save ([met_calc_path 'g0.dat'],'G0','-ASCII');

%% Plot

figure (1)
clf;
h1 = plot(dt,G0,'b');
hold on;
h2 = plot(dt,Ts,'r');
ylabel('Soil Heat Flux (Wm_2); Soil Temperature (^oC)')
xlabel('Day of Year')
legend([h1 h2], 'g0', 'Ts')
axis ([0 365 min(G0) max(G0)]);
print('-dill',[fig_path 'SoilHeatFlux']);
print('-dtiff',[fig_path 'SoilHeatFlux']);

end
