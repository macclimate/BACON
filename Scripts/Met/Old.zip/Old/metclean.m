function [] = metclean(year, site);



%% 
Ts2a(Ts2a<-8,1) = NaN; Ts2a(:,1) = interp_nan(dt,Ts2a);
Ts5a(Ts5a<-8,1) = NaN; Ts5a(:,1) = interp_nan(dt,Ts5a);
Ts2b(Ts2b<-8,1) = NaN; Ts2b(:,1) = interp_nan(dt,Ts2b);
Ts5b(Ts5b<-8,1) = NaN; Ts5b(:,1) = interp_nan(dt,Ts5b);