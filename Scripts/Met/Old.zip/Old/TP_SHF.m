%% SHFlux.m
% This program is written
% % Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option
clear all
close all


% this program get soil surface heat flux G0 from soil heat
% flux plates at 3cm (G3) and storage (M) between 0-3 cm
% according to formula: G0 = G3 + M
% where M is the rate of change of heat stored in the top 3 cm
% layer per unit area and M = z*Cs*delta_T/delta_t. z is the thickness
% of layer above the flux plate (0.03m), Cs is the volumetric heat capacity
% of the soil (J m^-3 K^-1) and delta_T/delta_t is the rate of change of
% tht average temperature of teh top 3 cm (K s^-1). C can be calculated:
% C = 2.00*theta_m + 2.50*theta_o + 4.18*theta_w
% where theta_m, theta_o, theta_w are volume fractions of mineral soil,
%organic matter and water respectively.
%%
if ispc == 1
    data_loc = 'C:/HOME/';
else
    data_loc = '/home/jayb/';
end

st_yr = 2003;
en_yr = 2007;
num_yrs = en_yr-st_yr+1;
%%
for site_num = 1:1:4

    site_list = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
    site = site_list(site_num,:);
disp(['site:' site]);
    for year_num = st_yr:1:en_yr
        yr_ctr = year_num - st_yr+1;
        year = num2str(year_num);

%% Input and Output locations -- always the same
        load_path_filled = ([data_loc 'MATLAB/Data/Met/Final_Filled/' site '/' site '_' year]);
        load_path_cleaned = ([data_loc 'MATLAB/Data/Met/Final_Cleaned/' site '/' site '_' year]);
        save_path = ([data_loc 'MATLAB/Data/Met/Calculated4/' site '/' site '_' year ]);
param_path = [data_loc 'MATLAB/Data/Met/Calculated4/Docs/'];
        hdr_path = [data_loc 'MATLAB/Data/Met/Final_Cleaned/Headers/'];
tracker_path = [data_loc 'MATLAB/Data/Flux/Met_Flux_Tracker/' site '/' site '_' year];
        
%% Parameters:
        [junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);
        z = 0.03; %% Soil Heat Flux probes at 3 cm
        delta_t = 1800; %% Half hour data
SHF_params = dlmread([param_path 'TP_SHF_params.csv'],',');
%% Load needed variables %%%%%%%%%%%%%%%%%%%%%%%%%
        %%% Load header
        hdr = jjb_hdr_read([hdr_path site '_CCP_List.csv'], ',', 2);

        data(yr_ctr).Ts2 = load([load_path_filled '.Ts2']);
        data(yr_ctr).Ts5 = load([load_path_filled '.Ts5']);
        data(yr_ctr).shf1 = jjb_load_var(hdr,[load_path_cleaned '.'],'G_Plate1',1);
        data(yr_ctr).shf2 = jjb_load_var(hdr,[load_path_cleaned '.'],'G_Plate2',1);

%% Plot variables to investigate
        figure(1); clf;
        plot(dt,data(yr_ctr).shf1,'b'); hold on; plot(dt,data(yr_ctr).shf2,'r')
        legend('SHF1','SHF2')

        %%% Scatterplot of pit A vs pit B -- possible to fill from one to other??
        figure(2)
        ok_data = find(~isnan(data(yr_ctr).shf1 .* data(yr_ctr).shf2));
        plot(data(yr_ctr).shf1(ok_data), data(yr_ctr).shf2(ok_data),'k.')

%% Average SHF values between pits
        data(yr_ctr).shf(1:length(data(yr_ctr).shf1),1) = NaN;
        data(yr_ctr).shf = row_nanmean([data(yr_ctr).shf1 data(yr_ctr).shf2]);

        %% Put in gap-filling for SHF data at this point--before adding in storage?

%% %%%%%%%%%%%%%%%%%%%%% Site Specific Coefficients and Operations %%%%%%%%%%%%%%%%%%%%%%%%%%
        [param]=params(year, num2str(site_num), 'SHF');
        theta_w = param(:,1); theta_m = param(:,2); theta_o = param(:,3);

%% Calculate dT/dt -- change in storage for top 3 cm
        ind_dt(:,1) = 2:length(dt);
        data(yr_ctr).dTs(1:length(dt),1) = NaN;
        data(yr_ctr).dTs(2:length(dt),1) = data(yr_ctr).Ts2(ind_dt,1) - data(yr_ctr).Ts2(ind_dt-1,1);
        data(yr_ctr).dTs(1,1) = data(yr_ctr).dTs(2,1);

        %% Calculations
        data(yr_ctr).M(1:1:length(dt),1) = NaN;
        Cs = 2.*theta_m + 2.5.*theta_o + 4.18.*theta_w;

        data(yr_ctr).M = (z.*Cs.*(data(yr_ctr).dTs./delta_t))*1.0e6;        %%%in W^m-2
        % M = [M(1) ;M(1:end)];
        data(yr_ctr).G = data(yr_ctr).shf + data(yr_ctr).M;

%% Clean G

figure(3); clf
plot(data(yr_ctr).G,'b.-');      

% %%% Remove Spikes
right_row = find(SHF_params(:,1) == site_num & SHF_params(:,2) == year_num);
             
data(yr_ctr).G(data(yr_ctr).G < SHF_params(right_row,3) | data(yr_ctr).G > SHF_params(right_row,4)) = NaN;
             z = SHF_params(right_row,6);
             sdev = SHF_params(right_row,7);
             st_pt = SHF_params(right_row,5);


% 
% switch site
%     case 'TP39'
% 
%              data(yr_ctr).G(data(yr_ctr).G <-20 | data(yr_ctr).G > 50) = NaN;
%              z = 15;
%              sdev = 1.5;
%     case 'TP74'
% 
%              data(yr_ctr).G(data(yr_ctr).G <-30 | data(yr_ctr).G > 80) = NaN;
%              z = 20;
%              sdev = 2;
%     case 'TP89'
%              data(yr_ctr).G(data(yr_ctr).G <-30 | data(yr_ctr).G > 30) = NaN;
%              z = 15;
%              sdev = 1.5;             
%     case 'TP02'         
%              data(yr_ctr).G(data(yr_ctr).G <-50 | data(yr_ctr).G > 150) = NaN;
%              z = 20;
%              sdev = 2;             
% end

         


real_spikes = jjb_find_spike2(data(yr_ctr).G, z,sdev,st_pt);
data(yr_ctr).G(abs(real_spikes)==1,1) = NaN;


%         %
%         
% %         spike_tracker(1:length(data(yr_ctr).G)
%         
%          
%         data(yr_ctr).G_m1 = data(yr_ctr).G(2:length(data(yr_ctr).G));
%         data(yr_ctr).G_diff = data(yr_ctr).G(1:length(data(yr_ctr).G)-1) - data(yr_ctr).G_m1;
% 
%         
%         
% figure(4)
% plot(data(yr_ctr).G_diff,'b')
%         ind_bad = find(abs(
%         
%         
%         data(yr_ctr).G(abs(data(yr_ctr).G_diff)>75,1) = NaN;
% 
        %%% Fill the rest with interpolation (small gaps) and MDV (larger gaps):
        data(yr_ctr).G = jjb_interp_gap(data(yr_ctr).G,dt,3);
        
         data(yr_ctr).Gfill = jjb_MDV_gapfill(data(yr_ctr).G,5,48);

figure(3);hold on;
plot(data(yr_ctr).G,'go'); hold on;
plot(data(yr_ctr).Gfill,'r');
%         %% Save Variables
temp_M = data(yr_ctr).M; temp_G = data(yr_ctr).G; temp_Gfill = data(yr_ctr).Gfill; 



        save ([save_path 'soil_Hstor.dat'],'temp_M','-ASCII');
        save ([save_path 'g0.dat'],'temp_G','-ASCII');
        save ([save_path 'g0_filled.dat'],'temp_Gfill','-ASCII');        

%         %%% save tracker files:
% save([tracker_path 'dcdt_1h_tracker.dat'],'dcdt1h_tracker');
% save([tracker_path 'dcdt_2h_tracker.dat'],'dcdt2h_tracker');

        
        
        
        %% Plot
% 
%         figure (1)
%         clf;
%         h1 = plot(dt,data(yr_ctr).G,'b');
%         hold on;
%         h2 = plot(dt,Ts,'r');
%         ylabel('Soil Heat Flux (Wm_2); Soil Temperature (^oC)')
%         xlabel('Day of Year')
%         legend([h1 h2], 'g0', 'Ts')
%         axis ([0 365 min(data(yr_ctr).G) max(data(yr_ctr).G)]);
%         print('-dill',[fig_path 'SoilHeatFlux']);
%         print('-dtiff',[fig_path 'SoilHeatFlux']);
    clear data temp* dt junk ind_dt;
%     respo = input('press enter to continue');
    end
end