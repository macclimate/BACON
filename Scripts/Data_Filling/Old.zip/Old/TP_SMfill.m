%% This script fills all met variables that must be continuous in order to
%%% use for flux estimations.  In addition to filling the data file, a
%%% tracker file will be kept for each site, detailing what met data has
%%% been filled for each year.  Filling processes will be grouped by the
%%% variable that is being filled.
%%%%% Please note that the method for fillinga particular variable may
%%% change from year to year and site to site,depending on what data and
%%% methods are available.  Each section will be documented accordingly.
%%%%% The following variables will be filled:
% 1) PAR
% 2) Air Temperature (Ts)
% 3) Soil Temperature (2cm & 5cm)
% 4) Relative Humidity (RH)
%% 5) Average Soil Moisture Content (%)
%%% Created July 2, 2008 by JJB

%% Setting variables:
clear all; close all;

if ispc == 1;
    data_loc = 'C:/HOME/';
else
    data_loc = '/home/jayb/';
end

st_yr = 2003;
en_yr = 2007;
num_yrs = en_yr-st_yr+1;
%%
for site_num = 3%1:1:4

    site_list = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
    site = site_list(site_num,:);
disp(['site:' site]);

    for year_num = st_yr:1:en_yr
        yr_ctr = year_num - st_yr+1;
        year = num2str(year_num);

%% Input and Output locations -- always the same
        load_path_filled = ([data_loc 'MATLAB/Data/Met/Final_Filled/' site '/' site '_' year]);
        load_path_cleaned = ([data_loc 'MATLAB/Data/Met/Final_Cleaned/' site '/' site '_' year]);
%         save_path = ([data_loc 'MATLAB/Data/Met/Calculated4/' site '/' site '_' year ]);
param_path = [data_loc 'MATLAB/Data/Met/Calculated4/Docs/'];
        hdr_path = [data_loc 'MATLAB/Data/Met/Final_Cleaned/Headers/'];
tracker_path = [data_loc 'MATLAB/Data/Flux/Met_Flux_Tracker/' site '/' site '_' year];
        
%% Time Variables:
        [junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);
%% Load needed variables %%%%%%%%%%%%%%%%%%%%%%%%%
        %%% Load header
        hdr = jjb_hdr_read([hdr_path site '_CCP_List.csv'], ',', 2);
   SM100a = jjb_load_var(hdr,[load_path_cleaned '.'],'SM100cmA',1);
   SM100b = jjb_load_var(hdr,[load_path_cleaned '.'],'SM100cmB',1);
   SM50a = jjb_load_var(hdr,[load_path_cleaned '.'],'SM50cmA',1);
   SM50b = jjb_load_var(hdr,[load_path_cleaned '.'],'SM50cmB',1);       
   SM20a = jjb_load_var(hdr,[load_path_cleaned '.'],'SM20cmA',1);
   SM20b = jjb_load_var(hdr,[load_path_cleaned '.'],'SM20cmB',1);        
   SM10a = jjb_load_var(hdr,[load_path_cleaned '.'],'SM10cmA',1);
   SM10b = jjb_load_var(hdr,[load_path_cleaned '.'],'SM10cmB',1);        
   SM5a = jjb_load_var(hdr,[load_path_cleaned '.'],'SM5cmA',1);
   SM5b = jjb_load_var(hdr,[load_path_cleaned '.'],'SM5cmB',1);        
        
%% Average for Pit A:   
SMa = NaN.*ones(length(dt),1);

%%% estimate value at 30cm:
SM30a(:,1) = (((SM50a - SM20a)./30).*10)+SM20a;
SM15a(:,1) = mean([SM10a'; SM20a']);
SM25a(:,1) = mean([SM20a'; SM30a']);
SM7p5a(:,1) = mean([SM5a'; SM10a']);
SM12p5a(:,1) = mean([SM5a'; SM20a']);
SM17p5a(:,1) = mean([SM5a'; SM30a']);
SM20p0a(:,1) = mean([SM10a'; SM30a']);

SM_depths = [5 7.5 10 12.5 15 17.5 20 25];
SM_all = [SM5a SM7p5a SM10a SM12p5a SM15a SM17p5a SM20a SM25a];
SM_list = [~isnan(SM5a) ~isnan(SM7p5a) ~isnan(SM10a) ~isnan(SM12p5a) ~isnan(SM15a) ~isnan(SM17p5a) ~isnan(SM20a) ~isnan(SM25a)];

for i = 1:1:length(SMa)
   good_cols = find(SM_list(i,:)==1);
if length(good_cols) > 2
   wt(1) = SM_depths(good_cols(1)) + (SM_depths(good_cols(2)) - SM_depths(good_cols(1)))./2;
   for k = 2:1:length(good_cols)-1
       wt(k) = (SM_depths(good_cols(k)) - SM_depths(good_cols(k-1)))./2 + (SM_depths(good_cols(k+1)) - SM_depths(good_cols(k)))./2; 
   end
   wt(k+1) = (30- SM_depths(k+1)) + (SM_depths(good_cols(k+1)) - SM_depths(good_cols(k)))./2;
wt = wt./30;
   
   
   SMa(i,1) = sum(SM_all(i,good_cols).*wt);
clear wt good_cols;

else
    SMa(i,1) = NaN;
end   

end



% SMa(:,1) = mean([SM5a';SM15a';SM25a']);
clear SM_depths SM_all SM_list;


%% Average for Pit B: 
SMb = NaN.*ones(length(dt),1);

SM30b(:,1) = (((SM50b - SM20b)./30).*10)+SM20b;
%%% estimate value at 30cm:
SM7p5b(:,1) = mean([SM5b'; SM10b']);
SM12p5b(:,1) = mean([SM5b'; SM20b']);
SM15b(:,1) = mean([SM10b'; SM20b']);
SM17p5b(:,1) = mean([SM5b'; SM30b']);
SM20p0b(:,1) = mean([SM10b'; SM30b']);
SM25b(:,1) = mean([SM20b'; SM30b']);
SM_depths = [5 7.5 10 12.5 15 17.5 20 25];
SM_all = [SM5b SM7p5b SM10b SM12p5b SM15b SM17p5b SM20b SM25b];
SM_list = [~isnan(SM5b) ~isnan(SM7p5b) ~isnan(SM10b) ~isnan(SM12p5b) ~isnan(SM15b) ~isnan(SM17p5b) ~isnan(SM20b) ~isnan(SM25b)];

for i = 1:1:length(SMb)
   good_cols = find(SM_list(i,:)==1);
if length(good_cols) > 2
   wt(1) = SM_depths(good_cols(1)) + (SM_depths(good_cols(2)) - SM_depths(good_cols(1)))./2;
   for k = 2:1:length(good_cols)-1
       wt(k) = (SM_depths(good_cols(k)) - SM_depths(good_cols(k-1)))./2 + (SM_depths(good_cols(k+1)) - SM_depths(good_cols(k)))./2; 
   end
   wt(k+1) = (30- SM_depths(k+1)) + (SM_depths(good_cols(k+1)) - SM_depths(good_cols(k)))./2;
wt = wt./30;
   
   
   SMb(i,1) = sum(SM_all(i,good_cols).*wt);
clear wt good_cols;

else
    SMb(i,1) = NaN;
end   

end

% SMb2(:,1) = mean([SM5b';SM15b';SM25b']);

%% Average over both pits:
SM(:,1) = row_nanmean([SMa SMb]);
        
%% Check
figure(yr_ctr); clf
plot(SM); hold on;
plot(SMa,'r');
plot(SMb,'g');
legend('SM','SMa','SMb')
title(['SM for year ' num2str(year_num)]);

%% SAVE files to filled directory
save([load_path_filled '.SMa'],'SMa','-ASCII');
save([load_path_filled '.SMb'],'SMb','-ASCII');
save([load_path_filled '.SM'],'SM','-ASCII');

clear SM* dt junk 
    end
%     resp = input('press enter to continue to next site');
end
        