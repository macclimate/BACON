%% This script fills all met variables that must be continuous in order to 
%%% use for flux estimations.  In addition to filling the data file, a
%%% tracker file will be kept for each site, detailing what met data has
%%% been filled for each year.  Filling processes will be grouped by the
%%% variable that is being filled.  
%%%%% Please note that the method for fillinga particular variable may 
%%% change from year to year and site to site,depending on what data and 
%%% methods are available.  Each section will be documented accordingly.
%%%%% The following variables will be filled:
% 1) PAR
% 2) Air Temperature (Ta)
% 3) Soil Temperature (2cm & 5cm)
% 4) Relative Humidity (PAR)
% 5) 
loadstart = addpath_loadstart;

%%% Created June 18, 2008 by JJB
%% Setting variables:

% if ispc == 1;
%     loadstart = 'C:/HOME/';
% else
%     loadstart = '/home/jayb/';
% end

%%% Set Start and end years:
st_yr = 2008;
end_yr = 2008;
num_yrs = end_yr - st_yr + 1;
%%% Declare Paths:
load_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/'];
hdr_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/Headers/'];
save_path = [loadstart 'Matlab/Data/Met/Final_Filled/'];
tracker_path = [loadstart 'Matlab/Data/Flux/Met_Flux_Tracker/'];
%%% Load headers
hdr_TP02 = jjb_hdr_read([hdr_path 'TP02_CCP_List.csv'], ',', 2);
hdr_TP39 = jjb_hdr_read([hdr_path 'TP39_CCP_List.csv'], ',', 2);
hdr_TP74 = jjb_hdr_read([hdr_path 'TP74_CCP_List.csv'], ',', 2);
hdr_TP89 = jjb_hdr_read([hdr_path 'TP89_CCP_List.csv'], ',', 2);

%%% Create Tracker Files (all files start at zero, meaning no data exists):
TP02_PARtracker(1:17568,1:num_yrs) = 0; TP39_PARtracker(1:17568,1:num_yrs) = 0; 
TP74_PARtracker(1:17568,1:num_yrs) = 0; TP89_PARtracker(1:17568,1:num_yrs) = 0; 

%% 1) PAR:
colors = colormap(lines(num_yrs));

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
%     yr_list(yr_ctr,:) = num2str(j);
%%% Load all data:   
try
    TP02(yr_ctr).PAR = jjb_load_var(hdr_TP02,[load_path 'TP02/TP02_' num2str(j) '.'],'PARdown_3m',1);
catch
    TP02(yr_ctr).PAR = NaN.*ones(17568,1);
end
try
    TP39(yr_ctr).PAR = jjb_load_var(hdr_TP39,[load_path 'TP39/TP39_' num2str(j) '.'],'PARdown_28m',1);
catch
    TP39(yr_ctr).PAR = NaN.*ones(17568,1);
end

try
    TP74(yr_ctr).PAR = jjb_load_var(hdr_TP74,[load_path 'TP74/TP74_' num2str(j) '.'],'PARdown_15m',1);
catch
    TP74(yr_ctr).PAR = NaN.*ones(17568,1);
end

try
    TP89(yr_ctr).PAR = jjb_load_var(hdr_TP89,[load_path 'TP89/TP89_' num2str(j) '.'],'PARdown_12m',1);
catch
    TP89(yr_ctr).PAR = NaN.*ones(17568,1);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%% Clean bottom of data (remove this part after CCP_output is run once again)
    TP02(yr_ctr).PAR(TP02(yr_ctr).PAR(:,1) < 20,1) = 0;
    TP39(yr_ctr).PAR(TP39(yr_ctr).PAR(:,1) < 10,1) = 0;
    TP74(yr_ctr).PAR(TP74(yr_ctr).PAR(:,1) < 10,1) = 0;
    TP89(yr_ctr).PAR(TP89(yr_ctr).PAR(:,1) < 10,1) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    
%%% Fill tracker files for rows where data exists:
TP02_PARtracker(~isnan(TP02(yr_ctr).PAR),yr_ctr) = 1;
TP39_PARtracker(~isnan(TP39(yr_ctr).PAR),yr_ctr) = 1;
TP74_PARtracker(~isnan(TP74(yr_ctr).PAR),yr_ctr) = 1;
TP89_PARtracker(~isnan(TP89(yr_ctr).PAR),yr_ctr) = 1;
    
figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP02 PAR ' num2str(j)]);
figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP39 PAR ' num2str(j)]);
figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP74 PAR ' num2str(j)]);
figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP89 PAR ' num2str(j)]);   
end

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);

%%% Test how close each sensor is to the other:
% A) TP39 vs TP74
figure(5)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP74(yr_ctr).PAR,'k.');title('TP39 vs TP74'); hold on;plot([0 2500],[0 2500],'r--');
p39_74(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0) ,TP74(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_74(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0) ,TP74(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0));

figure(6)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP39 vs TP89');hold on;plot([0 2500],[0 2500],'r--');
p39_89(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_89(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0));

figure(7)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP39 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p39_02(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_02(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

figure(8)
subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP74 vs TP89');hold on;plot([0 2500],[0 2500],'r--');
p74_89(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p74_89(yr_ctr,3) = rsquared(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0));

figure(9)
subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP74 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p74_02(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p74_02(yr_ctr,3) = rsquared(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

figure(10)
subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP89 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p89_02(yr_ctr,1:2) = mmpolyfit(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p89_02(yr_ctr,3) = rsquared(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

end

%%% At this point, I believe what we want to do is standardize everything
%%% by the regression with TP39, and then use the r-squared values to
%%% determine which site the data should be filled in from.  Scratch that,
%%% perhaps I will only adjust TP02 data for 2003-(early)2006 so that they match
%%% up with PAR measured after that (sensor was adjusted in 2006,
%%% resulting in higher amplitudes and closer similarity with TP39.
for k = 1:1:4
if k == 4
    TP02(k).PAR(1:7371,1) = (TP02(k).PAR(1:7371,1)./p39_02(k,1)).*p39_02(5,1);
else
    TP02(k).PAR = (TP02(k).PAR./p39_02(k,1)).*p39_02(5,1);
end
end
clear p*
%% recalculate slope and rsquared
for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% Test how close each sensor is to the other:
    % A1) TP39 & TP74

    figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP74(yr_ctr).PAR,'k.');title('TP39 vs TP74'); hold on;plot([-10 40],[-10 40],'r--');
 
    [p39_74(yr_ctr).PAR pred39_74(yr_ctr).PAR pw39_74(yr_ctr).PAR pred_adj39_74(yr_ctr).PAR] = Ts_fit(TP39(yr_ctr).PAR, TP74(yr_ctr).PAR);

    % A2) TP39 & TP89
    figure(3)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP39 vs TP89'); hold on;plot([-10 40],[-10 40],'r--');

    [p39_89(yr_ctr).PAR pred39_89(yr_ctr).PAR pw39_89(yr_ctr).PAR pred_adj39_89(yr_ctr).PAR] = Ts_fit(TP39(yr_ctr).PAR, TP89(yr_ctr).PAR);

    % A3) TP39 & TP02
    figure(5)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP39 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');
    [p39_02(yr_ctr).PAR pred39_02(yr_ctr).PAR pw39_02(yr_ctr).PAR pred_adj39_02(yr_ctr).PAR] = Ts_fit(TP39(yr_ctr).PAR, TP02(yr_ctr).PAR);
  
   
    % B1) TP74 & TP39
    [p74_39(yr_ctr).PAR pred74_39(yr_ctr).PAR pw74_39(yr_ctr).PAR pred_adj74_39(yr_ctr).PAR] = Ts_fit(TP74(yr_ctr).PAR, TP39(yr_ctr).PAR);

    % B2) TP74 & TP89
    figure(7)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP74 vs TP89'); hold on;plot([-10 40],[-10 40],'r--');
    [p74_89(yr_ctr).PAR pred74_89(yr_ctr).PAR pw74_89(yr_ctr).PAR pred_adj74_89(yr_ctr).PAR] = Ts_fit(TP74(yr_ctr).PAR, TP89(yr_ctr).PAR);

    % B3) TP74 & TP02
    figure(9)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP74 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');
    
    [p74_02(yr_ctr).PAR pred74_02(yr_ctr).PAR pw74_02(yr_ctr).PAR pred_adj74_02(yr_ctr).PAR] = Ts_fit(TP74(yr_ctr).PAR, TP02(yr_ctr).PAR);
    
    % C1) TP89 & TP39
    [p89_39(yr_ctr).PAR pred89_39(yr_ctr).PAR pw89_39(yr_ctr).PAR pred_adj89_39(yr_ctr).PAR] = Ts_fit(TP89(yr_ctr).PAR, TP39(yr_ctr).PAR);

    % C2) TP89 & TP74
    [p89_74(yr_ctr).PAR pred89_74(yr_ctr).PAR pw89_74(yr_ctr).PAR pred_adj89_74(yr_ctr).PAR] = Ts_fit(TP89(yr_ctr).PAR, TP74(yr_ctr).PAR);
   
    % C3) TP89 & TP02
    figure(11)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP89 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');

    [p89_02(yr_ctr).PAR pred89_02(yr_ctr).PAR pw89_02(yr_ctr).PAR pred_adj89_02(yr_ctr).PAR] = Ts_fit(TP89(yr_ctr).PAR, TP02(yr_ctr).PAR);

    % D1) TP02 & TP39
    [p02_39(yr_ctr).PAR pred02_39(yr_ctr).PAR pw02_39(yr_ctr).PAR pred_adj02_39(yr_ctr).PAR] = Ts_fit(TP02(yr_ctr).PAR, TP39(yr_ctr).PAR);

    % D2) TP02 & T74
    [p02_74(yr_ctr).PAR pred02_74(yr_ctr).PAR pw02_74(yr_ctr).PAR pred_adj02_74(yr_ctr).PAR] = Ts_fit(TP02(yr_ctr).PAR, TP74(yr_ctr).PAR);
    
    % D3) TP02 & T89
    [p02_89(yr_ctr).PAR pred02_89(yr_ctr).PAR pw02_89(yr_ctr).PAR pred_adj02_89(yr_ctr).PAR] = Ts_fit(TP02(yr_ctr).PAR, TP89(yr_ctr).PAR);

end



%% Make a list of r2 and slope values:
for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);
    
 master_slope_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).PAR(1)      p39_89(yr_ctr).PAR(1)     p39_02(yr_ctr).PAR(1)] ;
 master_slope_TP74(yr_ctr,:) = [p74_39(yr_ctr).PAR(1) zeros.*ones(1,1)           p74_89(yr_ctr).PAR(1)     p74_02(yr_ctr).PAR(1)] ;
 master_slope_TP89(yr_ctr,:) = [p89_39(yr_ctr).PAR(1) p89_74(yr_ctr).PAR(1)      zeros.*ones(1,1)          p89_02(yr_ctr).PAR(1)] ;
 master_slope_TP02(yr_ctr,:) = [p02_39(yr_ctr).PAR(1) p02_74(yr_ctr).PAR(1)      p02_89(yr_ctr).PAR(1)     zeros.*ones(1,1)     ] ;
    
 master_r2_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).PAR(3)      p39_89(yr_ctr).PAR(3)     p39_02(yr_ctr).PAR(3)] ;
 master_r2_TP74(yr_ctr,:) = [p74_39(yr_ctr).PAR(3) zeros.*ones(1,1)           p74_89(yr_ctr).PAR(3)     p74_02(yr_ctr).PAR(3)] ;
 master_r2_TP89(yr_ctr,:) = [p89_39(yr_ctr).PAR(3) p89_74(yr_ctr).PAR(3)      zeros.*ones(1,1)          p89_02(yr_ctr).PAR(3)] ;
 master_r2_TP02(yr_ctr,:) = [p02_39(yr_ctr).PAR(3) p02_74(yr_ctr).PAR(3)      p02_89(yr_ctr).PAR(3)     zeros.*ones(1,1)     ] ;

 master_r2adj_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).PAR(4)      p39_89(yr_ctr).PAR(4)     p39_02(yr_ctr).PAR(4)] ;
 master_r2adj_TP74(yr_ctr,:) = [p74_39(yr_ctr).PAR(4) zeros.*ones(1,1)           p74_89(yr_ctr).PAR(4)     p74_02(yr_ctr).PAR(4)] ;
 master_r2adj_TP89(yr_ctr,:) = [p89_39(yr_ctr).PAR(4) p89_74(yr_ctr).PAR(4)      zeros.*ones(1,1)          p89_02(yr_ctr).PAR(4)] ;
 master_r2adj_TP02(yr_ctr,:) = [p02_39(yr_ctr).PAR(4) p02_74(yr_ctr).PAR(4)      p02_89(yr_ctr).PAR(4)     zeros.*ones(1,1)     ] ;
 
end
 
 master_slope = [master_slope_TP39; master_slope_TP74; master_slope_TP89; master_slope_TP02 ];

 master_r2 = [master_r2_TP39; master_r2_TP74; master_r2_TP89; master_r2_TP02 ];

 master_r2adj = [master_r2adj_TP39; master_r2adj_TP74; master_r2adj_TP89; master_r2adj_TP02 ];

            
%% FILL GAPS:

master_counter = 1;

%% Fill gaps in TP39

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

    %%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));

    % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
    best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill PAR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP39(yr_ctr).PAR)); % find the rows that need to be filled

        switch best(kk)
            case 1
               TP39(yr_ctr).PAR(empty_rows) = pred39_39(yr_ctr).PAR(empty_rows);
            case 2
                TP39(yr_ctr).PAR(empty_rows) = pred74_39(yr_ctr).PAR(empty_rows);
            case 3
                TP39(yr_ctr).PAR(empty_rows) = pred89_39(yr_ctr).PAR(empty_rows);
            case 4
                TP39(yr_ctr).PAR(empty_rows) = pred02_39(yr_ctr).PAR(empty_rows);
        end

        clear empty_rows
    end
    filled_rows = find(TP39_PARtracker(1:length(TP39(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP39(yr_ctr).PAR));
    TP39_PARtracker(filled_rows,yr_ctr) = 2;
    clear filled_rows
    master_counter = master_counter + 1;
end

%% Fill gaps in TP74:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

    %%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));

    % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
    best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill PAR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP74(yr_ctr).PAR)); % find the rows that need to be filled

        switch best(kk)
            case 1
                TP74(yr_ctr).PAR(empty_rows) = pred39_74(yr_ctr).PAR(empty_rows);
            case 2
                TP74(yr_ctr).PAR(empty_rows) = pred74_74(yr_ctr).PAR(empty_rows);
            case 3
                TP74(yr_ctr).PAR(empty_rows) = pred89_74(yr_ctr).PAR(empty_rows);
            case 4
                TP74(yr_ctr).PAR(empty_rows) = pred02_74(yr_ctr).PAR(empty_rows);
        end

        clear empty_rows
    end
    filled_rows = find(TP74_PARtracker(1:length(TP74(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP74(yr_ctr).PAR));
    TP74_PARtracker(filled_rows,yr_ctr) = 2;


    clear filled_rows
    master_counter = master_counter + 1;
end


%% Fill gaps in TP89:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

    %%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));

    % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
    best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill PAR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP89(yr_ctr).PAR)); % find the rows that need to be filled

        switch best(kk)
            case 1
                TP89(yr_ctr).PAR(empty_rows) = pred39_89(yr_ctr).PAR(empty_rows);
            case 2
                TP89(yr_ctr).PAR(empty_rows) = pred74_89(yr_ctr).PAR(empty_rows);
            case 3
                TP89(yr_ctr).PAR(empty_rows) = pred89_89(yr_ctr).PAR(empty_rows);
            case 4
                TP89(yr_ctr).PAR(empty_rows) = pred02_89(yr_ctr).PAR(empty_rows);
        end

        clear empty_rows
    end
    filled_rows = find(TP89_PARtracker(1:length(TP89(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP89(yr_ctr).PAR));
    TP89_PARtracker(filled_rows,yr_ctr) = 2;
clear filled_rows;
    master_counter = master_counter + 1;
end

%% Fill gaps in TP02:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

    %%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));

    % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
    best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill PAR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP02(yr_ctr).PAR)); % find the rows that need to be filled

        switch best(kk)
            case 1
                TP02(yr_ctr).PAR(empty_rows) = pred39_02(yr_ctr).PAR(empty_rows);
            case 2
                TP02(yr_ctr).PAR(empty_rows) = pred74_02(yr_ctr).PAR(empty_rows);
            case 3
                TP02(yr_ctr).PAR(empty_rows) = pred89_02(yr_ctr).PAR(empty_rows);
            case 4
                TP02(yr_ctr).PAR(empty_rows) = pred02_02(yr_ctr).PAR(empty_rows);
        end

        clear empty_rows
    end
    filled_rows = find(TP02_PARtracker(1:length(TP02(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP02(yr_ctr).PAR));
    TP02_PARtracker(filled_rows,yr_ctr) = 2;
clear filled_rows;
    master_counter = master_counter + 1;
end

%% Final Check on the data -- see how it looks when filled in, and 

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
    
    figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP02 PAR ' num2str(j)]);
ind4 = find(TP02_PARtracker(1:length(TP02(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind4,TP02(yr_ctr).PAR(ind4,1),'gx-'); 

    figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP39 PAR ' num2str(j)]);
ind1 = find(TP39_PARtracker(1:length(TP39(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind1,TP39(yr_ctr).PAR(ind1,1),'gx-'); 

    figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP74 PAR ' num2str(j)]);
ind2 = find(TP74_PARtracker(1:length(TP74(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind2,TP74(yr_ctr).PAR(ind2,1),'gx-'); 
    
    figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP89 PAR ' num2str(j)]);   
ind3 = find(TP89_PARtracker(1:length(TP89(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind3,TP89(yr_ctr).PAR(ind3,1),'gx-'); 

clear ind1 ind2 ind3 ind4;

PAR_gaps(yr_ctr,:) = [length(find(TP39_PARtracker(1:17520,yr_ctr)==0)) length(find(TP74_PARtracker(1:17520,yr_ctr)==0)) ...
                      length(find(TP89_PARtracker(1:17520,yr_ctr)==0)) length(find(TP02_PARtracker(1:17520,yr_ctr)==0))];

PAR_fills(yr_ctr,:) = [length(find(TP39_PARtracker(1:17520,yr_ctr)==2)) length(find(TP74_PARtracker(1:17520,yr_ctr)==2)) ...
                      length(find(TP89_PARtracker(1:17520,yr_ctr)==2)) length(find(TP02_PARtracker(1:17520,yr_ctr)==2))];
              
end

%% SAVE files to filled directory

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);

    temp_02 = TP02(yr_ctr).PAR;
    save([save_path 'TP02/TP02_' num2str(j) '.PAR'],'temp_02','-ASCII')
    temp_39 = TP39(yr_ctr).PAR;
    save([save_path 'TP39/TP39_' num2str(j) '.PAR'],'temp_39','-ASCII')
    temp_74 = TP74(yr_ctr).PAR;
    save([save_path 'TP74/TP74_' num2str(j) '.PAR'],'temp_74','-ASCII')
    temp_89 = TP89(yr_ctr).PAR;
    save([save_path 'TP89/TP89_' num2str(j) '.PAR'],'temp_89','-ASCII')

    %%% Trackers    
temp_02_tracker = TP02_PARtracker(:,yr_ctr);
    save([tracker_path 'TP02/TP02_' num2str(j) 'PAR_tracker.dat'],'temp_02_tracker','-ASCII');
temp_39_tracker = TP39_PARtracker(:,yr_ctr);
    save([tracker_path 'TP39/TP39_' num2str(j) 'PAR_tracker.dat'],'temp_39_tracker','-ASCII');
    temp_74_tracker = TP74_PARtracker(:,yr_ctr);
    save([tracker_path 'TP74/TP74_' num2str(j) 'PAR_tracker.dat'],'temp_74_tracker','-ASCII');
    temp_89_tracker = TP89_PARtracker(:,yr_ctr);
    save([tracker_path 'TP89/TP89_' num2str(j) 'PAR_tracker.dat'],'temp_89_tracker','-ASCII');

    
    clear temp_*

end

 

