%% This script fills all met variables that must be continuous in order to 
%%% use for flux estimations.  In addition to filling the data file, a
%%% tracker file will be kept for each site, detailing what met data has
%%% been filled for each year.  Filling processes will be grouped by the
%%% variable that is being filled.  
%%%%% Please note that the method for fillinga particular variable may 
%%% change from year to year and site to site,depending on what data and 
%%% methods are available.  Each section will be documented accordingly.
%%%%% The following variables will be filled:
% 1) PAR
% 2) Air Temperature (Ta)
% 3) Soil Temperature (2cm & 5cm)
% 4) Relative Humidity (RH)
% 5) Atmospheric Pressure (APR)


%%% Created June 18, 2008 by JJB
%% Setting variables:
clear all; close all;

if ispc == 1;
    data_loc = 'C:/HOME/';
else
    data_loc = '/home/jayb/';
end

%%% Set Start and end years:
st_yr = 2003;
end_yr = 2007;
num_yrs = end_yr - st_yr + 1;
%%% Declare Paths:
load_path = [data_loc 'MATLAB/Data/Met/Final_Cleaned/'];
hdr_path = [data_loc 'MATLAB/Data/Met/Final_Cleaned/Headers/'];
save_path = [data_loc 'MATLAB/Data/Met/Final_Filled/'];
tracker_path = [data_loc 'MATLAB/Data/Flux/Met_Flux_Tracker/'];

%%% Load headers
hdr_TP02 = jjb_hdr_read([hdr_path 'TP02_CCP_List.csv'], ',', 2);
hdr_TP39 = jjb_hdr_read([hdr_path 'TP39_CCP_List.csv'], ',', 2);
hdr_TP74 = jjb_hdr_read([hdr_path 'TP74_CCP_List.csv'], ',', 2);
hdr_TP89 = jjb_hdr_read([hdr_path 'TP89_CCP_List.csv'], ',', 2);

colors = colormap(lines(num_yrs));

%% %%%%%%%%%%%%%%%%%%%%%%% RELATIVE HUMIDITY %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Create Tracker Files (all files start at zero, meaning no data exists):
TP02_APRtracker(1:17568,1:num_yrs) = 0; TP39_APRtracker(1:17568,1:num_yrs) = 0; 
TP74_APRtracker(1:17568,1:num_yrs) = 0; TP89_APRtracker(1:17568,1:num_yrs) = 0; 


for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
%     yr_list(yr_ctr,:) = num2str(j);
%%% Load all data:   
    TP02(yr_ctr).APR = jjb_load_var(hdr_TP02,[load_path 'TP02/TP02_' num2str(j) '.'],'APR',1);
    TP39(yr_ctr).APR = jjb_load_var(hdr_TP39,[load_path 'TP39/TP39_' num2str(j) '.'],'APR',1);
    TP74(yr_ctr).APR = jjb_load_var(hdr_TP74,[load_path 'TP74/TP74_' num2str(j) '.'],'APR',1);
    TP89(yr_ctr).APR = jjb_load_var(hdr_TP89,[load_path 'TP89/TP89_' num2str(j) '.'],'APR',1);
    
%%% Fill tracker files for rows where data exists:
TP02_APRtracker(~isnan(TP02(yr_ctr).APR),yr_ctr) = 1;
TP39_APRtracker(~isnan(TP39(yr_ctr).APR),yr_ctr) = 1;
TP74_APRtracker(~isnan(TP74(yr_ctr).APR),yr_ctr) = 1;
TP89_APRtracker(~isnan(TP89(yr_ctr).APR),yr_ctr) = 1;
    
figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).APR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP02 APR ' num2str(j)]);
figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).APR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP39 APR ' num2str(j)]);
figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).APR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP74 APR ' num2str(j)]);
figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).APR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP89 APR ' num2str(j)]);   
end



% 
% for j = st_yr :1 : end_yr
%     yr_ctr = j-(st_yr-1);
% 
% %%% Test how close each sensor is to the other:
%     % A1) TP39 & TP74
% 
%     figure(1)
%     subplot(4,2,yr_ctr); plot(TP39(yr_ctr).APR,TP74(yr_ctr).APR,'k.');title('TP39 vs TP74'); hold on;plot([-10 40],[-10 40],'r--');
%  
%     [p39_74(yr_ctr).APR pred39_74(yr_ctr).APR pw39_74(yr_ctr).APR pred_adj39_74(yr_ctr).APR] = Ts_fit(TP39(yr_ctr).APR, TP74(yr_ctr).APR);
% 
%     % A2) TP39 & TP89
%     figure(3)
%     subplot(4,2,yr_ctr); plot(TP39(yr_ctr).APR,TP89(yr_ctr).APR,'k.');title('TP39 vs TP89'); hold on;plot([-10 40],[-10 40],'r--');
% 
%     [p39_89(yr_ctr).APR pred39_89(yr_ctr).APR pw39_89(yr_ctr).APR pred_adj39_89(yr_ctr).APR] = Ts_fit(TP39(yr_ctr).APR, TP89(yr_ctr).APR);
% 
%     % A3) TP39 & TP02
%     figure(5)
%     subplot(4,2,yr_ctr); plot(TP39(yr_ctr).APR,TP02(yr_ctr).APR,'k.');title('TP39 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');
%     [p39_02(yr_ctr).APR pred39_02(yr_ctr).APR pw39_02(yr_ctr).APR pred_adj39_02(yr_ctr).APR] = Ts_fit(TP39(yr_ctr).APR, TP02(yr_ctr).APR);
%   
%    
%     % B1) TP74 & TP39
%     [p74_39(yr_ctr).APR pred74_39(yr_ctr).APR pw74_39(yr_ctr).APR pred_adj74_39(yr_ctr).APR] = Ts_fit(TP74(yr_ctr).APR, TP39(yr_ctr).APR);
% 
%     % B2) TP74 & TP89
%     figure(7)
%     subplot(4,2,yr_ctr); plot(TP74(yr_ctr).APR,TP89(yr_ctr).APR,'k.');title('TP74 vs TP89'); hold on;plot([-10 40],[-10 40],'r--');
%     [p74_89(yr_ctr).APR pred74_89(yr_ctr).APR pw74_89(yr_ctr).APR pred_adj74_89(yr_ctr).APR] = Ts_fit(TP74(yr_ctr).APR, TP89(yr_ctr).APR);
% 
%     % B3) TP74 & TP02
%     figure(9)
%     subplot(4,2,yr_ctr); plot(TP74(yr_ctr).APR,TP02(yr_ctr).APR,'k.');title('TP74 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');
%     
%     [p74_02(yr_ctr).APR pred74_02(yr_ctr).APR pw74_02(yr_ctr).APR pred_adj74_02(yr_ctr).APR] = Ts_fit(TP74(yr_ctr).APR, TP02(yr_ctr).APR);
%     
%     % C1) TP89 & TP39
%     [p89_39(yr_ctr).APR pred89_39(yr_ctr).APR pw89_39(yr_ctr).APR pred_adj89_39(yr_ctr).APR] = Ts_fit(TP89(yr_ctr).APR, TP39(yr_ctr).APR);
% 
%     % C2) TP89 & TP74
%     [p89_74(yr_ctr).APR pred89_74(yr_ctr).APR pw89_74(yr_ctr).APR pred_adj89_74(yr_ctr).APR] = Ts_fit(TP89(yr_ctr).APR, TP74(yr_ctr).APR);
%    
%     % C3) TP89 & TP02
%     figure(11)
%     subplot(4,2,yr_ctr); plot(TP89(yr_ctr).APR,TP02(yr_ctr).APR,'k.');title('TP89 vs TP02'); hold on;plot([-10 40],[-10 40],'r--');
% 
%     [p89_02(yr_ctr).APR pred89_02(yr_ctr).APR pw89_02(yr_ctr).APR pred_adj89_02(yr_ctr).APR] = Ts_fit(TP89(yr_ctr).APR, TP02(yr_ctr).APR);
% 
%     % D1) TP02 & TP39
%     [p02_39(yr_ctr).APR pred02_39(yr_ctr).APR pw02_39(yr_ctr).APR pred_adj02_39(yr_ctr).APR] = Ts_fit(TP02(yr_ctr).APR, TP39(yr_ctr).APR);
% 
%     % D2) TP02 & T74
%     [p02_74(yr_ctr).APR pred02_74(yr_ctr).APR pw02_74(yr_ctr).APR pred_adj02_74(yr_ctr).APR] = Ts_fit(TP02(yr_ctr).APR, TP74(yr_ctr).APR);
%     
%     % D3) TP02 & T89
%     [p02_89(yr_ctr).APR pred02_89(yr_ctr).APR pw02_89(yr_ctr).APR pred_adj02_89(yr_ctr).APR] = Ts_fit(TP02(yr_ctr).APR, TP89(yr_ctr).APR);
% 
% end
% for j = st_yr : 1 : end_yr
%     yr_ctr = j-(st_yr-1);
%     
%  master_slope_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).APR(1)      p39_89(yr_ctr).APR(1)     p39_02(yr_ctr).APR(1)] ;
%  master_slope_TP74(yr_ctr,:) = [p74_39(yr_ctr).APR(1) zeros.*ones(1,1)           p74_89(yr_ctr).APR(1)     p74_02(yr_ctr).APR(1)] ;
%  master_slope_TP89(yr_ctr,:) = [p89_39(yr_ctr).APR(1) p89_74(yr_ctr).APR(1)      zeros.*ones(1,1)          p89_02(yr_ctr).APR(1)] ;
%  master_slope_TP02(yr_ctr,:) = [p02_39(yr_ctr).APR(1) p02_74(yr_ctr).APR(1)      p02_89(yr_ctr).APR(1)     zeros.*ones(1,1)     ] ;
%     
%  master_r2_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).APR(3)      p39_89(yr_ctr).APR(3)     p39_02(yr_ctr).APR(3)] ;
%  master_r2_TP74(yr_ctr,:) = [p74_39(yr_ctr).APR(3) zeros.*ones(1,1)           p74_89(yr_ctr).APR(3)     p74_02(yr_ctr).APR(3)] ;
%  master_r2_TP89(yr_ctr,:) = [p89_39(yr_ctr).APR(3) p89_74(yr_ctr).APR(3)      zeros.*ones(1,1)          p89_02(yr_ctr).APR(3)] ;
%  master_r2_TP02(yr_ctr,:) = [p02_39(yr_ctr).APR(3) p02_74(yr_ctr).APR(3)      p02_89(yr_ctr).APR(3)     zeros.*ones(1,1)     ] ;
% 
%  master_r2adj_TP39(yr_ctr,:) = [zeros.*ones(1,1)      p39_74(yr_ctr).APR(4)      p39_89(yr_ctr).APR(4)     p39_02(yr_ctr).APR(4)] ;
%  master_r2adj_TP74(yr_ctr,:) = [p74_39(yr_ctr).APR(4) zeros.*ones(1,1)           p74_89(yr_ctr).APR(4)     p74_02(yr_ctr).APR(4)] ;
%  master_r2adj_TP89(yr_ctr,:) = [p89_39(yr_ctr).APR(4) p89_74(yr_ctr).APR(4)      zeros.*ones(1,1)          p89_02(yr_ctr).APR(4)] ;
%  master_r2adj_TP02(yr_ctr,:) = [p02_39(yr_ctr).APR(4) p02_74(yr_ctr).APR(4)      p02_89(yr_ctr).APR(4)     zeros.*ones(1,1)     ] ;
%  
% end
%  
%  master_slope = [master_slope_TP39; master_slope_TP74; master_slope_TP89; master_slope_TP02 ];
% 
%  master_r2 = [master_r2_TP39; master_r2_TP74; master_r2_TP89; master_r2_TP02 ];
% 
%  master_r2adj = [master_r2adj_TP39; master_r2adj_TP74; master_r2adj_TP89; master_r2adj_TP02 ];

%% FILL GAPS:
master_counter = 1;

%% Fill gaps in TP39
for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

%     %%% sort the r2 values to find best site data to fill it with:
%     [a, ix] = sort(master_r2(master_counter,:));
% 
%     % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
%     best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill APR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP39(yr_ctr).APR)); % find the rows that need to be filled

        switch kk
            case 1
                TP39(yr_ctr).APR(empty_rows) = TP74(yr_ctr).APR(empty_rows);
            case 2
                TP39(yr_ctr).APR(empty_rows) = TP89(yr_ctr).APR(empty_rows);
            case 3
                TP39(yr_ctr).APR(empty_rows) = TP02(yr_ctr).APR(empty_rows);
        end

        clear empty_rows
    end
    %% Last Resort to Fill:
         empty_rows = find(isnan(TP39(yr_ctr).APR)); % find the rows that need to be filled
   TP39(yr_ctr).APR(empty_rows) = 99;
         
    filled_rows = find(TP39_APRtracker(1:length(TP39(yr_ctr).APR),yr_ctr) == 0  & ~isnan(TP39(yr_ctr).APR));
    TP39_APRtracker(filled_rows,yr_ctr) = 2;
    clear filled_rows
    master_counter = master_counter + 1;
end

%% Fill gaps in TP74:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

%     %%% sort the r2 values to find best site data to fill it with:
%     [a, ix] = sort(master_r2(master_counter,:));
% 
%     % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
%     best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill APR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP74(yr_ctr).APR)); % find the rows that need to be filled

        switch kk
            case 1
                TP74(yr_ctr).APR(empty_rows) = TP39(yr_ctr).APR(empty_rows);
            case 2
                TP74(yr_ctr).APR(empty_rows) = TP89(yr_ctr).APR(empty_rows);
            case 3
                TP74(yr_ctr).APR(empty_rows) = TP02(yr_ctr).APR(empty_rows);
        end

        clear empty_rows
    end
        %% Last Resort to Fill:
         empty_rows = find(isnan(TP39(yr_ctr).APR)); % find the rows that need to be filled
   TP39(yr_ctr).APR(empty_rows) = 99;

    
    filled_rows = find(TP74_APRtracker(1:length(TP74(yr_ctr).APR),yr_ctr) == 0  & ~isnan(TP74(yr_ctr).APR));
    TP74_APRtracker(filled_rows,yr_ctr) = 2;


    clear filled_rows
    master_counter = master_counter + 1;
end


%% Fill gaps in TP89:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

%     %%% sort the r2 values to find best site data to fill it with:
%     [a, ix] = sort(master_r2(master_counter,:));
% 
%     % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
%     best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill APR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP89(yr_ctr).APR)); % find the rows that need to be filled

        switch kk
            case 1
                TP89(yr_ctr).APR(empty_rows) = TP39(yr_ctr).APR(empty_rows);
            case 2
                TP89(yr_ctr).APR(empty_rows) = TP74(yr_ctr).APR(empty_rows);
            case 3
                TP89(yr_ctr).APR(empty_rows) = TP02(yr_ctr).APR(empty_rows);
        end

        clear empty_rows
    end
        %% Last Resort to Fill:
         empty_rows = find(isnan(TP39(yr_ctr).APR)); % find the rows that need to be filled
   TP39(yr_ctr).APR(empty_rows) = 99;

    filled_rows = find(TP89_APRtracker(1:length(TP89(yr_ctr).APR),yr_ctr) == 0  & ~isnan(TP89(yr_ctr).APR));
    TP89_APRtracker(filled_rows,yr_ctr) = 2;
clear filled_rows;
    master_counter = master_counter + 1;
end

%% Fill gaps in TP02:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);

%     %%% sort the r2 values to find best site data to fill it with:
%     [a, ix] = sort(master_r2(master_counter,:));
% 
%     % best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
%     best = [ix(4) ix(3) ix(2)]; % order of site data to use:

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fill APR %%%%%%%%%%%%%%%%%%%%%%%%%
    for kk = 1:1:3

        empty_rows = find(isnan(TP02(yr_ctr).APR)); % find the rows that need to be filled

        switch kk
            case 1
                TP02(yr_ctr).APR(empty_rows) = TP39(yr_ctr).APR(empty_rows);
            case 2
                TP02(yr_ctr).APR(empty_rows) = TP74(yr_ctr).APR(empty_rows);
            case 3
                TP02(yr_ctr).APR(empty_rows) = TP89(yr_ctr).APR(empty_rows);
        end

        clear empty_rows
    end
        %% Last Resort to Fill:
         empty_rows = find(isnan(TP39(yr_ctr).APR)); % find the rows that need to be filled
   TP39(yr_ctr).APR(empty_rows) = 99;

    filled_rows = find(TP02_APRtracker(1:length(TP02(yr_ctr).APR),yr_ctr) == 0  & ~isnan(TP02(yr_ctr).APR));
    TP02_APRtracker(filled_rows,yr_ctr) = 2;
clear filled_rows;
    master_counter = master_counter + 1;
end
%% Final Check on the data -- see how it looks when filled in, and 

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
    
    figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).APR,'-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP02 APR ' num2str(j)]);
ind4 = find(TP02_APRtracker(1:length(TP02(yr_ctr).APR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind4,TP02(yr_ctr).APR(ind4,1),'g-'); 

    figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).APR,'-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP39 APR ' num2str(j)]);
ind1 = find(TP39_APRtracker(1:length(TP39(yr_ctr).APR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind1,TP39(yr_ctr).APR(ind1,1),'g-'); 

    figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).APR,'-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP74 APR ' num2str(j)]);
ind2 = find(TP74_APRtracker(1:length(TP74(yr_ctr).APR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind2,TP74(yr_ctr).APR(ind2,1),'g-'); 
    
    figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).APR,'-','Color',colors(yr_ctr,:)); axis([1 17568 95 105]); title(['TP89 APR ' num2str(j)]);   
ind3 = find(TP89_APRtracker(1:length(TP89(yr_ctr).APR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind3,TP89(yr_ctr).APR(ind3,1),'g-'); 

clear ind1 ind2 ind3 ind4;

APR_gaps(yr_ctr,:) = [length(find(TP39_APRtracker(1:17520,yr_ctr)==0)) length(find(TP74_APRtracker(1:17520,yr_ctr)==0)) ...
                      length(find(TP89_APRtracker(1:17520,yr_ctr)==0)) length(find(TP02_APRtracker(1:17520,yr_ctr)==0))];

APR_fills(yr_ctr,:) = [length(find(TP39_APRtracker(1:17520,yr_ctr)==2)) length(find(TP74_APRtracker(1:17520,yr_ctr)==2)) ...
                      length(find(TP89_APRtracker(1:17520,yr_ctr)==2)) length(find(TP02_APRtracker(1:17520,yr_ctr)==2))];
              
end

%% SAVE files to filled directory

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);

    temp_02 = TP02(yr_ctr).APR;
    save([save_path 'TP02/TP02_' num2str(j) '.APR'],'temp_02','-ASCII')
    temp_39 = TP39(yr_ctr).APR;
    save([save_path 'TP39/TP39_' num2str(j) '.APR'],'temp_39','-ASCII')
    temp_74 = TP74(yr_ctr).APR;
    save([save_path 'TP74/TP74_' num2str(j) '.APR'],'temp_74','-ASCII')
    temp_89 = TP89(yr_ctr).APR;
    save([save_path 'TP89/TP89_' num2str(j) '.APR'],'temp_89','-ASCII')
%%% Trackers    
temp_02_tracker = TP02_APRtracker(:,yr_ctr);
    save([tracker_path 'TP02/TP02_' num2str(j) 'APR_tracker.dat'],'temp_02_tracker','-ASCII');
temp_39_tracker = TP39_APRtracker(:,yr_ctr);
    save([tracker_path 'TP39/TP39_' num2str(j) 'APR_tracker.dat'],'temp_39_tracker','-ASCII');
    temp_74_tracker = TP74_APRtracker(:,yr_ctr);
    save([tracker_path 'TP74/TP74_' num2str(j) 'APR_tracker.dat'],'temp_74_tracker','-ASCII');
    temp_89_tracker = TP89_APRtracker(:,yr_ctr);
    save([tracker_path 'TP89/TP89_' num2str(j) 'APR_tracker.dat'],'temp_89_tracker','-ASCII');
    
    clear temp_*

end

