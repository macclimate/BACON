%% Testing mcm_metfill.m
% Load cleaned data for 2005:

loadpath = addpath_loadstart;

TP39_Ta = load([loadstart 'Matlab/Data/Met/Final_Cleaned/TP39/TP39_2008.036']);
TP74_Ta = load([loadstart 'Matlab/Data/Met/Final_Cleaned/TP74/TP74_2008.030']);
TP89_Ta = load([loadstart 'Matlab/Data/Met/Final_Cleaned/TP89/TP89_2008.030']);
TP02_Ta = load([loadstart 'Matlab/Data/Met/Final_Cleaned/TP02/TP02_2008.030']);
% just make sure right vars:
figure(1); clf;
plot(TP39_Ta,'k'); hold on;
plot(TP74_Ta,'b');
plot(TP89_Ta,'r');
plot(TP02_Ta,'g');

[TP39_filled TP74_filled TP89_filled TP02_filled tracker] = mcm_metfill(TP39_Ta, TP74_Ta, TP89_Ta, TP02_Ta);



