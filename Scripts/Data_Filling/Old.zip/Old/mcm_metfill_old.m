% function [] = mcm_metfill(year)
% clear all;
% close all;
%{TP39_filled TP74_filled TP89_filled TP02_filled tracker
% if ischar(year)
% else
%     year = num2str(year);
% end
loadstart = addpath_loadstart;
site_labels = ['TP39'; 'TP74';'TP89'; 'TP02'];

%%% Header Path for Cleaned data -- 2008 onwards:
hdr_path = [loadstart 'Matlab/Data/Met/Raw1/Docs/'];
%%% Header Path for Cleaned data -- before 2008 (2003-2007):
hdr_path_pre2008 = [loadstart 'Matlab/Data/Met/Final_Cleaned/CCP/Headers/'];

% %%% Save Path
% output_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/' site '/'];

TP39 = []; TP89 = []; TP74 = []; TP02 = [];

%% Load data for 2003--2007:
for i = 1:1:length(site_labels)
    site = site_labels(i,:);
    %%%% Load Header
    data(1).header = jjb_hdr_read([hdr_path_pre2008 site '_CCP_Names.csv'], ',', 2);

    for year = 2003:1:2007
        %%%% Load Path
        temp(1).load_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/CCP/' site '/' site '_' num2str(year) '.'];


        %%%% Load Variables
        temp(1).Ta = jjb_load_var(data(1).header, temp(1).load_path, 'AirTemp_AbvCnpy',2);
        temp(1).RH = jjb_load_var(data(1).header, temp(1).load_path, 'RelHum_AbvCnpy',2);
        temp(1).PAR = jjb_load_var(data(1).header, temp(1).load_path, 'DownPAR_AbvCnpy',2);
        temp(1).WS = jjb_load_var(data(1).header, temp(1).load_path, 'WindSpd',2);
        temp(1).Wdir = jjb_load_var(data(1).header, temp(1).load_path, 'WindDir',2);
        temp(1).Ts5 = jjb_load_var(data(1).header, temp(1).load_path, 'SoilTemp_A_5cm',2);
        try
            temp(1).APR = jjb_load_var(data(1).header, temp(1).load_path, 'Pressure',2);
        catch
            temp(1).APR = NaN.*ones(length(temp(1).Ta),1);
        end

        eval([site ' = [' site ' ; year.*ones(length(temp(1).Ta),1) temp(1).Ta temp(1).RH temp(1).PAR temp(1).WS temp(1).Ts5 temp(1).APR temp(1).Wdir];' ]);

        clear temp
    end

end

clear data;

%% Load Data 2008-- onwards;

for year = 2008 % expand for more years
   

    for i = 1:1:length(site_labels);
        site = site_labels(i,:);
         %%%% Load Header
        data(1).header = jjb_hdr_read([hdr_path site '_OutputTemplate.csv'], ',', 3);
        %%%% Load Path
        temp(1).load_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/' site '/' site '_' num2str(year) '.'];

        %%%% Load Variables
        temp(1).Ta = jjb_load_var(data(1).header, temp(1).load_path, 'AirTemp_AbvCnpy',2);
        temp(1).RH = jjb_load_var(data(1).header, temp(1).load_path, 'RelHum_AbvCnpy',2);
        temp(1).PAR = jjb_load_var(data(1).header, temp(1).load_path, 'DownPAR_AbvCnpy',2);
        temp(1).WS = jjb_load_var(data(1).header, temp(1).load_path, 'WindSpd',2);
        temp(1).Wdir = jjb_load_var(data(1).header, temp(1).load_path, 'WindDir',2);
        temp(1).Ts5 = jjb_load_var(data(1).header, temp(1).load_path, 'SoilTemp_A_5cm',2);
        try
            temp(1).APR = jjb_load_var(data(1).header, temp(1).load_path, 'Pressure',2);
        catch
            temp(1).APR = NaN.*ones(length(temp(1).Ta),1);
        end

        eval([site ' = [' site ' ; year.*ones(length(temp(1).Ta),1) temp(1).Ta temp(1).RH temp(1).PAR temp(1).WS temp(1).Ts5 temp(1).APR temp(1).Wdir];' ]);

        clear temp


    end
end


% %
% % data(i).Ta = jjb_load_var(data(i).header, data(i).load_path, 'AirTemp_AbvCnpy',2);
% % data(i).RH = jjb_load_var(data(i).header, data(i).load_path, 'RelHum_AbvCnpy',2);
% % data(i).PAR = jjb_load_var(data(i).header, data(i).load_path, 'DownPAR_AbvCnpy',2);
% % data(i).WS = jjb_load_var(data(i).header, data(i).load_path, 'WindSpd',2);
% % data(i).Wdir = jjb_load_var(data(i).header, data(i).load_path, 'WindDir',2);
% % data(i).Ts5 = jjb_load_var(data(i).header, data(i).load_path, 'SoilTemp_A_5cm',2);
% % try
% % data(i).APR = jjb_load_var(data(i).header, data(i).load_path, 'Pressure',2);
% % catch
% %     data(i).APR = NaN.*ones(length(data(1).Ta),1);
% % end
% % end
%
%
% % Load Variables:
% for i = 1:1:length(site_labels);
%     site = site_labels(i,:);
% eval([site ' = [data(i).Ta data(i).RH data(i).PAR data(i).WS data(i).Ts5 data(i).APR data(i).Wdir];' ]);
% end


varnames(1,1) = cellstr('AirTemp_AbvCnpy'); varnames(2,1) = cellstr('RelHum_AbvCnpy'); varnames(3,1) = cellstr('DownPAR_AbvCnpy');
varnames(4,1) = cellstr('WindSpd'); varnames(5,1) = cellstr('SoilTemp_A_5cm'); varnames(6,1) = cellstr('Pressure');



% eval([char(sites(i,1)) '.load_path' = [loadstart 'Matlab/Data/Met/Cleaned3/' char(sites(i,1)) '/']]);
% TP39.load_path = [loadstart 'Matlab/Data/Met/Cleaned3/' char(sites(1,1)) '/'];
%

% header = jjb_hdr_read([hdr_path site '_OutputTemplate.csv'], ',', 3);




%%% Do some last-minute adjustments (in case timecodes are different
%%% between sites)
% For example, 2008 -- TP39, TP89 is in EDT, TP02, TP74 is in UTC

        ind_2008 = find(TP39(:,1) == 2008);
TP39_2008 = TP39(ind_2008,:);
TP89_2008 = TP89(ind_2008,:);

        [rows cols] = size(TP39_2008);
        
TP39_2008_UTC = [2008.*ones(8,1) NaN.*ones(8,cols-1); TP39_2008(1:length(ind_2008)-8,:)];


TP89_2008_UTC = [2008.*ones(8,1) NaN.*ones(8,cols-1); TP89_2008(1:length(ind_2008)-8,:)];

TP39(ind_2008,:) = TP39_2008_UTC(:,:);
TP89(ind_2008,:) = TP89_2008_UTC(:,:);

%% Let's fix some offsets in the data (still!!!!)
TP74(74471:75860,5) = NaN; % Bad data during 2007 for WS -- reading zero (need to fix in master data file also)
% TP39_temp = NaN.*ones(length(TP39),cols);
TP39_temp = [TP39(1:12131,:); TP39(12133:13160,:); NaN.*ones(1,8); TP39(13161:35105,:); NaN.*ones(1,8); TP39(35106:52598,:); TP39(52600:55755,:) ; TP39(55757:62250,:) ; NaN.*ones(1,8); TP39(62251:64439,:) ; TP39(64441:65491,:); NaN.*ones(1,8); TP39(65492:end,:)];
TP89_temp = [TP89(1:30369,:); TP89(30371:35088,:); NaN.*ones(1,8); TP89(35089:end,:)];
TP02_temp = [TP02(2:12898,:); NaN.*ones(1,8); TP02(12899:20475,:);  TP02(20478:21097,:); NaN.*ones(2,8); TP02(21098:end,:)];

clear TP39 TP89 TP02

TP39 = TP39_temp; TP89 = TP89_temp; TP02 = TP02_temp;
clear TP39_temp TP89_temp TP02_temp;

%%
for t = 2:1:cols
    figure(1); subplot(3,3,t-1); plot(TP39(:,t));
    figure(2); subplot(3,3,t-1); plot(TP74(:,t));    
    figure(3); subplot(3,3,t-1); plot(TP89(:,t));
    figure(4); subplot(3,3,t-1); plot(TP02(:,t));
end


%%
        TP39_filled = NaN.*ones(length(TP39),cols);
        TP74_filled = NaN.*ones(length(TP74),cols);
        TP89_filled = NaN.*ones(length(TP89),cols);
        TP02_filled = NaN.*ones(length(TP02),cols);


             [TP39_test TP74_test TP89_test TP02_test] = mcm_fillvars(TP39(TP39(:,1)==2008,3), TP74(TP39(:,1)==2008,3), TP89(TP39(:,1)==2008,3), TP02(TP39(:,1)==2008,3));

        for k = 2:1:5
            tic;
            [TP39_filled(:,k) TP74_filled(:,k) TP89_filled(:,k) TP02_filled(:,k)] = mcm_fillvars(TP39(:,k), TP74(:,k), TP89(:,k), TP02(:,k));

            t = toc;
            disp(['one variable finished in ' num2str(t) ' seconds']);
        end


TP39_filled(isnan(TP39_filled)) = TP39(isnan(TP39_filled));
TP74_filled(isnan(TP74_filled)) = TP74(isnan(TP74_filled));
TP89_filled(isnan(TP89_filled)) = TP89(isnan(TP89_filled));
TP02_filled(isnan(TP02_filled)) = TP02(isnan(TP02_filled));


figure(1); clf;
plot(TP74(:,4),'b.-'); hold on;
plot(TP02(:,4),'r.-');
plot(TP39(:,4),'g.-');
plot(TP89(:,4),'c.-');

figure(2); clf;
plot(TP74(:,2),'b.-'); hold on;
plot(TP02(:,2),'r.-');
plot(TP39(:,2),'g.-');
plot(TP89(:,2),'c.-');

figure(3); clf;
plot(TP74(:,5),'b.-'); hold on;
plot(TP02(:,5),'r.-');
plot(TP39(:,5),'g.-');
plot(TP89(:,5),'c.-');



figure('Name','TP39','NumberTitle','off'); clf;
for k = 2:1:5
    subplot(2,3,k)
    plot(TP39_filled(:,k),'b');hold on;
    plot(TP39(:,k),'r');
    title(char(varnames(k-1,1)))
end


figure('Name','TP74','NumberTitle','off'); clf;
for k = 2:1:5
    subplot(2,3,k)
    plot(TP74_filled(:,k),'b');hold on;
    plot(TP74(:,k),'r');
    title(char(varnames(k-1,1)))
end


figure('Name','TP89','NumberTitle','off'); clf;
for k = 2:1:5
    subplot(2,3,k)
    plot(TP89_filled(:,k),'b');hold on;
    plot(TP89(:,k),'r');
    title(char(varnames(k-1,1)))
end


figure('Name','TP02','NumberTitle','off'); clf;
for k = 1:1:6
    subplot(2,3,k)
    plot(TP02_filled(:,k),'b');hold on;
    plot(TP02(:,k),'r');
    title(char(varnames(k,1)))
end
