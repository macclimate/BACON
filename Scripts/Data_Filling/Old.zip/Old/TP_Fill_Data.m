%% TP_Fill_Data
clear all
close all

TP_APRfill

TP_PARfill

TP_Tafill

TP_Tsfill

TP_RHfill

TP_SMfill
