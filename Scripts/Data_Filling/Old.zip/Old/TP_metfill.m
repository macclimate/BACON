%% This script fills all met variables that must be continuous in order to 
%%% use for flux estimations.  In addition to filling the data file, a
%%% tracker file will be kept for each site, detailing what met data has
%%% been filled for each year.  Filling processes will be grouped by the
%%% variable that is being filled.  
%%%%% Please note that the method for fillinga particular variable may 
%%% change from year to year and site to site,depending on what data and 
%%% methods are available.  Each section will be documented accordingly.
%%%%% The following variables will be filled:
% 1) PAR
% 2) Air Temperature (Ta)
% 3) Soil Temperature (2cm & 5cm)
% 4) Relative Humidity (RH)
% 5) 


%%% Created June 18, 2008 by JJB
%% Setting variables:

if ispc == 1;
    dataloc = 'C:/HOME/';
else
    dataloc = '/home/jayb/';
end

%%% Set Start and end years:
st_yr = 2003;
end_yr = 2007;
num_yrs = end_yr - st_yr + 1;
%%% Declare Paths:
load_path = [dataloc 'MATLAB/Data/Met/Final_Cleaned/'];
hdr_path = [dataloc 'MATLAB/Data/Met/Final_Cleaned/Headers/'];


%%% Load headers
hdr_TP02 = jjb_hdr_read([hdr_path 'TP02_CCP_List.csv'], ',', 2);
hdr_TP39 = jjb_hdr_read([hdr_path 'TP39_CCP_List.csv'], ',', 2);
hdr_TP74 = jjb_hdr_read([hdr_path 'TP74_CCP_List.csv'], ',', 2);
hdr_TP89 = jjb_hdr_read([hdr_path 'TP89_CCP_List.csv'], ',', 2);

%%% Create Tracker Files (all files start at zero, meaning no data exists):
TP02_PARtracker(1:17568,1:num_yrs) = 0; TP39_PARtracker(1:17568,1:num_yrs) = 0; 
TP74_PARtracker(1:17568,1:num_yrs) = 0; TP89_PARtracker(1:17568,1:num_yrs) = 0; 

%% 1) PAR:
colors = colormap(lines(num_yrs));

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
%     yr_list(yr_ctr,:) = num2str(j);
%%% Load all data:   
    TP02(yr_ctr).PAR = jjb_load_var(hdr_TP02,[load_path 'TP02/TP02_' num2str(j) '.'],'PARdown_3m',1);
    TP39(yr_ctr).PAR = jjb_load_var(hdr_TP39,[load_path 'TP39/TP39_' num2str(j) '.'],'PARdown_28m',1);
    TP74(yr_ctr).PAR = jjb_load_var(hdr_TP74,[load_path 'TP74/TP74_' num2str(j) '.'],'PARdown_15m',1);
    TP89(yr_ctr).PAR = jjb_load_var(hdr_TP89,[load_path 'TP89/TP89_' num2str(j) '.'],'PARdown_12m',1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%% Clean bottom of data (remove this part after CCP_output is run once again)
    TP02(yr_ctr).PAR(TP02(yr_ctr).PAR(:,1) < 20,1) = 0;
    TP39(yr_ctr).PAR(TP39(yr_ctr).PAR(:,1) < 10,1) = 0;
    TP74(yr_ctr).PAR(TP74(yr_ctr).PAR(:,1) < 10,1) = 0;
    TP89(yr_ctr).PAR(TP89(yr_ctr).PAR(:,1) < 10,1) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    
%%% Fill tracker files for rows where data exists:
TP02_PARtracker(~isnan(TP02(yr_ctr).PAR),yr_ctr) = 1;
TP39_PARtracker(~isnan(TP39(yr_ctr).PAR),yr_ctr) = 1;
TP74_PARtracker(~isnan(TP74(yr_ctr).PAR),yr_ctr) = 1;
TP89_PARtracker(~isnan(TP89(yr_ctr).PAR),yr_ctr) = 1;
    
figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP02 PAR ' num2str(j)]);
figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP39 PAR ' num2str(j)]);
figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP74 PAR ' num2str(j)]);
figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,'x-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP89 PAR ' num2str(j)]);   
end

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);

%%% Test how close each sensor is to the other:
% A) TP39 vs TP74
figure(5)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP74(yr_ctr).PAR,'k.');title('TP39 vs TP74'); hold on;plot([0 2500],[0 2500],'r--');
p39_74(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0) ,TP74(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_74(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0) ,TP74(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0));

figure(6)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP39 vs TP89');hold on;plot([0 2500],[0 2500],'r--');
p39_89(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_89(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0));

figure(7)
subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP39 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p39_02(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p39_02(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

figure(8)
subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP89(yr_ctr).PAR,'k.');title('TP74 vs TP89');hold on;plot([0 2500],[0 2500],'r--');
p74_89(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p74_89(yr_ctr,3) = rsquared(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0));

figure(9)
subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP74 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p74_02(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p74_02(yr_ctr,3) = rsquared(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

figure(10)
subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,TP02(yr_ctr).PAR,'k.');title('TP89 vs TP02');hold on;plot([0 2500],[0 2500],'r--');
p89_02(yr_ctr,1:2) = mmpolyfit(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
p89_02(yr_ctr,3) = rsquared(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0));

end

%%% At this point, I believe what we want to do is standardize everything
%%% by the regression with TP39, and then use the r-squared values to
%%% determine which site the data should be filled in from.  Scratch that,
%%% perhaps I will only adjust TP02 data for 2003-(early)2006 so that they match
%%% up with PAR measured after that (sensor was adjusted in 2006,
%%% resulting in higher amplitudes and closer similarity with TP39.
for k = 1:1:4
if k == 4
    TP02(k).PAR(1:7371,1) = (TP02(k).PAR(1:7371,1)./p39_02(k,1)).*p39_02(5,1);
else
    TP02(k).PAR = (TP02(k).PAR./p39_02(k,1)).*p39_02(5,1);
end
end

%% recalculate slope and rsquared
for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% Test how close each sensor is to the other:
% A) TP39 vs TP74
p39_74(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0) ,TP74(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP74(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred39_74 = polyval(p39_74(yr_ctr,1:2),TP39(yr_ctr).PAR);
p39_74(yr_ctr,3) = rsquared(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & pred39_74 > 0) ,pred39_74(TP74(yr_ctr).PAR > 0 & pred39_74 > 0));

p39_89(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred39_89 = polyval(p39_89(yr_ctr,1:2),TP39(yr_ctr).PAR);
% p39_89(yr_ctr,3) = rsquared(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0));
p39_89(yr_ctr,3) = rsquared(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & pred39_89 > 0) ,pred39_89(TP89(yr_ctr).PAR > 0 & pred39_89 > 0));

p39_02(yr_ctr,1:2) = mmpolyfit(TP39(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP39(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred39_02 = polyval(p39_02(yr_ctr,1:2),TP39(yr_ctr).PAR);
p39_02(yr_ctr,3) = rsquared(TP02(yr_ctr).PAR(TP02(yr_ctr).PAR > 0 & pred39_02 > 0) ,pred39_02(TP02(yr_ctr).PAR > 0 & pred39_02 > 0));

p74_89(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0) ,TP89(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP89(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred74_89 = polyval(p74_89(yr_ctr,1:2),TP74(yr_ctr).PAR);
p74_89(yr_ctr,3) = rsquared(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & pred74_89 > 0) ,pred74_89(TP89(yr_ctr).PAR > 0 & pred74_89 > 0));

p74_02(yr_ctr,1:2) = mmpolyfit(TP74(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP74(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred74_02 = polyval(p74_02(yr_ctr,1:2),TP74(yr_ctr).PAR);
p74_02(yr_ctr,3) = rsquared(TP02(yr_ctr).PAR(TP02(yr_ctr).PAR > 0 & pred74_02 > 0) ,pred74_02(TP02(yr_ctr).PAR > 0 & pred74_02 > 0));

p89_02(yr_ctr,1:2) = mmpolyfit(TP89(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0) ,TP02(yr_ctr).PAR(TP89(yr_ctr).PAR > 0 & TP02(yr_ctr).PAR > 0),1,'ZeroCoef',0);
pred89_02 = polyval(p89_02(yr_ctr,1:2),TP89(yr_ctr).PAR);
p89_02(yr_ctr,3) = rsquared(TP02(yr_ctr).PAR(TP02(yr_ctr).PAR > 0 & pred89_02 > 0) ,pred89_02(TP02(yr_ctr).PAR > 0 & pred89_02 > 0));

clear pred*

end



%% Make a list of r2 and slope values:
master_slope = [zeros.*ones(5,1)              p39_74(:,1)      p39_89(:,1)          p39_02(:,1); ...
                1./p39_74(:,1)           zeros.*ones(5,1)     p74_89(:,1)          p74_02(:,1); ...
                1./p39_89(:,1)           1./p74_89(:,1)         zeros.*ones(5,1)    p89_02(:,1); ...
                1./p39_02(:,1)           1./p74_02(:,1)       1./p89_02(:,1)      zeros.*ones(5,1)];

master_r2 = [zeros.*ones(5,1)              p39_74(:,3)      p39_89(:,3)          p39_02(:,3); ...
                p39_74(:,3)           zeros.*ones(5,1)     p74_89(:,3)          p74_02(:,3); ...
                p39_89(:,3)           p74_89(:,3)         zeros.*ones(5,1)    p89_02(:,3); ...
                p39_02(:,3)           p74_02(:,3)       p89_02(:,3)      zeros.*ones(5,1)];

master_int = [zeros.*ones(5,1)              p39_74(:,2)      p39_89(:,2)          p39_02(:,2); ...
                p39_74(:,2).*-1           zeros.*ones(5,1)     p74_89(:,2)          p74_02(:,2); ...
                p39_89(:,2).*-1           p74_89(:,2).*-1         zeros.*ones(5,1)    p89_02(:,2); ...
                p39_02(:,2).*-1           p74_02(:,2).*-1       p89_02(:,2).*-1      zeros.*ones(5,1)];

            
            
            
master_counter = 1;  

%% Fill gaps in TP39            

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));
% best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
best = [ix(4) ix(3) ix(2)]; % order of site data to use:

for kk = 1:1:3

    empty_rows = find(isnan(TP39(yr_ctr).PAR)); % find the rows that need to be filled
    
    switch best(kk)
        case 1
    TP39(yr_ctr).PAR(empty_rows) = (TP39(yr_ctr).PAR(empty_rows)./master_slope(master_counter,1));
        case 2
    TP39(yr_ctr).PAR(empty_rows) = (TP74(yr_ctr).PAR(empty_rows)./master_slope(master_counter,2));
        case 3
    TP39(yr_ctr).PAR(empty_rows) = (TP89(yr_ctr).PAR(empty_rows)./master_slope(master_counter,3));
        case 4
    TP39(yr_ctr).PAR(empty_rows) = (TP02(yr_ctr).PAR(empty_rows)./master_slope(master_counter,4));
    end    
    
    clear empty_rows
end
filled_rows = find(TP39_PARtracker(1:length(TP39(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP39(yr_ctr).PAR));
TP39_PARtracker(filled_rows,yr_ctr) = 2;

clear filled_rows;

master_counter = master_counter + 1;
end    

%% Fill gaps in TP74:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));
% best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
best = [ix(4) ix(3) ix(2)]; % order of site data to use:

for kk = 1:1:3

    empty_rows = find(isnan(TP74(yr_ctr).PAR)); % find the rows that need to be filled
    
    switch best(kk)
        case 1
    TP74(yr_ctr).PAR(empty_rows) = (TP39(yr_ctr).PAR(empty_rows)./master_slope(master_counter,1));
        case 2
    TP74(yr_ctr).PAR(empty_rows) = (TP74(yr_ctr).PAR(empty_rows)./master_slope(master_counter,2));
        case 3
    TP74(yr_ctr).PAR(empty_rows) = (TP89(yr_ctr).PAR(empty_rows)./master_slope(master_counter,3));
        case 4
    TP74(yr_ctr).PAR(empty_rows) = (TP02(yr_ctr).PAR(empty_rows)./master_slope(master_counter,4));
    end    
    
    clear empty_rows
end
filled_rows = find(TP74_PARtracker(1:length(TP74(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP74(yr_ctr).PAR));
TP74_PARtracker(filled_rows,yr_ctr) = 2;

clear filled_rows;

master_counter = master_counter + 1;
end    

%% Fill gaps in TP89:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));
% best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
best = [ix(4) ix(3) ix(2)]; % order of site data to use:

for kk = 1:1:3

    empty_rows = find(isnan(TP89(yr_ctr).PAR)); % find the rows that need to be filled
    
    switch best(kk)
        case 1
    TP89(yr_ctr).PAR(empty_rows) = (TP39(yr_ctr).PAR(empty_rows)./master_slope(master_counter,1));
        case 2
    TP89(yr_ctr).PAR(empty_rows) = (TP74(yr_ctr).PAR(empty_rows)./master_slope(master_counter,2));
        case 3
    TP89(yr_ctr).PAR(empty_rows) = (TP89(yr_ctr).PAR(empty_rows)./master_slope(master_counter,3));
        case 4
    TP89(yr_ctr).PAR(empty_rows) = (TP02(yr_ctr).PAR(empty_rows)./master_slope(master_counter,4));
    end    
    
    clear empty_rows
end
filled_rows = find(TP89_PARtracker(1:length(TP89(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP89(yr_ctr).PAR));
TP89_PARtracker(filled_rows,yr_ctr) = 2;

clear filled_rows;

master_counter = master_counter + 1;
end  

%% Fill gaps in TP02:

for j = st_yr : 1 : end_yr
    yr_ctr = j-(st_yr-1);
    
%%% sort the r2 values to find best site data to fill it with:
    [a, ix] = sort(master_r2(master_counter,:));
% best = [find(ix == 4) find(ix == 3) find(ix ==2)]; % order of site data to use:
best = [ix(4) ix(3) ix(2)]; % order of site data to use:

for kk = 1:1:3

    empty_rows = find(isnan(TP02(yr_ctr).PAR)); % find the rows that need to be filled
    
    switch best(kk)
        case 1
    TP02(yr_ctr).PAR(empty_rows) = (TP39(yr_ctr).PAR(empty_rows)./master_slope(master_counter,1));
        case 2
    TP02(yr_ctr).PAR(empty_rows) = (TP74(yr_ctr).PAR(empty_rows)./master_slope(master_counter,2));
        case 3
    TP02(yr_ctr).PAR(empty_rows) = (TP89(yr_ctr).PAR(empty_rows)./master_slope(master_counter,3));
        case 4
    TP02(yr_ctr).PAR(empty_rows) = (TP02(yr_ctr).PAR(empty_rows)./master_slope(master_counter,4));
    end    
    
    clear empty_rows
end
filled_rows = find(TP02_PARtracker(1:length(TP02(yr_ctr).PAR),yr_ctr) == 0  & ~isnan(TP02(yr_ctr).PAR));
TP02_PARtracker(filled_rows,yr_ctr) = 2;

clear filled_rows;

master_counter = master_counter + 1;
end  

%% Final Check on the data -- see how it looks when filled in, and 

for j = st_yr :1 : end_yr
    yr_ctr = j-(st_yr-1);
    
    figure(4)
    subplot(4,2,yr_ctr); plot(TP02(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP02 PAR ' num2str(j)]);
ind4 = find(TP02_PARtracker(1:length(TP02(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind4,TP02(yr_ctr).PAR(ind4,1),'gx-'); 

    figure(1)
    subplot(4,2,yr_ctr); plot(TP39(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP39 PAR ' num2str(j)]);
ind1 = find(TP39_PARtracker(1:length(TP39(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind1,TP39(yr_ctr).PAR(ind1,1),'gx-'); 

    figure(2)
    subplot(4,2,yr_ctr); plot(TP74(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP74 PAR ' num2str(j)]);
ind2 = find(TP74_PARtracker(1:length(TP74(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind2,TP74(yr_ctr).PAR(ind2,1),'gx-'); 
    
    figure(3)
    subplot(4,2,yr_ctr); plot(TP89(yr_ctr).PAR,'-','Color',colors(yr_ctr,:)); axis([1 17568 0 3000]); title(['TP89 PAR ' num2str(j)]);   
ind3 = find(TP89_PARtracker(1:length(TP89(yr_ctr).PAR),yr_ctr)==2);
    subplot(4,2,yr_ctr);hold on; plot(ind3,TP89(yr_ctr).PAR(ind3,1),'gx-'); 

clear ind1 ind2 ind3 ind4;

PAR_gaps(yr_ctr,:) = [length(find(TP39_PARtracker(1:17520,yr_ctr)==0)) length(find(TP74_PARtracker(1:17520,yr_ctr)==0)) ...
                      length(find(TP89_PARtracker(1:17520,yr_ctr)==0)) length(find(TP02_PARtracker(1:17520,yr_ctr)==0))];

PAR_fills(yr_ctr,:) = [length(find(TP39_PARtracker(1:17520,yr_ctr)==2)) length(find(TP74_PARtracker(1:17520,yr_ctr)==2)) ...
                      length(find(TP89_PARtracker(1:17520,yr_ctr)==2)) length(find(TP02_PARtracker(1:17520,yr_ctr)==2))];
              
end

%% %%%%%%%%%%%%%%%%%%%%%%% INTERMISSION  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
resp = 1;
while resp ==1 
r = input('press enter to continue to air temperature ');
if isempty(r)==1
    resp = 0;
else 
    resp = 1;
end
end    
 

