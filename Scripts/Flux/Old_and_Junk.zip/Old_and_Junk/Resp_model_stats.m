function [stats] = Resp_model_stats(measured, modeled)
% alpha = 0.05

%% RMSE for all data points (no bin averaging)


good_all = find( ~isnan(measured) & ~isnan(modeled));
%RMSE for data points (non bin averaged):
RMSE = sqrt((sum((modeled(good_all) - measured(good_all)).^2))./(length(good_all)-2));
rRMSE = sqrt((sum((modeled(good_all) - measured(good_all)).^2))./(sum(measured(good_all).^2)));
MAE = (sum(abs(modeled(good_all) - measured(good_all))))./(length(good_all));
BE = (sum(modeled(good_all) - measured(good_all)))./(length(good_all));
p = polyfit(measured(good_all),modeled(good_all),1);

clear good_all

% end
stats(1,1) = p(1);
stats(1,2) = p(2);
stats(1,3) = RMSE; 
stats(1,4) = rRMSE; 
stats(1,5) = MAE;
stats(1,6) = BE;
