clear all
close all
%% Stats Comparison:
model_list = [1 3 4 5 6];
% site = '1'; stamp = '39';
% site = '2'; stamp = '74';
% site = '3'; stamp = '89';   
site = '4'; stamp = '04';
yrlist = [2003; 2004; 2005; 2006; 2007; 200307];
if ispc == 1
    path = ['C:\HOME\MATLAB\Data\Data_Analysis\M' site '_allyears\'];
else
    path = ['/home/jayb/MATLAB/Data/Data_Analysis/M' site '_allyears/'];
end
% path = ['E:\Data\Data_Analysis\M' site '_allyears\'];

%% Compare GEP stats data:

 start_row = 1;   
   for j = 1:1:length(model_list)
      
       GEP_model = model_list(j);
       
 temp = load([path 'M' site '_model' num2str(GEP_model) '_stats.dat']); %GEP
GEP_stats(start_row:start_row+5,:) = temp;

yrs(start_row:start_row+5,1) = yrlist;
modelnum(start_row:start_row+5,1) = GEP_model.*ones(6,1);

clear temp;

start_row = start_row+6;

   end
   
   GEP_stats = [str2double(site).*ones(length(GEP_stats),1) modelnum yrs GEP_stats];
   
   clear yrs modelnum;
%% Compare NEE stats data:
 start_row = 1;   
   for j = 1:1:length(model_list)
      
       GEP_model = model_list(j);
       
 temp = load([path 'M' site '_model' num2str(GEP_model) '_NEEstats.dat']);

 NEE_stats(start_row:start_row+5,:) = temp;

yrs(start_row:start_row+5,1) = yrlist;
modelnum(start_row:start_row+5,1) = GEP_model.*ones(6,1);

clear temp;

start_row = start_row+6;

   end
[rows cols] = size(NEE_stats);
   NEE_stats = [str2double(site).*ones(rows,1) modelnum yrs NEE_stats];
   
   
M1_stats = [0.481 2.057 0.079;...
            0.473 2.011 0.023;...
            0.590 2.504 -0.175;...
            0.479 2.046 -0.106];
        
M2_stats = [0.536 2.356 0.265;...
            0.542 2.388 0.199;...
            0.600 2.744 0.157;...
            0.548 2.432 0.028];
   
M3_stats = [0.487 3.950 -0.033;...
            0.495 3.986 -0.123;...
            0.522 4.242 0.320;...
            0.491 4.004 0.251]; 
        
M4_stats = [0.737 1.382 -0.078;...
            0.751 1.424 -0.174;...
            0.740 1.366 0.131;...
            0.755 1.427 -0.22];        
        symlist = ['o','v','s','p'];
        colorlist = colormap(lines(4));
%         x = [1 2 3]
        figure(2);clf
         for m = 1:1:4
            H(m) = plot(1,M1_stats(m,1),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3));
            hold on;
            plot(2,M2_stats(m,1),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3))
            plot(3,M3_stats(m,1),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3))
            plot(4,M4_stats(m,1),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3))
         end
         axis([0 5 0.4 0.8])
         XTicks = (1:1:4)'; XTickLabels = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
         set(gca,'XTick',XTicks,'XTickLabel',XTickLabels,'FontSize',20)
         legend(H,'Aggregated R','Individual','PAR-GEP','Aggregated All',2)
        
         figure(3);clf
           for m = 1:1:4
            H(m) = plot(1,M1_stats(m,2),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3));
            hold on;
            plot(2,M2_stats(m,2),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
            plot(3,M3_stats(m,2),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
            plot(4,M4_stats(m,2),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
         end
               axis([0 5 1 4.4])
         XTicks = (1:1:4)'; XTickLabels = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
         set(gca,'XTick',XTicks,'XTickLabel',XTickLabels,'FontSize',20)
         legend(H,'Aggregated','Individual','PAR-GEP','Aggregated All',2)

                  figure(4);clf
           for m = 1:1:4
            H(m) = plot(1,abs(M1_stats(m,3)),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,1:3));
            hold on;
            plot(2,abs(M2_stats(m,3)),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
            plot(3,abs(M3_stats(m,3)),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
            plot(4,abs(M4_stats(m,3)),'Marker',symlist(m),'MarkerSize',12,'Color',colorlist(m,:))
         end
               axis([0 5 0 0.4])
         XTicks = (1:1:4)'; XTickLabels = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
         set(gca,'XTick',XTicks,'XTickLabel',XTickLabels,'FontSize',20)
         legend(H,'Aggregated','Individual','PAR-GEP','Aggregated All',2)