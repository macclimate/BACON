function [] = TP_Flux_Load(site_num, start_yr, end_yr) 
%% TP_Flux_Load.m
%%% This function loads data required for TP flux analysis, and saves the
%%% data in a matlab structure file
%%% Use 1,2,3,4 for TP39,TP74,TP89 and TP02, respectively.
%%%%% DATA NEEDED:
% Tair, Ts, PAR, RH (VPD), WS, WDIR, dcdt, NEE(raw), 

%%
if ispc == 1;
    data_loc = 'C:/HOME/';
else
    data_loc = '/home/jayb/';
end

%% Make Sure site and year are in proper format
site_list = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
if ischar(site_num) == true
    site_num = str2double(site_num);
end
    site = site_list(site_num,:);    
disp(['processing site: ' site]);
    
if ischar(start_yr) == true
    start_yr = str2double(start_yr);
end
if ischar(end_yr) == true
    end_yr = str2double(end_yr);
end
   


 row_ctr = 0;
for j = start_yr:1:end_yr
    yr_ctr = j - start_yr + 1;      %% Counts from 1 by 1 to number of years being processed
    yr_str = num2str(j);
     
%% Declare Paths:
load_path_filled = ([data_loc 'MATLAB/Data/Met/Final_Filled/' site '/' site '_' yr_str]);
load_path_cleaned = ([data_loc 'MATLAB/Data/Met/Final_Cleaned/' site '/' site '_' yr_str]);
    hdr_path = [data_loc 'MATLAB/Data/Met/Final_Cleaned/Headers/'];
% metcalc_path = ([data_loc 'MATLAB/Data/Met/Calculated4/' site '/' site '_' yr_str ]);
tracker_path = [data_loc 'MATLAB/Data/Flux/Met_Flux_Tracker/' site '/' site '_' yr_str];
flux_path = [data_loc 'MATLAB/Data/Flux/Final_Calculated/' site '/' site '_'];
% param_path = [data_loc 'MATLAB/Data/Flux/Final_Calculated/Docs/'];
param_path = [data_loc 'MATLAB/Data/Met/Calculated4/Docs/'];

  
%% Load header
        hdr = jjb_hdr_read([hdr_path site '_CCP_List.csv'], ',', 2);

%%        
dt(1:17568,1) = NaN; temp_NEE(1:17568,1) = NaN; temp_Ts2(1:17568,1) = NaN; temp_Ta(1:17568,1) = NaN; 
temp_PAR(1:17568,1) = NaN; temp_SM(1:17568,1) = NaN; temp_SMb(1:17568,1) = NaN; temp_SMa(1:17568,1) = NaN; 
temp_ustar(1:17568,1) = NaN; temp_WS(1:17568,1) = NaN; temp_WDir(1:17568,1) = NaN; temp_RH(1:17568,1) = NaN;
temp_Ts5(1:17568,1) = NaN; year(1:17568,1) = NaN; temp_tr_Ta(1:17568,1) = NaN; temp_tr_APR(1:17568,1) = NaN; 
temp_tr_PAR(1:17568,1) = NaN; temp_tr_VPD(1:17568,1) = NaN; temp_tr_Ts2(1:17568,1) = NaN; temp_tr_Ts5(1:17568,1) = NaN; 
temp_tr_SM(1:17568,1) = NaN; temp_tr_SMa(1:17568,1) = NaN; temp_tr_SMb(1:17568,1) = NaN; 

%% Make Time variables:
        [temp_yr junk(:,1) junk(:,2) temp_dt]  = jjb_makedate(j,30);
        
%% Load Variables:
dt(1:length(temp_dt),1) = temp_dt; 
year(1:length(temp_dt),1) = temp_yr(1:length(temp_dt),1);

data(1).dt(row_ctr+1:row_ctr+17568,1) = dt(1:17568,1);
data(1).year(row_ctr+1:row_ctr+17568,1) = year(1:17568,1);

temp_Tas = load([load_path_filled '.Ta']); temp_Ta(1:length(temp_Tas),1) = temp_Tas; data(1).Ta(row_ctr+1:row_ctr+17568,1) = temp_Ta(1:17568,1);
temp_RHs = load([load_path_filled '.RH']); temp_RH(1:length(temp_RHs),1) = temp_RHs; data(1).RH(row_ctr+1:row_ctr+17568,1) = temp_RH(1:17568,1);
temp_PARs = load([load_path_filled '.PAR']); temp_PAR(1:length(temp_PARs),1) = temp_PARs; data(1).PAR(row_ctr+1:row_ctr+17568,1) = temp_PAR(1:17568,1);
temp_Ts2s = load([load_path_filled '.Ts2']); temp_Ts2(1:length(temp_Ts2s),1) = temp_Ts2s; data(1).Ts2(row_ctr+1:row_ctr+17568,1) = temp_Ts2(1:17568,1);
temp_Ts5s = load([load_path_filled '.Ts5']); temp_Ts5(1:length(temp_Ts5s),1) = temp_Ts5s; data(1).Ts5(row_ctr+1:row_ctr+17568,1) = temp_Ts5(1:17568,1);
temp_WSs = jjb_load_var(hdr,[load_path_cleaned '.'],'WS',1); temp_WS(1:length(temp_WSs),1) = temp_WSs; data(1).WS(row_ctr+1:row_ctr+17568,1) = temp_WS(1:17568,1);
temp_WDirs = jjb_load_var(hdr,[load_path_cleaned '.'],'W_DIR',1); temp_WDir(1:length(temp_WDirs),1) = temp_WDirs; data(1).WDir(row_ctr+1:row_ctr+17568,1) = temp_WDir(1:17568,1);
temp_ustars = jjb_load_var(hdr,[load_path_cleaned '.'],'Ustar',1); temp_ustar(1:length(temp_ustars),1) = temp_ustars; data(1).ustar(row_ctr+1:row_ctr+17568,1) = temp_ustar(1:17568,1);
temp_SMs = load([load_path_filled '.SM']); temp_SM(1:length(temp_SMs),1) = temp_SMs; data(1).SM(row_ctr+1:row_ctr+17568,1) = temp_SM(1:17568,1);
temp_SMas = load([load_path_filled '.SMa']); temp_SMa(1:length(temp_SMas),1) = temp_SMas; data(1).SMa(row_ctr+1:row_ctr+17568,1) = temp_SMa(1:17568,1);
temp_SMbs = load([load_path_filled '.SMb']); temp_SMb(1:length(temp_SMbs),1) = temp_SMbs; data(1).SMb(row_ctr+1:row_ctr+17568,1) = temp_SMb(1:17568,1);
temp_NEEs = load([flux_path yr_str 'NEE_raw.dat']); temp_NEE(1:length(temp_NEEs),1) = temp_NEEs; data(1).NEE_raw(row_ctr+1:row_ctr+17568,1) = temp_NEE(1:17568,1);

%%% Calculate VPD from RH
esat = 0.6108.*exp((17.27.*temp_Ta)./(237.3+temp_Ta));
e = (temp_RH.*esat)./100;
temp_VPD = esat-e;
clear esat e;
data(1).VPD(row_ctr+1:row_ctr+17568,1) = temp_VPD(1:17568,1);
%% Load tracker files:

temp_trTa = load([tracker_path 'Ta_tracker.dat']);  temp_master_tracker(1:17568,1) = temp_trTa(1:17568,1);
temp_trAPR = load([tracker_path 'APR_tracker.dat']); temp_master_tracker(1:17568,2) = temp_trAPR(1:17568,1);
temp_trPAR = load([tracker_path 'PAR_tracker.dat']); temp_master_tracker(1:17568,3) = temp_trPAR(1:17568,1);
temp_trRH = load([tracker_path 'RH_tracker.dat']);   
temp_trTs2 = load([tracker_path 'Ts2_tracker.dat']); temp_master_tracker(1:17568,4) = temp_trTs2(1:17568,1);
temp_trTs5 = load([tracker_path 'Ts5_tracker.dat']); temp_master_tracker(1:17568,5) = temp_trTs5(1:17568,1);

%% Make SM, VPD and ustar tracker files:
temp_trVPD(1:length(temp_VPD),1) = 0;
temp_trVPD(temp_trTa == 1 & temp_trRH == 1 ,1) = 1;
temp_trVPD((temp_trTa == 2 | temp_trRH == 2) & temp_trTa~= 0 & temp_trRH ~= 0,1) = 2;
temp_trVPD(isnan(temp_VPD),1) = 0;


temp_trustar(1:length(temp_ustar),1) = 0;
temp_trustar(~isnan(temp_ustar),1) = 1;

temp_trSM(1:length(temp_SM),1) = 0;
temp_trSM(~isnan(temp_SM),1) = 1;

temp_trSMa(1:length(temp_SMa),1) = 0;
temp_trSMa(~isnan(temp_SMa),1) = 1;

temp_trSMb(1:length(temp_SMb),1) = 0;
temp_trSMb(~isnan(temp_SMb),1) = 1;

temp_master_tracker(1:17568,6) = temp_trVPD(1:17568,1);
temp_master_tracker(1:17568,7) = temp_trustar(1:17568,1);
temp_master_tracker(1:17568,8) = temp_trSM(1:17568,1);
temp_master_tracker(1:17568,9) = temp_trSMa(1:17568,1);
temp_master_tracker(1:17568,10) = temp_trSMb(1:17568,1);



%% Clean NEE raw data, make a new tracker file for cleaned NEE:
NEE_params = dlmread([param_path 'TP_NEE_params.csv'],',');
right_row = find(NEE_params(:,1) == site_num & NEE_params(:,2) == j);
st_pt = NEE_params(right_row,3);
real_z = NEE_params(right_row,4);
stdev = NEE_params(right_row,5);

real_spikes = jjb_find_spike2(temp_NEE, 99,stdev,st_pt, real_z);
NEE_clean = temp_NEE;
NEE_clean(abs(real_spikes)==1,1) = NaN;

data(1).NEE(row_ctr+1:row_ctr+17568,1) = NEE_clean(1:17568,1);

temp_trNEE(1:17568,1) = 0;
temp_trNEE(~isnan(NEE_clean),1) = 1;

temp_master_tracker(~isnan(NEE_clean),11) = 1;

temp_NEE2(1:length(temp_yr),1) = NEE_clean(1:length(temp_yr),1);
save([flux_path num2str(j)  'NEEclean.dat'],'temp_NEE2','-ASCII');

%%
data(1).tracker(row_ctr+1:row_ctr+17568,1:11) = temp_master_tracker(:,1:11);

clear temp* dt year junk NEE_clean real_spikes
  row_ctr = row_ctr + 17568;
%   resp = input('hit enter');
end



%% Save the master file:
save([flux_path 'input_' num2str(start_yr) '_' num2str(end_yr) '.mat'],'data');
