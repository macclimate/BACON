alpha = 0.05

[GEP_reg(1).b,GEP_reg(1).bint,GEP_reg(1).r,GEP_reg(1).rint,GEP_reg(1).stats] = regress_analysis(GEP2003_bavg(1:11,2),[GEP2003_bavg(1:11,1) ones(11,1)],alpha);

[GEP_reg(2).b,GEP_reg(2).bint,GEP_reg(2).r,GEP_reg(2).rint,GEP_reg(2).stats] = regress_analysis(GEP2004_bavg(1:11,2),[GEP2004_bavg(1:11,1) ones(11,1)],alpha);

[GEP_reg(3).b,GEP_reg(3).bint,GEP_reg(3).r,GEP_reg(3).rint,GEP_reg(3).stats] = regress_analysis(GEP2005_bavg(1:11,2),[GEP2005_bavg(1:11,1) ones(11,1)],alpha);

[GEP_reg(4).b,GEP_reg(4).bint,GEP_reg(4).r,GEP_reg(4).rint,GEP_reg(4).stats] = regress_analysis(GEP2006_bavg(1:11,2),[GEP2006_bavg(1:11,1) ones(11,1)],alpha);

[GEP_reg(5).b,GEP_reg(5).bint,GEP_reg(5).r,GEP_reg(5).rint,GEP_reg(5).stats] = regress_analysis(GEP2007_bavg(1:11,2),[GEP2007_bavg(1:11,1) ones(11,1)],alpha);

[GEP_reg(6).b,GEP_reg(6).bint,GEP_reg(6).r,GEP_reg(6).rint,GEP_reg(6).stats] = regress_analysis(GEPa_bavg(1:11,2),[GEPa_bavg(1:11,1) ones(11,1)],alpha);

for jk = 1:1:6
%     sl_int(jk,:) = GEP_reg(jk).b;
%     stats(jk,:) = GEP_reg(jk).stats;
    stats_sm(jk,1:2) = GEP_reg(jk).b;
    stats_sm(jk,3) = GEP_reg(jk).stats(1,1);
    
end

%% Calculate More Stats
% RMSE
RMSE(1,1) = (sum((GEP2003_bavg(1:11,2)- GEP2003_bavg(1:11,1)).^2))./9;
RMSE(2,1) = (sum((GEP2004_bavg(1:11,2)- GEP2004_bavg(1:11,1)).^2))./9;
RMSE(3,1) = (sum((GEP2005_bavg(1:11,2)- GEP2005_bavg(1:11,1)).^2))./9;
RMSE(4,1) = (sum((GEP2006_bavg(1:11,2)- GEP2006_bavg(1:11,1)).^2))./9;
RMSE(5,1) = (sum((GEP2007_bavg(1:11,2)- GEP2007_bavg(1:11,1)).^2))./9;
RMSE(6,1) = (sum((GEPa_bavg(1:11,2)- GEPa_bavg(1:11,1)).^2))./9;

stats_sm = [stats_sm RMSE];
%% Calculate same stats but for high GEP
[GEP_reg2(1).b,GEP_reg2(1).bint,GEP_reg2(1).r,GEP_reg2(1).rint,GEP_reg2(1).stats] = regress_analysis(GEP2003_bavg(12:22,2),[GEP2003_bavg(12:22,1) ones(11,1)],alpha);

[GEP_reg2(2).b,GEP_reg2(2).bint,GEP_reg2(2).r,GEP_reg2(2).rint,GEP_reg2(2).stats] = regress_analysis(GEP2004_bavg(12:22,2),[GEP2004_bavg(12:22,1) ones(11,1)],alpha);

[GEP_reg2(3).b,GEP_reg2(3).bint,GEP_reg2(3).r,GEP_reg2(3).rint,GEP_reg2(3).stats] = regress_analysis(GEP2005_bavg(12:22,2),[GEP2005_bavg(12:22,1) ones(11,1)],alpha);

[GEP_reg2(4).b,GEP_reg2(4).bint,GEP_reg2(4).r,GEP_reg2(4).rint,GEP_reg2(4).stats] = regress_analysis(GEP2006_bavg(12:22,2),[GEP2006_bavg(12:22,1) ones(11,1)],alpha);

[GEP_reg2(5).b,GEP_reg2(5).bint,GEP_reg2(5).r,GEP_reg2(5).rint,GEP_reg2(5).stats] = regress_analysis(GEP2007_bavg(12:22,2),[GEP2007_bavg(12:22,1) ones(11,1)],alpha);

[GEP_reg2(6).b,GEP_reg2(6).bint,GEP_reg2(6).r,GEP_reg2(6).rint,GEP_reg2(6).stats] = regress_analysis(GEPa_bavg(12:22,2),[GEPa_bavg(12:22,1) ones(11,1)],alpha);

for jk = 1:1:6
%     sl_int2(jk,:) = GEP_reg2(jk).b;
%     stats2(jk,:) = GEP_reg2(jk).stats;
     stats_lg(jk,1:2) = GEP_reg2(jk).b;
    stats_lg(jk,3) = GEP_reg2(jk).stats(1,1);
end

%% Calculate More Stats
% RMSE
RMSE2(1,1) = sqrt((sum((GEP2003_bavg(12:22,2)- GEP2003_bavg(12:22,1)).^2))./9);
RMSE2(2,1) = sqrt((sum((GEP2004_bavg(12:22,2)- GEP2004_bavg(12:22,1)).^2))./9);
RMSE2(3,1) = sqrt((sum((GEP2005_bavg(12:21,2)- GEP2005_bavg(12:21,1)).^2))./8);
RMSE2(4,1) = sqrt((sum((GEP2006_bavg(12:22,2)- GEP2006_bavg(12:22,1)).^2))./9);
RMSE2(5,1) = sqrt((sum((GEP2007_bavg(12:22,2)- GEP2007_bavg(12:22,1)).^2))./9);
RMSE2(6,1) = sqrt((sum((GEPa_bavg(12:22,2)- GEPa_bavg(12:22,1)).^2))./9);

stats_lg = [stats_lg RMSE2];

%% RMSE for all data:
RMSEall(1,1) = sqrt((sum((GEP2003_bavg(1:22,2)- GEP2003_bavg(1:22,1)).^2))./20);
RMSEall(2,1) = sqrt((sum((GEP2004_bavg(1:22,2)- GEP2004_bavg(1:22,1)).^2))./20);
RMSEall(3,1) = sqrt((sum((GEP2005_bavg(1:21,2)- GEP2005_bavg(1:21,1)).^2))./19);
RMSEall(4,1) = sqrt((sum((GEP2006_bavg(1:22,2)- GEP2006_bavg(1:22,1)).^2))./20);
RMSEall(5,1) = sqrt((sum((GEP2007_bavg(1:22,2)- GEP2007_bavg(1:22,1)).^2))./20);
RMSEall(6,1) = sqrt((sum((GEPa_bavg(1:22,2)- GEPa_bavg(1:22,1)).^2))./20);

stat_out = [stats_sm stats_lg RMSEall];

save ([path 'M' site '_model' num2str(GEP_model) '_stats.dat'], 'stat_out','-ASCII');


%% Try to do some stats work with NEE:
for jb = 1:1:6
    NEE_bavg = NEEbavg(jb).bavg;
    group_bot = [-25 -13 2];
    group_top = [-13  2 12];
for kk = 1:1:length(group_bot)
    good_num = find(NEE_bavg(:,1) > group_bot(kk) & NEE_bavg(:,1) <= group_top(kk) & ~isnan(NEE_bavg(:,2)));
[NEE_reg(kk).b,NEE_reg(kk).bint,NEE_reg(kk).r,NEE_reg(kk).rint,NEE_reg(kk).stats] = regress_analysis(NEE_bavg(good_num,2),[NEE_bavg(good_num,1) ones(length(good_num),1)],alpha);
NEE_RMSE(kk,1) = sqrt((sum((NEE_bavg(good_num,2)- NEE_bavg(good_num,1)).^2))./(length(good_num)-2));
%relative RMSE
rNEE_RMSE(kk,1) = sqrt((sum((NEE_bavg(good_num,2)- NEE_bavg(good_num,1)).^2))./(sum(NEE_bavg(good_num,1).^2)));

clear good_num
end
NEE_stats(jb,1:2) = NEE_reg(1).b; NEE_stats(jb,3) = NEE_reg(1).stats(1,1);
NEE_stats(jb,4) = NEE_RMSE(1); NEE_stats(jb,5) = rNEE_RMSE(1);
NEE_stats(jb,6:7) = NEE_reg(2).b;  NEE_stats(jb,8) = NEE_reg(2).stats(1,1);
NEE_stats(jb,9) = NEE_RMSE(2); NEE_stats(jb,10) = rNEE_RMSE(2); 
NEE_stats(jb,11:12) = NEE_reg(3).b;  NEE_stats(jb,13) = NEE_reg(3).stats(1,1);
NEE_stats(jb,14) = NEE_RMSE(3,1); NEE_stats(jb,15) = rNEE_RMSE(3,1); 

kk =kk+1;
% RMSE for all data
    good_num_all = find(NEE_bavg(:,1) > group_bot(1) & NEE_bavg(:,1) <= group_top(end) & ~isnan(NEE_bavg(:,2)));
[NEE_reg(kk).b,NEE_reg(kk).bint,NEE_reg(kk).r,NEE_reg(kk).rint,NEE_reg(kk).stats] = regress_analysis(NEE_bavg(good_num_all,2),[NEE_bavg(good_num_all,1) ones(length(good_num_all),1)],alpha);
NEE_RMSE(kk,1) = sqrt((sum((NEE_bavg(good_num_all,2)- NEE_bavg(good_num_all,1)).^2))./(length(good_num_all)-2));
rNEE_RMSE(kk,1) = sqrt((sum((NEE_bavg(good_num_all,2)- NEE_bavg(good_num_all,1)).^2))./(sum(NEE_bavg(good_num_all,1).^2)));


NEE_stats(jb,16) = NEE_RMSE(kk);
NEE_stats(jb,17) = rNEE_RMSE(kk);



% NEE_RMSE_all(kk,1) = (sum((NEE1_clean(good(jb).NEE) - NEE_model(good(jb).NEE)).^2))./(length(good(jb).NEE)-2);

clear NEE_RMSE NEE_reg good_num good_num_all
end
%% RMSE for all data points (no bin averaging)
for pp = 2003:1:2007
ctr_pp = pp-2002;
for kk = 1:1:length(group_bot);
good_all = find(year1 == pp & NEE1_clean > group_bot(kk) & NEE1_clean < group_top(kk) & ~isnan(NEE1_clean) & ~isnan(NEE_model));
%RMSE for data points (non bin averaged):
NEE_RMSE_all(kk,1) = sqrt((sum((NEE_model(good_all) - NEE1_clean(good_all)).^2))./(length(good_all)-2));
rNEE_RMSE_all(kk,1) = sqrt((sum((NEE_model(good_all) - NEE1_clean(good_all)).^2))./(sum(NEE1_clean(good_all).^2)));
MAE(kk,1) = (sum(abs(NEE_model(good_all) - NEE1_clean(good_all))))./(length(good_all));
BE(kk,1) = (sum(NEE_model(good_all) - NEE1_clean(good_all)))./(length(good_all));

clear good_all
end
NEE_stats(ctr_pp,18:20) = NEE_RMSE_all(1:3,1); 
NEE_stats(ctr_pp,21:23) = rNEE_RMSE_all(1:3,1); 
NEE_stats(ctr_pp,24:26) = MAE(1:3,1);
NEE_stats(ctr_pp,27:29) = BE(1:3,1);


kk =kk+1;
% RMSE for all data (non bin averaged)
good_num_all = find(~isnan(NEE1_clean) & year1 == pp & ~isnan(NEE_model));
NEE_RMSE_all(kk,1) = sqrt((sum((NEE1_clean(good_num_all,1)- NEE_model(good_num_all,1)).^2))./(length(good_num_all)-2));
rNEE_RMSE_all(kk,1) = sqrt((sum((NEE1_clean(good_num_all,1) - NEE_model(good_num_all)).^2))./(sum(NEE1_clean(good_num_all).^2)));
MAE(kk,1) = (sum(abs(NEE_model(good_num_all) - NEE1_clean(good_num_all))))./(length(good_num_all));
BE(kk,1) = (sum(NEE_model(good_num_all) - NEE1_clean(good_num_all)))./(length(good_num_all));

NEE_stats(ctr_pp,30) = NEE_RMSE_all(kk);
NEE_stats(ctr_pp,31) = rNEE_RMSE_all(kk);
NEE_stats(ctr_pp,32) = MAE(kk);
NEE_stats(ctr_pp,33) = BE(kk);


clear NEE_RMSE_all;

end

ctr_pp = ctr_pp+1;
%%% Finally, no bin average, for all years:
for kk = 1:1:length(group_bot);
good_all = find(NEE1_clean > group_bot(kk) & NEE1_clean < group_top(kk) & ~isnan(NEE1_clean) & ~isnan(NEE_model));
%RMSE for data points (non bin averaged):
NEE_RMSE_all(kk,1) = sqrt((sum((NEE_model(good_all) - NEE1_clean(good_all)).^2))./(length(good_all)-2));
rNEE_RMSE_all(kk,1) = sqrt((sum((NEE_model(good_all) - NEE1_clean(good_all)).^2))./(sum(NEE1_clean(good_all).^2)));
MAE(kk,1) = (sum(abs(NEE_model(good_all) - NEE1_clean(good_all))))./(length(good_all));
BE(kk,1) = (sum(NEE_model(good_all) - NEE1_clean(good_all)))./(length(good_all));
clear good_all
end

NEE_stats(ctr_pp,18:20) = NEE_RMSE_all(1:3,1); 
NEE_stats(ctr_pp,21:23) = rNEE_RMSE_all(1:3,1); 
NEE_stats(ctr_pp,24:26) = MAE(1:3,1);
NEE_stats(ctr_pp,27:29) = BE(1:3,1);

% RMSE for all data points (no bin average)
kk =kk+1;
% RMSE for all data (non bin averaged)
good_num_all = find(~isnan(NEE1_clean) & ~isnan(NEE_model));
NEE_RMSE_all(kk,1) = sqrt((sum((NEE1_clean(good_num_all,1)- NEE_model(good_num_all,1)).^2))./(length(good_num_all)-2));
rNEE_RMSE_all(kk,1) = sqrt((sum((NEE1_clean(good_num_all,1) - NEE_model(good_num_all)).^2))./(sum(NEE1_clean(good_num_all).^2)));
MAE(kk,1) = (sum(abs(NEE_model(good_num_all) - NEE1_clean(good_num_all))))./(length(good_num_all));
BE(kk,1) = (sum(NEE_model(good_num_all) - NEE1_clean(good_num_all)))./(length(good_num_all));


% NEE_stats(ctr_pp,17) = NEE_RMSE_all(kk);
NEE_stats(ctr_pp,30) = NEE_RMSE_all(kk);
NEE_stats(ctr_pp,31) = rNEE_RMSE_all(kk);
NEE_stats(ctr_pp,32) = MAE(kk);
NEE_stats(ctr_pp,33) = BE(kk);

%% Day & Night Error Comparison:

for pp = 2003:1:2007
    ctr_pp = pp-2002;
    
good_day = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & PAR1 > 20);
good_night = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & PAR1 < 10);

NEE_RMSE_day(ctr_pp,1) = sqrt((sum((NEE1_clean(good_day,1)- NEE_model(good_day,1)).^2))./(length(good_day)-2));
NEE_RMSE_night(ctr_pp,1) = sqrt((sum((NEE1_clean(good_night,1)- NEE_model(good_night,1)).^2))./(length(good_night)-2));

rNEE_RMSE_day(ctr_pp,1) = sqrt((sum((NEE1_clean(good_day,1) - NEE_model(good_day)).^2))./(sum(NEE1_clean(good_day).^2)));
rNEE_RMSE_night(ctr_pp,1) = sqrt((sum((NEE1_clean(good_night,1) - NEE_model(good_night)).^2))./(sum(NEE1_clean(good_night).^2)));

NEE_MAE_day(ctr_pp,1) =(sum(abs(NEE_model(good_day) - NEE1_clean(good_day))))./(length(good_day));
NEE_MAE_night(ctr_pp,1) =(sum(abs(NEE_model(good_night) - NEE1_clean(good_night))))./(length(good_night));

NEE_BE_day(ctr_pp,1) = (sum(NEE_model(good_day) - NEE1_clean(good_day)))./(length(good_day));
NEE_BE_night(ctr_pp,1) = (sum(NEE_model(good_night) - NEE1_clean(good_night)))./(length(good_night));

end
ctr_pp = ctr_pp+1;
%%% All years:

good_day_all = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & PAR1 > 20);
good_night_all = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & PAR1 < 10);

NEE_RMSE_day(ctr_pp,1) = sqrt((sum((NEE1_clean(good_day_all,1)- NEE_model(good_day_all,1)).^2))./(length(good_day_all)-2));
NEE_RMSE_night(ctr_pp,1) = sqrt((sum((NEE1_clean(good_night_all,1)- NEE_model(good_night_all,1)).^2))./(length(good_night_all)-2));

rNEE_RMSE_day(ctr_pp,1) = sqrt((sum((NEE1_clean(good_day_all,1) - NEE_model(good_day_all)).^2))./(sum(NEE1_clean(good_day_all).^2)));
rNEE_RMSE_night(ctr_pp,1) = sqrt((sum((NEE1_clean(good_night_all,1) - NEE_model(good_night_all)).^2))./(sum(NEE1_clean(good_night_all).^2)));

NEE_MAE_day(ctr_pp,1) =(sum(abs(NEE_model(good_day_all) - NEE1_clean(good_day_all))))./(length(good_day_all));
NEE_MAE_night(ctr_pp,1) =(sum(abs(NEE_model(good_night_all) - NEE1_clean(good_night_all))))./(length(good_night_all));

NEE_BE_day(ctr_pp,1) = (sum(NEE_model(good_day_all) - NEE1_clean(good_day_all)))./(length(good_day_all));
NEE_BE_night(ctr_pp,1) = (sum(NEE_model(good_night_all) - NEE1_clean(good_night_all)))./(length(good_night_all));

NEE_stats = [NEE_stats NEE_RMSE_day NEE_RMSE_night rNEE_RMSE_day rNEE_RMSE_night NEE_MAE_day NEE_MAE_night NEE_BE_day NEE_BE_night];


%%% Seasonal Stats:
for pp = 2003:1:2007
    ctr_pp = pp-2002;
% Winter    
    
good_win = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & (dt1 > 330 | dt1<=91));
good_spr = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 91 & dt1<=152);
good_sum = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 152 & dt1<=274);
good_aut = find(year1 == pp & ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 274 & dt1<=330);

NEE_RMSE_win(ctr_pp,1) = sqrt((sum((NEE1_clean(good_win,1)- NEE_model(good_win,1)).^2))./(length(good_win)-2));
NEE_RMSE_spr(ctr_pp,1) = sqrt((sum((NEE1_clean(good_spr,1)- NEE_model(good_spr,1)).^2))./(length(good_spr)-2));
NEE_RMSE_sum(ctr_pp,1) = sqrt((sum((NEE1_clean(good_sum,1)- NEE_model(good_sum,1)).^2))./(length(good_sum)-2));
NEE_RMSE_aut(ctr_pp,1) = sqrt((sum((NEE1_clean(good_aut,1)- NEE_model(good_aut,1)).^2))./(length(good_aut)-2));

rNEE_RMSE_win(ctr_pp,1) = sqrt((sum((NEE1_clean(good_win,1) - NEE_model(good_win)).^2))./(sum(NEE1_clean(good_win).^2)));
rNEE_RMSE_spr(ctr_pp,1) = sqrt((sum((NEE1_clean(good_spr,1) - NEE_model(good_spr)).^2))./(sum(NEE1_clean(good_spr).^2)));
rNEE_RMSE_sum(ctr_pp,1) = sqrt((sum((NEE1_clean(good_sum,1) - NEE_model(good_sum)).^2))./(sum(NEE1_clean(good_sum).^2)));
rNEE_RMSE_aut(ctr_pp,1) = sqrt((sum((NEE1_clean(good_aut,1) - NEE_model(good_aut)).^2))./(sum(NEE1_clean(good_aut).^2)));

NEE_MAE_spr(ctr_pp,1) =(sum(abs(NEE_model(good_spr) - NEE1_clean(good_spr))))./(length(good_spr));
NEE_MAE_sum(ctr_pp,1) =(sum(abs(NEE_model(good_sum) - NEE1_clean(good_sum))))./(length(good_sum));
NEE_MAE_aut(ctr_pp,1) =(sum(abs(NEE_model(good_aut) - NEE1_clean(good_aut))))./(length(good_aut));
NEE_MAE_win(ctr_pp,1) =(sum(abs(NEE_model(good_win) - NEE1_clean(good_win))))./(length(good_win));


NEE_BE_win(ctr_pp,1) = (sum(NEE_model(good_win) - NEE1_clean(good_win)))./(length(good_win));
NEE_BE_spr(ctr_pp,1) = (sum(NEE_model(good_spr) - NEE1_clean(good_spr)))./(length(good_spr));
NEE_BE_sum(ctr_pp,1) = (sum(NEE_model(good_sum) - NEE1_clean(good_sum)))./(length(good_sum));
NEE_BE_aut(ctr_pp,1) = (sum(NEE_model(good_aut) - NEE1_clean(good_aut)))./(length(good_aut));

end

ctr_pp = ctr_pp+1;
%%% All years:

good_win = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & (dt1 > 330 | dt1<=91));
good_spr = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 91 & dt1<=152);
good_sum = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 152 & dt1<=274);
good_aut = find( ~isnan(NEE1_clean) & ~isnan(NEE_model) & dt1 > 274 & dt1<=330);

NEE_RMSE_win(ctr_pp,1) = sqrt((sum((NEE1_clean(good_win,1)- NEE_model(good_win,1)).^2))./(length(good_win)-2));
NEE_RMSE_spr(ctr_pp,1) = sqrt((sum((NEE1_clean(good_spr,1)- NEE_model(good_spr,1)).^2))./(length(good_spr)-2));
NEE_RMSE_sum(ctr_pp,1) = sqrt((sum((NEE1_clean(good_sum,1)- NEE_model(good_sum,1)).^2))./(length(good_sum)-2));
NEE_RMSE_aut(ctr_pp,1) = sqrt((sum((NEE1_clean(good_aut,1)- NEE_model(good_aut,1)).^2))./(length(good_aut)-2));

rNEE_RMSE_win(ctr_pp,1) = sqrt((sum((NEE1_clean(good_win,1) - NEE_model(good_win)).^2))./(sum(NEE1_clean(good_win).^2)));
rNEE_RMSE_spr(ctr_pp,1) = sqrt((sum((NEE1_clean(good_spr,1) - NEE_model(good_spr)).^2))./(sum(NEE1_clean(good_spr).^2)));
rNEE_RMSE_sum(ctr_pp,1) = sqrt((sum((NEE1_clean(good_sum,1) - NEE_model(good_sum)).^2))./(sum(NEE1_clean(good_sum).^2)));
rNEE_RMSE_aut(ctr_pp,1) = sqrt((sum((NEE1_clean(good_aut,1) - NEE_model(good_aut)).^2))./(sum(NEE1_clean(good_aut).^2)));

NEE_MAE_spr(ctr_pp,1) =(sum(abs(NEE_model(good_spr) - NEE1_clean(good_spr))))./(length(good_spr));
NEE_MAE_sum(ctr_pp,1) =(sum(abs(NEE_model(good_sum) - NEE1_clean(good_sum))))./(length(good_sum));
NEE_MAE_aut(ctr_pp,1) =(sum(abs(NEE_model(good_aut) - NEE1_clean(good_aut))))./(length(good_aut));
NEE_MAE_win(ctr_pp,1) =(sum(abs(NEE_model(good_win) - NEE1_clean(good_win))))./(length(good_win));


NEE_BE_win(ctr_pp,1) = (sum(NEE_model(good_win) - NEE1_clean(good_win)))./(length(good_win));
NEE_BE_spr(ctr_pp,1) = (sum(NEE_model(good_spr) - NEE1_clean(good_spr)))./(length(good_spr));
NEE_BE_sum(ctr_pp,1) = (sum(NEE_model(good_sum) - NEE1_clean(good_sum)))./(length(good_sum));
NEE_BE_aut(ctr_pp,1) = (sum(NEE_model(good_aut) - NEE1_clean(good_aut)))./(length(good_aut));


NEE_stats = [NEE_stats NEE_RMSE_win NEE_RMSE_spr NEE_RMSE_sum NEE_RMSE_aut ...
             rNEE_RMSE_win rNEE_RMSE_spr rNEE_RMSE_sum rNEE_RMSE_aut ...
            NEE_MAE_win NEE_MAE_spr NEE_MAE_sum NEE_MAE_aut ...
            NEE_BE_win NEE_BE_spr NEE_BE_sum NEE_BE_aut];
            
            
save ([path 'M' site '_model' num2str(GEP_model) '_NEEstats.dat'], 'NEE_stats','-ASCII');




