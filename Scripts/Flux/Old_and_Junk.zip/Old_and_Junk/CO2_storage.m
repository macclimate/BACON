function [] = CO2_storage(year,site)
%% CO2_storage.m
% This program calculates the changes in the amount of CO2 stored beneath
% the OPEC sensor, using CO2 concentration measured at the top of the
% canopy, or measured at different points in the profile
% Created July 31, 2007 by JJB
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths and Load Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Loading variables out of Met data
load_path_met = (['C:\Home\Matlab\Data\Met\Organized2\Met' site '\Column\30min\Met' site '_' year '.']);
hdr_path_met = (['C:\Home\Matlab\Data\Met\Organized2\Docs\Met' site 'Output_Columns_' year '.txt']);
%%% Loading variables out of Master Flux Table
load_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Organized2\Met' site '\Column\Met' site '_' year '.']);
hdr_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Organized2\Docs\Met' site '_Master_Columns.txt']);
%%% Output path
out_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated4\Met' site '\Met' site '_' year '_']);

%% Load Header Files
[hdr_cell_met] = jjb_hdr_read(hdr_path_met,'*');
[hdr_cell_op]  = jjb_hdr_read(hdr_path_op,'*');

%% Load Variables
%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);
%%% Air Temperature
T_air = jjb_load_var(hdr_cell_met, load_path_met, 'T_HMP_Top');
%%% Air Pressure
Pres =  jjb_load_var(hdr_cell_op, load_path_op, 'AtmoPr');
%%% CO2 Concentrations
CO2_top = jjb_load_var(hdr_cell_op, load_path_op,'CO2_top');
CO2_cpy = jjb_load_var(hdr_cell_op, load_path_op,'CO2_midcanopy');

%% Condition Data
%%% Pressure
Pres(Pres > 105 | Pres < 95, 1) = NaN;
%%% Method 1 - interpolation
Pres = interp_nan(dt, Pres);
%%% Method 2 - make missing values constant
% Pres (Pres > 105 | Pres < 95 | isnan(Pres)==0) == 99;

%%% CO2 Conc. - Convert from ppm to mole fraction of dry air (mg/m^3)
CO2_top_mg = CO2_convert(CO2_top, T_air, Pres,1);
CO2_cpy_mg = CO2_convert(CO2_cpy, T_air, Pres,1);

%%% Clean CO2 mole fraction values
CO2_top_mg(CO2_top_mg < 580 | CO2_top_mg > 1050, 1) = NaN; 
CO2_cpy_mg(CO2_top_mg < 580 | CO2_top_mg > 1050, 1) = NaN; 

%%% Shift CO2_top data by one point and take difference to get dc/dt
%%% Also cuts off the extra data point that is created by adding NaN
c1top = [NaN; CO2_top_mg(1:length(CO2_top_mg)-1)];
c2top = [CO2_top_mg(1:length(CO2_top_mg)-1) ; NaN];
c1cpy = [NaN; CO2_cpy_mg(1:length(CO2_cpy_mg)-1)];
c2cpy = [CO2_cpy_mg(1:length(CO2_cpy_mg)-1) ; NaN];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Set Value of z, ztop and zcpy 
%%%(ztop is distance btw cpy (Li-800) sensor and top (Li-7500) intakes)
%%%(zcpy is dist btw ground and cpy sensor)
param = params(year, site, 'CO2_storage');
z = param(:,1);     ztop = param(:,2);   zcpy = param(:,3);
col_flag = param(:,4);

%% Calculate CO2 storage in column below OPEC system: One-Height approach
dcdt = (c2top-c1top).*(z/1800).*(1000/44);  %% What is this equation????

%%%Criteria consistent or make %them adjustable depending on site??
dcdt(dcdt < -10 | dcdt > 10, 1) = NaN;

%% 2 - Height section approach
if col_flag == 2 % Calculate for the top and bottom halves
%%% top
    dcdt_top = (c2top-c1top).*(ztop/1800).*(1000/44);  %% What is this equation????
%%% bottom
    dcdt_cpy = (c2cpy-c1cpy).*(zcpy/1800).*(1000/44);  %% What is this equation????
elseif col_flag == 1;
    dcdt_top(1:length(dcdt),1) = Nan;
    dcdt_cpy(1:length(dcdt),1) = Nan;
end
%%% Add top and bottom storages
dcdt_sum = dcdt_top + dcdt_cpy;

%% Clean and fill data (remove outliers (greater than +/- 10))
dcdt(dcdt < -10 | dcdt > 10 , 1) = NaN;
dcdt_fill= interp_nan(dt,dcdt);

dcdt_sum(dcdt_sum < -10 | dcdt_sum > 10,1) = NaN;
dcdt_sum_fill = interp_nan(dt,dcdt_sum);

%% SAVE Variables
save ([out_path_op 'dcdt.dat'],'dcdt','-ASCII');
save ([out_path_op 'dcdt_cleaned.dat'],'dcdt_fill','-ASCII');

save ([out_path_op 'dcdt_sum.dat'],'dcdt_sum','-ASCII');
save ([out_path_op 'dcdt_sum_cleaned.dat'],'dcdt_sum_fill','-ASCII');

save ([out_path_op 'CO2mg_top_cleaned.dat'],'CO2_top_mg','-ASCII');
save ([out_path_op 'CO2mg_cpy_cleaned.dat'],'CO2_cpy_mg','-ASCII');



