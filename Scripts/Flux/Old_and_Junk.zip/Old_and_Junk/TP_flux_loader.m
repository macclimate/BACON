% function [] = TP_flux_loader(site,st_yr, end_yr)
site = '1';
st_yr = 2003;
end_yr = 2007;

%% TP_loader 
% This function loads files to be used in flux calculations at all TP sites

if ischar(site) == false
    site = num2str(site);
end

if ispc == 1
% path = ['C:/HOME/MATLAB/Data/Data_Analysis/M' site '_allyears/'];
data_loc = 'C:/Home/';
path = [data_loc 'MATLAB/Data/Data_Analysis/M' site '_allyears/'];

else
    
% path = ['/home/jayb/MATLAB/work/TP/'];
data_loc = '/home/jayb/';

path = [data_loc 'MATLAB/Data/Data_Analysis/M' site '_allyears/'];
end
%% Check if variables already exist -- If not, Create open variables for 2003-2007

% if exist([path 'M' site '_all_yrs_data.dat']) == 2;
%     out_flag = 0;
%     all_vars = load([path 'M1_all_yrs_data.dat']);
% T_air1 = all_vars(:,1);
% PAR1 = all_vars(:,2);
% Ts1 = all_vars(:,3);
% SM1 = all_vars(:,4);
% NEE1 = all_vars(:,5); NEE1(NEE1 > 35 | NEE1 < -35) = NaN;
% ustar1 = all_vars(:,6);
% dt1 = all_vars(:,7);
% year1 = all_vars(:,8);
% WS1 = all_vars(:,9);
% Wdir1 = all_vars(:,10);
% VPD1 = all_vars(:,11);
% clear all_vars;
% 
% else
% out_flag = 1;    

%%% Create open variables
n_yrs = end_yr-st_yr+1;
dtt(1:17568,1:n_yrs) = NaN; NEE(1:17568,1:n_yrs) = NaN; Ts(1:17568,1:n_yrs) = NaN; T_air(1:17568,1:n_yrs) = NaN; 
PAR(1:17568,1:n_yrs) = NaN; SM5a(1:17568,1:n_yrs) = NaN; SM5b(1:17568,1:n_yrs) = NaN; SM10a(1:17568,1:n_yrs) = NaN; 
SM10b(1:17568,1:n_yrs) = NaN; SM20a(1:17568,1:n_yrs) = NaN; SM20b(1:17568,1:n_yrs) = NaN; ustar(1:17568,1:n_yrs) = NaN; 
year1(1:17568,1:n_yrs) = NaN; WS(1:17568,1:n_yrs) = NaN; Wdir(1:17568,1:n_yrs) = NaN; RH(1:17568,1:n_yrs) = NaN;
SM50a(1:17568,1:n_yrs) = NaN; SM50b(1:17568,1:n_yrs) = NaN; SM100a(1:17568,1:n_yrs) = NaN; SM100b(1:17568,1:n_yrs) = NaN;
%% Load variables for years 2003-2006
yr_ctr = 1;   

for i = st_yr:1:end_yr
year = num2str(i);    
 if str2num(year) < 2007
     data_type = 'master';
 else
     data_type = 'processed';
 end
%%% Create year and dt vectors for year:
[yr junk(:,1) junk(:,2) dt]  = jjb_makedate(str2double(year),30);
%%% Load Pre-Processed data
NEE(1:length(dt),yr_ctr) = load([data_loc 'MATLAB/Data/Flux/OPEC/Calculated5/Met' site '/Met' site '_' year '_NEE_uncut.dat']);
Ts2(1:length(dt),yr_ctr) = load([data_loc 'MATLAB/Data/Met/Calculated4/Met' site '/Met' site '_' year '_Ts.dat']);

%%% Load met vars:
[vars_out] = jjb_flux_load('Analysis', year, site, data_type, data_type);
T_air(1:length(dt),yr_ctr) = vars_out(:,1);
PAR(1:length(dt),yr_ctr) = vars_out(:,2);
WS(1:length(dt),yr_ctr) = vars_out(:,3);
SM5a(1:length(dt),yr_ctr) = vars_out(:,5);
SM5b(1:length(dt),yr_ctr) = vars_out(:,6);
SM10a(1:length(dt),yr_ctr) = vars_out(:,7);
SM10b (1:length(dt),yr_ctr) = vars_out(:,8);
SM20a (1:length(dt),yr_ctr) = vars_out(:,9);
SM20b(1:length(dt),yr_ctr) = vars_out(:,10);
ustar(1:length(dt),yr_ctr) = vars_out(:,11);
Wdir(1:length(dt),yr_ctr) = vars_out(:,14);
RH(1:length(dt),yr_ctr) = vars_out(:,15);
RHc(1:length(dt),yr_ctr) = vars_out(:,16);
Ts5a(1:length(dt),yr_ctr) = vars_out(:,17);
Ts5b(1:length(dt),yr_ctr) = vars_out(:,18);
PAR_up(1:length(dt),yr_ctr) = vars_out(:,19);
dtt(1:length(dt),yr_ctr) = dt(:,1);
yrr(1:length(dt),yr_ctr) = yr(:,1);

[vars_out2] = jjb_flux_load('HR', year, site, data_type, data_type);

SM50a(1:length(dt),yr_ctr) = vars_out2(:,5);
SM50b (1:length(dt),yr_ctr) = vars_out2(:,6);
SM100a (1:length(dt),yr_ctr) = vars_out2(:,7);
SM100b(1:length(dt),yr_ctr) = vars_out2(:,8);

clear vars_out vars_out2 

[vars_out3] = jjb_flux_load('EB', year, site, data_type, data_type);
Hs_orig(1:length(dt),yr_ctr) = vars_out3(:,1);
LE_orig (1:length(dt),yr_ctr) = vars_out3(:,2);
Jt(1:length(dt),yr_ctr) = vars_out3(:,3); 
G0(1:length(dt),yr_ctr) = vars_out3(:,4);
Rn(1:length(dt),yr_ctr) = vars_out3(:,5);

clear vars_out3 dt yr junk
yr_ctr = yr_ctr + 1;
end

%% Load variables for year 2007
% year = '2007';
% [yr junk(:,1) junk(:,2) dt]  = jjb_makedate(str2double(year),30);

% NEE(1:length(dt),5) = load(['C:/Home/Matlab/Data/Flux/OPEC/Calculated5/Met' site '/Met' site '_' year '_NEE_uncut.dat']);
% Ts(1:length(dt),5) = load(['C:/HOME/MATLAB/Data/Met/Calculated4/Met' site '/Met' site '_' year '_Ts.dat']);

% 
% 
% [vars_out] = jjb_flux_load('Analysis', year, site, 'processed', 'processed');
% T_air(1:length(dt),5) = vars_out(:,1);
% PAR(1:length(dt),5) = vars_out(:,2);
% WS(1:length(dt),5) = vars_out(:,3);
% SM5a(1:length(dt),5) = vars_out(:,5);
% SM5b(1:length(dt),5) = vars_out(:,6);
% SM10a(1:length(dt),5) = vars_out(:,7);
% SM10b (1:length(dt),5) = vars_out(:,8);
% SM20a (1:length(dt),5) = vars_out(:,9);
% SM20b(1:length(dt),5) = vars_out(:,10);
% ustar(1:length(dt),5) = vars_out(:,11);
% Wdir(1:length(dt),5) = vars_out(:,14);
% RH(1:length(dt),5) = vars_out(:,15);
% RHc(1:length(dt),5) = vars_out(:,16);
% Ts5a(1:length(dt),5) = vars_out(:,17);
% Ts5b(1:length(dt),5) = vars_out(:,18);

% dtt(1:length(dt),5) = dt(:,1);
% yrr(1:length(dt),5) = yr(:,1);
% 
% clear vars_out dt yr;
%% Replace 2005 met2 Ts data during early spring with data from Met 1;
if strcmp(site,'2') == 1
M1_Ts5a = load([data_loc 'MATLAB/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.038']);
M1_Ts5b = load([data_loc 'MATLAB/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2005.044']);
yrrlist = yrr(1,1:n_yrs); yrrlist = yrrlist';
col05 = find(yrrlist == 2005);
Ts5a(4498:5736,col05) = M1_Ts5a(4498:5736,1);
Ts5b(4498:5736,col05) = M1_Ts5b(4498:5736,1);
%%%Replace Met 2 2003 data
M1_data = jjb_flux_load('Analysis', '2003', '1', 'master', 'master');
col03 = find(yrrlist == 2003);
Ts5a(isnan(Ts5a(1:17520,col03)),col03) = M1_data(isnan(Ts5a(1:17520,col03)),17);
Ts5b(isnan(Ts5b(1:17520,col03)),col03) = M1_data(isnan(Ts5b(1:17520,col03)),18);

PAR(isnan(PAR(1:17520,col03)),col03) = M1_data(isnan(PAR(1:17520,col03)),2);
T_air(isnan(T_air(1:17520,col03)),col03) = M1_data(isnan(T_air(1:17520,col03)),1);
RH(isnan(RH(1:17520,col03)),col03) = M1_data(isnan(RH(1:17520,col03)),15);
clear M1_data
%%%Replace Met 2 2004 data
M1_data = jjb_flux_load('Analysis', '2004', '1', 'master', 'master');
col04 = find(yrrlist == 2004);
Ts5a(isnan(Ts5a(1:17568,col04)),col04) = M1_data(isnan(Ts5a(1:17568,col04)),17);
Ts5b(isnan(Ts5b(1:17568,col04)),col04) = M1_data(isnan(Ts5b(1:17568,col04)),18);

PAR(isnan(PAR(1:17568,col04)),col04) = M1_data(isnan(PAR(1:17568,col04)),2);
T_air(isnan(T_air(1:17568,col04)),col04) = M1_data(isnan(T_air(1:17568,col04)),1);
RH(isnan(RH(1:17568,col04)),col04) = M1_data(isnan(RH(1:17568,col04)),15);
end

%% Replace 2004 met4 PAR data with data from Met 1;
if strcmp(site,'4') == 1
M1_PAR = load([data_loc 'MATLAB/Data/Flux/OPEC/Organized2/Met1/Column/Met1_2004.023']);

yrrlist = yrr(1,1:n_yrs); yrrlist = yrrlist';
col_04 = find(yrrlist == 2004);
PAR(isnan(PAR(:,col_04)),col_04) = M1_PAR(isnan(PAR(:,col_04)),1);

M1data = jjb_flux_load('Analysis', '2004', '1', 'master', 'master');



Ta_04 = T_air(1:17568,col_04); Ta_04(isnan(Ta_04),1) = M1data(isnan(Ta_04),1);
T_air(1:17568,col_04) = Ta_04;

Ts5a_04 = Ts5a(1:17568,col_04);

RH_04 = RH(1:17568,col_04); RH_04(isnan(RH_04),1) = M1data(isnan(RH_04),15); 
RH(1:17568,col_04) = RH_04;

[Ts5a_04_filled_md Ts5a_04_model_md] = jjb_WLR_gapfill(Ta_04, Ts5a_04, 1500, 'on');
[Ts5a_04_filled_lg Ts5a_04_model_lg] = jjb_WLR_gapfill(Ta_04, Ts5a_04, 700, 'on');
[Ts5a_04_filled_sm Ts5a_04_model_sm] = jjb_WLR_gapfill(Ta_04, Ts5a_04, 350, 'on');

% figure(8)
% clf
% subplot(3,1,1)
% plot(Ts5a_04_model_lg)
% hold on
% plot(Ts5a_04,'g')
% plot(Ta_04,'r')
% subplot(3,1,2)
% plot(Ts5a_04_model_md)
% hold on
% plot(Ts5a_04,'g')
% plot(Ta_04,'r')
% subplot(3,1,3)
% plot(Ts5a_04_model_sm)
% hold on
% plot(Ts5a_04,'g')
% plot(Ta_04,'r')

Ts5a_04(3576:3925,1) = Ts5a_04_model_sm(3576:3925,1);
Ts5a_04(6355:6600,1) = Ts5a_04_model_sm(6355:6600,1);
Ts5a_04(6600:6948,1) = Ts5a_04_model_lg(6600:6948,1);
Ts5a_04(isnan(Ts5a_04),1) = Ts5a_04_model_lg(isnan(Ts5a_04),1);
Ts5a(1:17568,col_04) = Ts5a_04;

clear M1data;


%% Fill Met 4 file for missing values in 2005:
M1data = jjb_flux_load('Analysis', '2005', '1', 'processed', 'processed');
% st_05 = 35137; en_05 = 52704; % start and end rows for 2005 in 1 column files

col05 = find(yrrlist == 2005);

Ta_05 = T_air(1:17520,col05); %RH_05 = RH(1:17520,col05); PAR_05 = PAR(1:17520,col05);
Ts5a_05 = Ts5a(1:17520,col05);

%%% Ta
% Ta_05(isnan(Ta_05),1) = M1data(isnan(Ta_05),1); 
% T_air(1:17520,col05) = Ta_05;
%      
% RH_05(isnan(RH_05),1) = M1data(isnan(RH_05),1); 
% RH1(1:17520,col05) = RH_05;
% 
% PAR_05(isnan(PAR_05),1) = M1data(isnan(PAR_05),1); 
% PAR1(1:17520,col05) = PAR_05;

[Ts5a_05_filled_md Ts5a_05_model_md] = jjb_WLR_gapfill(Ta_05, Ts5a_05, 1500, 'on');
[Ts5a_05_filled_lg Ts5a_05_model_lg] = jjb_WLR_gapfill(Ta_05, Ts5a_05, 700, 'on');
[Ts5a_05_filled_sm Ts5a_05_model_sm] = jjb_WLR_gapfill(Ta_05, Ts5a_05, 350, 'on');

Ts5a_05(1:1046,1) = Ts5a_05_model_md(1:1046,1);
Ts5a_05(isnan(Ts5a_05),1) = Ts5a_05_model_md(isnan(Ts5a_05),1);
Ts5a(1:17520,col05) = Ts5a_05;


% figure(8)
% clf
% subplot(3,1,1)
% plot(Ts5a_05_model_lg)
% hold on
% plot(Ts5a_05,'g')
% plot(Ta_05,'r')
% subplot(3,1,2)
% plot(Ts5a_05_model_md)
% hold on
% plot(Ts5a_05,'g')
% plot(Ta_05,'r')
% subplot(3,1,3)
% plot(Ts5a_05_model_sm)
% hold on
% plot(Ts5a_05,'g')
% plot(Ta_05,'r')

end


%% Clean soil moisture data and depth-weight average
SM5a(SM5a < 0 | SM5a > 1) = NaN; SM5b(SM5b < 0 | SM5b > 1) = NaN;
SM10a(SM10a < 0 | SM10a > 1) = NaN; SM10b(SM10b < 0 | SM10b > 1) = NaN;
SM20a(SM20a < 0 | SM20a > 1) = NaN; SM20b(SM20b < 0 | SM20b > 1) = NaN;

SM5a(isnan(SM5a)) = SM5b(isnan(SM5a));
SM10a(isnan(SM10a)) = SM10b(isnan(SM10a));
SM20a(isnan(SM20a)) = SM20b(isnan(SM20a));

%%% predict SM @ 15cm using average of 10 and 20 cm
SM15a = (SM10a+SM20a)./2;
SM15a(isnan(SM15a)) = SM10a(isnan(SM15a));
%%% average SM @ 5cm and SM @ 15cm to get average for top 20cm
SM = (SM5a+SM15a)./2;
SM(SM < 0 | SM > 0.6) = NaN;

%% Retrieve one 5cm Soil Temperature Value
Ts5a(Ts5a< -30 | Ts5a > 40) = NaN; Ts5b(Ts5b< -30 | Ts5b > 40) = NaN;

Ts5 = (Ts5a+Ts5b)/2;
Ts5(Ts5<-20) = NaN;
Ts5(isnan(Ts5)) = Ts5a(isnan(Ts5));
Ts5(isnan(Ts5)) = Ts5b(isnan(Ts5));
Ts5(Ts5<-20) = NaN;

%% Load precip data
PPTx = dlmread([data_loc 'MATLAB/Data/Data_Analysis/Precip_data/Delhi_Day_Precip_2002_2007.csv'],',');
PPT(1).all = PPTx(:,2); PPT(2).all = PPTx(:,3); PPT(3).all = PPTx(:,4);
PPT(4).all = PPTx(:,5); PPT(5).all = PPTx(:,6);

%% Make a Precip File that is averaged out to make hhour data from daily
%%% averages, and a file that has all precip for one day as the first value
PPT48(1:17568,1:n_yrs) = NaN; PPThh(1:17568,1:n_yrs) = NaN;
for col = 1:1:n_yrs
    day_ctr = 1;
    for ctr = 1:48:17521

PPThh(ctr+23,col) = PPT(col).all(day_ctr);
PPT48(ctr:ctr+47,col) = (PPT(col).all(day_ctr))./48;
day_ctr = day_ctr+1;
    end
end
   

%% Reshape all data into single columns
T_air1 = reshape(T_air,[],1);
PAR1 = reshape(PAR,[],1);
Ts21 = reshape(Ts2,[],1);
SM1 = reshape(SM,[],1);
NEE1 = reshape(NEE,[],1); NEE1(NEE1 > 35 | NEE1 < -35) = NaN;
ustar1 = reshape(ustar,[],1);
dt1 = reshape(dtt,[],1);
year1 = reshape(yrr,[],1);
WS1 = reshape(WS,[],1);
Wdir1 = reshape(Wdir,[],1);
RH1 = reshape(RH,[],1);
RHc1 = reshape(RHc,[],1);
Ts51 = reshape(Ts5,[],1);
PPThh1 = reshape(PPThh,[],1);
PPT481 = reshape(PPT48,[],1);
SM50a1 = reshape(SM50a,[],1);
SM100a1 = reshape(SM100a,[],1);
SM50b1 = reshape(SM50b,[],1);
SM100b1 = reshape(SM100b,[],1);
SM10a1 = reshape(SM10a,[],1);
SM20a1 = reshape(SM20a,[],1);
SM10b1 = reshape(SM10b,[],1);
SM20b1 = reshape(SM20b,[],1);
SM5a1 = reshape(SM5a,[],1);
SM5b1 = reshape(SM5b,[],1);
Hs1 = reshape(Hs_orig,[],1);
LE1 = reshape(LE_orig,[],1);
Jt1 = reshape(Jt,[],1);
G01 = reshape(G0,[],1);
Rn1 = reshape(Rn,[],1);
PAR_up1 = reshape(PAR_up,[],1);

clear NEE Ts2 T_air PAR SM5a SM5b SM10a SM10b SM20a SM20b ustar dtt junk yrr WS Wdir RH;
clear SM50a SM50b SM100a SM100b PPThh PPT48 SM PPTx PPT Hs_orig LE_orig Jt G0 Rn PAR_up;




%% Fill gap in PAR for 2007 with PAR from Met2:
if strcmp(site,'1') ==1
RH1(isnan(RH1)) = RHc1(isnan(RH1)) ;    
M2_PAR(1:length(PAR1),1) = NaN;
M2_PAR(70273:87792,1)= load([data_loc 'MATLAB/Data/Met/Cleaned3/Met2/Met2_2007.013']);
PAR1(year1 == 2007 & (PAR1 < -5 | isnan(PAR1))) = M2_PAR(year1 == 2007 & (PAR1 < -5 | isnan(PAR1)));
end

%% Convert RH into VPD:
esat = 0.6108.*exp((17.27.*T_air1)./(237.3+T_air1));
e = (RH1.*esat)./100;
VPD1 = esat-e;

clear RH1 esat e;

%% Make a seperate VPD file, where only data between 11 and 1400 exist
% (midday values)
VPDmd1(1:length(VPD1),1) = NaN;
for ctr2 = 22:48:length(VPDmd1)-26
    VPDmd1(ctr2:ctr2+6,1) = VPD1(ctr2:ctr2+6,1);
end

%% Save variables
% if isequal(out_flag,1)==1
all_yrs_data = [T_air1 PAR1 Ts21 SM1 NEE1 ustar1 dt1 year1 WS1 Wdir1 VPD1 Ts51 VPDmd1 PPThh1 PPT481 ...
                SM50a1 SM50b1 SM100a1 SM100b1 SM10a1 SM10b1 SM20a1 SM20b1 SM5a1 SM5b1 PAR_up1];

save([path 'M' site '_all_yrs_data.dat'],'all_yrs_data','-ASCII')
clear all_yrs_data
% end

EB_data = [Hs1 LE1 Jt1 G01 Rn1];
save([path 'M' site '_EB_data.dat'],'EB_data','-ASCII');
clear EB_data;

%% Plot key variables to look for gaps that need to be filled:
figure(4); clf
subplot(4,1,1)
plot(SM1)
ylabel('SM1')
subplot(4,1,2)
plot(PAR1)
ylabel('PAR1')
subplot(4,1,3)
plot(Ts51)
ylabel('Ts51')
subplot(4,1,4)
plot(VPD1)
ylabel('VPD1')
