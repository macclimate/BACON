model_list = [1 3 4 5 6];
close all
for t = 1:1:4
switch t
    case 1
 site = '1'; stamp = '39';       
    case 2
site = '2'; stamp = '74';
    case 3
site = '3'; stamp = '89';   
    case 4
site = '4'; stamp = '04';
end
if ispc == 1
    path = ['C:\HOME\MATLAB\Data\Data_Analysis\M' site '_allyears\'];
        fig_path = 'C:\HOME\MATLAB\Data\CCP Pres\CCP_Figs\';
else
    path = ['/home/jayb/MATLAB/Data/Data_Analysis/M' site '_allyears/'];
end


 start_row = 1;   
   for j = 1:1:length(model_list)
      
       GEP_model = model_list(j);
       
 temp = load([path 'M' site '_model' num2str(GEP_model) '_flux_results.dat']);
results(t).all(start_row:start_row+4,:) = temp;

clear temp;

start_row = start_row+5;

   end
   
end
%%
yr_labels = ['2003';'2004';'2005';'2006';'2007'];
yr_ticks = (1:1:5);
colorlist = ['b' 'r' 'g' 'm' 'c' 'y'];
symlist = ['o';'s';'v';'p';'^'];
 %% Figure 1 - comparison of outputs for Met 2:
% figure(1);clf
% title('Comparison for Met 2');
% subplot(3,1,1)
% plot(M2_model1(:,1),'b.-'); hold on
% plot(M2_model3(:,1),'rx-'); 
% plot(M2_model4(:,1),'gp-'); 
% title('NEE - Met 2')
% legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
% set(gca,'XTick',yr_ticks);
% set(gca,'XTickLabel',yr_labels);
% grid on

%% Comparison for Met 1:
figure(1); clf
c_ctr = 1;

for j = 11%:5:21
    figure(1)
    subplot(3,1,1)
    plot(results(1).all(j:j+4,2).*-1,'o-','MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','Color',colorlist(c_ctr),'LineWidth',4); hold on;

    subplot(3,1,2)
    plot(results(1).all(j:j+4,4),'o-','MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','Color',colorlist(c_ctr+1),'LineWidth',4); hold on;
    
    subplot(3,1,3)
    plot(results(1).all(j:j+4,8),'o-','MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','Color',colorlist(c_ctr+2),'LineWidth',4); hold on;

    figure(7)
    subplot(2,1,1)
    plot((1:1:5),results(1).all(j:j+4,2).*-1,'.','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8); hold on;
    
    figure(11); hold on;
   plot(results(1).all(j:j+4,2).*-1,'v--','MarkerFaceColor',[0.6 0.2 0.6],'MarkerEdgeColor','k', 'MarkerSize',10,'Color',[0.6 0.2 0.6]); hold on;
    
        c_ctr = c_ctr+1;
end
figure(1)
subplot(3,1,1)
ylabel('NEP (g C m^{-2} s^{-1})','FontSize',14);
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
set(gca,'FontSize',14);
grid on

subplot(3,1,2)
% title('Re - Met 1')
% legend('Mod1','Mod3', 'Mod4', 'Mod5', 'Mod6',3)
ylabel('R (g C m^{-2} s^{-1})','FontSize',14);
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
set(gca,'FontSize',14);
grid on

subplot(3,1,3)
% title('GEP - Met 1')
ylabel('P (g C m^{-2} s^{-1})','FontSize',14);
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
set(gca,'FontSize',14);
grid on

% line([0 6],[0 0], 'LineStyle','--','Color','k','LineWidth',1)
set(gca,'YGrid','on')
% ylabel('R (g C m^{-2} s^{-1})','FontSize',18);


% print('-dbmp','/home/jayb/Desktop/1A_Figs/m1flux')






% figure(5); clf
% c_ctr = 1;
% 
% for j = 1:5:21
%     subplot(3,1,1)
%     plot(results(1).all(j:j+4,2).*-1,'o-','Color',colorlist(c_ctr)); hold on;
% 
%     subplot(3,1,2)
%     plot(results(1).all(j:j+4,4),'o-','Color',colorlist(c_ctr)); hold on;
%     
%     subplot(3,1,3)
%     plot(results(1).all(j:j+4,8),'o-','Color',colorlist(c_ctr)); hold on;
% 
%         c_ctr = c_ctr+1;
% end
% 


%% Comparison for Met 2:
figure(2); clf
c_ctr = 1;

for j = 1:5:21
    figure(2)
    subplot(3,1,1)
    plot(results(2).all(j:j+4,2).*-1,'o-','Color',colorlist(c_ctr)); hold on;

    subplot(3,1,2)
    plot(results(2).all(j:j+4,4),'o-','Color',colorlist(c_ctr)); hold on;
    
    subplot(3,1,3)
    plot(results(2).all(j:j+4,8),'o-','Color',colorlist(c_ctr)); hold on;

    figure(7); hold on;
    subplot(2,1,2)
    plot((1:1:5),results(2).all(j:j+4,2).*-1,'.','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8); hold on;

    figure(10)
    subplot(3,1,1)
  if j == 6  
  plot((1:1:5),results(2).all(j:j+4,2).*-1,'r-','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8, 'LineWidth',4); hold on;
  figure(11); hold on;
          plot(results(2).all(j:j+4,2).*-1,'o--','MarkerFaceColor','b','MarkerEdgeColor','k', 'MarkerSize',10,'Color','b'); hold on;
  
  
  else
    plot((1:1:5),results(2).all(j:j+4,2).*-1,'.','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8); hold on;
  end
   
    
    if j == 16
        figure(8); hold on
%         subplot(2,1,1)
        plot(results(2).all(j:j+4,2).*-1,'o--','MarkerFaceColor','b','MarkerEdgeColor','k', 'MarkerSize',10,'Color','b'); hold on;
%         subplot(2,1,2)
%         plot(results(2).all(j:j+4,4).*-1,'o--','MarkerFaceColor','b','MarkerEdgeColor','k', 'MarkerSize',10,'Color','b'); hold on;
%         plot(results(2).all(j:j+4,8).*1,'o--','MarkerFaceColor','b','MarkerEdgeColor','k', 'MarkerSize',10,'Color','b'); hold on;
    end
        c_ctr = c_ctr+1;
end
figure(2)
subplot(3,1,1)
title('NEP - Met 2')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
title('Re - Met 2')
legend('Mod1','Mod3', 'Mod4', 'Mod5', 'Mod6',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
title('GEP - Met 2')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

%% Comparison for Met 3:
figure(3); clf
c_ctr = 1;

for j = 1:5:21
    figure(3)
    subplot(3,1,1)
    plot(results(3).all(j:j+4,2).*-1,'o-','Color',colorlist(c_ctr)); hold on;

    subplot(3,1,2)
    plot(results(3).all(j:j+4,4),'o-','Color',colorlist(c_ctr)); hold on;
    
    subplot(3,1,3)
    plot(results(3).all(j:j+4,8),'o-','Color',colorlist(c_ctr)); hold on;

        figure(10)
    subplot(3,1,2)
      if j == 6  
  plot((1:1:5),results(3).all(j:j+4,2).*-1,'r-','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8, 'LineWidth',4); hold on;
  figure(11); hold on;
  plot(results(3).all(j:j+4,2).*-1,'p--','MarkerFaceColor','g','MarkerEdgeColor','k', 'MarkerSize',10,'Color','g'); hold on;

      else

    plot((1:1:5),results(3).all(j:j+4,2).*-1,'.','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8); hold on;
      end
    
    if j == 16
        figure(8); hold on

        plot(results(3).all(j:j+4,2).*-1,'p--','MarkerFaceColor','g','MarkerEdgeColor','k', 'MarkerSize',10,'Color','g'); hold on;
    end
    
    
        c_ctr = c_ctr+1;
end
figure(3)
subplot(3,1,1)
title('NEP - Met 3')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
title('Re - Met 3')
legend('Mod1','Mod3', 'Mod4', 'Mod5', 'Mod6',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
title('GEP - Met 3')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on
    

%% Comparison for Met 4:
figure(4); clf
c_ctr = 1;

for j = 1:5:21
    figure(4)
    subplot(3,1,1)
    plot(results(4).all(j:j+4,2).*-1,'o-','Color',colorlist(c_ctr)); hold on;

    subplot(3,1,2)
    plot(results(4).all(j:j+4,4),'o-','Color',colorlist(c_ctr)); hold on;
    
    subplot(3,1,3)
    plot(results(4).all(j:j+4,8),'o-','Color',colorlist(c_ctr)); hold on;
    
    figure(10)
    subplot(3,1,3)
      if j == 6  
  plot((1:1:5),results(4).all(j:j+4,2).*-1,'r-','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8, 'LineWidth',4); hold on;
  figure(11); hold on;
          plot(results(4).all(j:j+4,2).*-1,'s--','MarkerFaceColor','r','MarkerEdgeColor','k', 'MarkerSize',10,'Color','r'); hold on;
      
      else
    plot((1:1:5),results(4).all(j:j+4,2).*-1,'.','Marker',symlist(c_ctr),'MarkerFaceColor',colorlist(c_ctr),'MarkerEdgeColor','k','MarkerSize',8); hold on;
      end
    
    if j == 16
        figure(8); hold on
        plot(results(4).all(j:j+4,2).*-1,'s--','MarkerFaceColor','r','MarkerEdgeColor','k', 'MarkerSize',10,'Color','r'); hold on;
    end

        c_ctr = c_ctr+1;
end
figure(4)
subplot(3,1,1)
title('NEP - Met 4')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
title('Re - Met 4')
legend('RA-GCA','RA-GCY', 'RY-GCY', 'RA-GUY', 'RA-G',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
title('GEP - Met 4')
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on


figure(8)
XTicks = (0:1:6)';
XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 -200 1000])                
set(gca,'XTick',XTicks)
set(gca,'XTickLabel',XTickLabels,'FontSize',18)
legend('TP74','TP89','TP02',1);
line([0 6],[0 0], 'LineStyle','--','Color','k','LineWidth',1)
set(gca,'YGrid','on')
ylabel('NEP (g C m^{-2} y^{-1})','FontSize',18);
print('-dbmp',[fig_path 'M2_4_Fluxes'])
print('-depsc',[fig_path 'M2_4_Fluxes'])


figure(11)
XTicks = (0:1:6)';
XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 -200 1000])                
set(gca,'XTick',XTicks)
set(gca,'XTickLabel',XTickLabels,'FontSize',18)
legend('TP39','TP74','TP89','TP02',1);
line([0 6],[0 0], 'LineStyle','--','Color','k','LineWidth',1)
set(gca,'YGrid','on')
ylabel('NEP (g C m^{-2} y^{-1})','FontSize',18);
print('-dbmp',[fig_path 'M1_4_Fluxes'])
print('-depsc',[fig_path 'M1_4_Fluxes'])



figure(7)
subplot(2,1,1)
XTicks = (0:1:6)';
YTicks = [0; 200; 400; 600; 800];
YTickLabels = [0; 200; 400; 600; 800];

XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 0 800])                
set(gca,'XTick',XTicks,'YTick',YTicks)
set(gca,'XTickLabel',XTickLabels,'FontSize',16)
set(gca,'YTickLabel',YTickLabels,'FontSize',14)
legend('RA-GCA','RA-GCY', 'RY-GCY', 'RA-GUY', 'RA-GUA',2)
set(gca,'YGrid','on')
subplot(2,1,2)
YTicks = [0; 200; 400; 600; 800];
YTickLabels = [0; 200; 400; 600; 800];

XTicks = (0:1:6)';
XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 0 800])                
set(gca,'XTick',XTicks,'YTick',YTicks)
set(gca,'XTickLabel',XTickLabels,'FontSize',16)
set(gca,'YTickLabel',YTickLabels,'FontSize',14)
% set(gca,'XTickLabel',XTickLabels,'FontSize',18)


% line([-1 6],[0 0], 'LineStyle','--','Color','k','LineWidth',2)
set(gca,'YGrid','on')
ylabel('                                    NEP (g C m^{-2} y^{-1})','FontSize',16);
print('-dbmp',[fig_path 'M1_2_Models'])
print('-depsc',[fig_path 'M1_2_Models'])


figure(10)
subplot(3,1,1)
XTicks = (0:1:6)';
YTicks = [0; 200; 400; 600; 800];
YTickLabels = [0; 200; 400; 600; 800];

XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 0 800])                
set(gca,'XTick',[],'YTick',YTicks)
set(gca,'YTick',YTicks)
% set(gca,'XTickLabel',XTickLabels,'FontSize',16)
set(gca,'YTickLabel',YTickLabels,'FontSize',14)
% legend('RA-GCA','RA-GCY', 'RY-GCY', 'RA-GUY', 'RA-GUA',2)
set(gca,'YGrid','on')

subplot(3,1,2)
YTicks = [600; 700; 800; 900; 1000];
YTickLabels = [600; 700; 800; 900; 1000];

XTicks = (0:1:6)';
XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 600 1000])                
set(gca,'XTick',XTicks,'YTick',YTicks)
set(gca,'XTickLabel',XTickLabels,'FontSize',16)
set(gca,'YTickLabel',YTickLabels,'FontSize',14)
% set(gca,'XTickLabel',XTickLabels,'FontSize',18)


% line([-1 6],[0 0], 'LineStyle','--','Color','k','LineWidth',2)
set(gca,'YGrid','on')
ylabel('NEP (g C m^{-2} y^{-1})','FontSize',16);

subplot(3,1,3)
YTicks = [-200; -100; 0; 100; 200];
YTickLabels = [-200; -100; 0; 100; 200];

XTicks = (0:1:6)';
XTickLabels = ['    ';'2003';'2004';'2005';'2006';'2007';'    '];
axis([0 6 -200 300])                
set(gca,'XTick',[],'YTick',YTicks)
% set(gca,'XTickLabel',XTickLabels,'FontSize',16)
set(gca,'YTickLabel',YTickLabels,'FontSize',14)
% set(gca,'XTickLabel',XTickLabels,'FontSize',18)


% line([-1 6],[0 0], 'LineStyle','--','Color','k','LineWidth',2)
set(gca,'YGrid','on')
% ylabel('NEP (g C m^{-2} y^{-1})','FontSize',16);




print('-dbmp',[fig_path 'M234_Results'])
print('-depsc',[fig_path 'M234_Results'])

