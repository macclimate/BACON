clear all;

fid = fopen('C:\Home\Matlab\Data\Met\Organized2\Docs\Met1Output_Columns_2007.txt');
i = 1;
eofstat = 0;
while eofstat == 0;                             %% Scans through the lines of the header file until reaching the end of file
    tline = fgets(fid);                             %% Read a line
%     spaces = find(isspace(tline)==1);   
file(i,:) = tline;
i = i +1;
eofstat = feof(fid);
end

for j = 1:length(file)
    an = isstrprop(file(j,:),'alphanum');
    sp = isstrprop(file(j,:),'wspace');
    u_score(j,:) = find(an==0 & sp==0);             %%%Need to also make look for brackets
end
col(:,:) = file(:,1:u_score(1)-1);
Filename(:,:) = file(:,u_score(1)+1:u_score(2)-1);




% g = [an; sp];
%%%isstrprop