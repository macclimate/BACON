% This program calculates the CO2 storage (umol m-2 s-1) from the groud to the 
% measurement level.
%
% (c)Bill Chen                                    File created:  May. 27, 1998
%                                                 Last modified: Oct. 07, 1999
%

% Revision:
%           Oct. 07, 1999 by Bill Chen
%           - add 1999 data
%           Sep. 14, 1999 by Bill Chen
%           - seperate this program out from NEE_cal.m
% March 22, 2000, Altaf Arain
%	- SOBS site
%% April 05, 2001, Altaf Arain
% - modified for 2000 data 
% Modified for GRFS, Altaf Arain, Dec 8, 2004
% Modified for TP Met4 OPEC 2005 data. Altaf ad Mathias, May 26, 2006

% --- get time series ---
load decdoy_00.txt;
dt = decdoy_00(1:17520);


% --- get CO2 concentration in mg at top of tower ---
load C:\data\turkey\m4\2005\m4CO2mgtop.txt
load C:\data\turkey\m4\2005\m4CO2mgcpy.txt

CO2mgtop = m4CO2mgtop;
CO2mgcpy = m4CO2mgcpy;

% --- calculate storage term (dc/dt) ---

% --- calculate storage term (dc/dt) ---
% Single column storage
z = 3; % hieght of tower sensor (LI-7500)
c1 		= [NaN;CO2mgtop];
c2 		= [CO2mgtop;NaN];
dcdt 	= (c2-c1)*(z/1800)*(1000/44);
dcdt 	= dcdt(1:length(dcdt)-1);
ind = find(dcdt > 5 | dcdt < -5);
dcdt(ind)	= NaN*ones(length(ind),1);

% % Top half storage
% ztop = 8; % 1/2 the hieght of tower sensor (LI-7500)
% c1top 		= [NaN;CO2mgtop];
% c2top 		= [CO2mgtop;NaN];
% dcdttop 	= (c2top-c1top)*(ztop/1800)*(1000/44);
% dcdttop 	= dcdttop(1:length(dcdttop)-1);
% ind = find(dcdttop > 10 | dcdttop < -10);
% dcdttop(ind)	= NaN*ones(length(ind),1);
% 
% % Bottom half storage
% zcpy = 8; % Hieght of Li800 in the canopy
% c1cpy 		= [NaN;CO2mgcpy];
% c2cpy 		= [CO2mgcpy;NaN];
% dcdtcpy 	= (c2cpy-c1cpy)*(zcpy/1800)*(1000/44);
% dcdtcpy 	= dcdtcpy(1:length(dcdtcpy)-1);
% ind = find(dcdtcpy > 10 | dcdtcpy < -10);
% dcdtcpy(ind)	= NaN*ones(length(ind),1);
% 
% dcdtsum = dcdtcpy + dcdttop;
% ind = find(dcdtsum > 5 | dcdtsum < -5);
% dcdtsum(ind)	= NaN*ones(length(ind),1);
% 
% ind = find(isnan(dcdtsum)); dcdtsum(ind) = dcdt(ind);

figure(1)
hold on
% plot(dcdttop,'b')
% plot(dcdtcpy,'r')
% plot(dcdtsum,'c')
plot(dcdt,'g')

save 'C:\data\turkey\m4\2005\dcdt.txt' dcdt -ASCII
