
%% CO2_storage.m
% This program calculates the changes in the amount of CO2 and heat stored beneath
% the OPEC sensor, using CO2 concentration and temperature measured at the top of the
% canopy, or measured at different points in the profile
% Created July 31, 2007 by JJB
% Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Modified Feb 25, 2008 by JJB 
%       - included raw NEE calculation into function, so that only Met_SHF
%       and OPEC_storage have to be used before going to flux calculation
%       scripts.
clear all
close all


loadstart = addpath_loadstart;

% st_yr = 2003;
% en_yr = 2007;
st_yr = 2008; en_yr = 2008;
num_yrs = en_yr-st_yr+1;
%%
for site_num = 1%:1:4

    site_list = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
    site = site_list(site_num,:);
disp(['site:' site]);
    for year_num = st_yr:1:en_yr
        yr_ctr = year_num - st_yr+1;
        year = num2str(year_num);

%% Input and Output locations -- always the same
        load_path_filled = ([loadstart 'Matlab/Data/Met/Final_Filled/' site '/' site '_' year]);
        load_path_cleaned = ([loadstart 'Matlab/Data/Met/Final_Cleaned/' site '/' site '_' year]);
        save_path = ([loadstart 'Matlab/Data/Flux/Final_Calculated/' site '/' site '_' year ]);
param_path = [loadstart 'Matlab/Data/Met/Calculated4/Docs/'];
tracker_path = [loadstart 'Matlab/Data/Flux/Met_Flux_Tracker/' site '/' site '_' year];
        hdr_path = [loadstart 'Matlab/Data/Met/Final_Cleaned/Headers/'];
%%% Load header
        hdr = jjb_hdr_read([hdr_path site '_CCP_List.csv'], ',', 2);
%% Parameters:
        [junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);
param = params(year, num2str(site_num), 'CO2_storage');
z = param(:,1);     ztop = param(:,2);   zcpy = param(:,3);
col_flag = param(:,4);
Ma = 28.97; % approx molar mass of dry air:
rho_a = 1200;  % approx density of dry air (g/m3)

try
Storage_params = dlmread([param_path 'TP_Storage_params.csv'],',');
catch
 Storage_params = [] ;
end

%% Load needed variables %%%%%%%%%%%%%%%%%%%%%%%%%
switch site
    case 'TP39'; topname = 'CO2_28m'; cpyname = 'CO2_14m';
    case 'TP74'; topname = 'CO2_15m'; cpyname = 'CO2_9.2m';
    case 'TP89'; topname = 'CO2_12m'; cpyname = 'CO2_6m';
    case 'TP02'; topname = 'CO2_3m'; cpyname = 'CO2_0m';
end
try
        data(yr_ctr).top = jjb_load_var(hdr,[load_path_cleaned '.'],topname,1);
catch
        data(yr_ctr).top = [];
end
        data(yr_ctr).cpy = jjb_load_var(hdr,[load_path_cleaned '.'],cpyname,1);
        data(yr_ctr).FC = jjb_load_var(hdr,[load_path_cleaned '.'],'FC',1);
        

        data(yr_ctr).Ta = load([load_path_filled '.Ta']);
        data(yr_ctr).APR = load([load_path_filled '.APR']);
         
%% DO HEAT STORAGE FIRST:

%% Shift Temperature data by one point and take difference to get dT/dt
%%% Also cuts off the extra data point that is created by adding NaN
T1top = [NaN; data(yr_ctr).Ta(1:length(data(yr_ctr).Ta)-1)];
T2top = [data(yr_ctr).Ta(1:length(data(yr_ctr).Ta)-1) ; NaN];

%% Heat Storage
dTdt = T1top-T2top;
data(yr_ctr).Jt(:,1) = 22.25.*0.6.*dTdt +1.66;    %% Blanken et al. (1997) 
data(yr_ctr).Jt(1,1) = data(yr_ctr).Jt(2,1); data(yr_ctr).Jt(length(dt),1) = data(yr_ctr).Jt(length(dt)-1,1); 
%%% Fill small gaps with linear interp:
[data(yr_ctr).Jtfill] = jjb_interp_gap(data(yr_ctr).Jt,dt, 3);


%% Shift CO2_top data by one point and take difference to get dc/dt
%%% Also cuts off the extra data point that is created by adding NaN
c1top = [NaN; data(yr_ctr).top(1:length(data(yr_ctr).top)-1)];
c2top = [data(yr_ctr).top(1:length(data(yr_ctr).top)-1) ; NaN];
c1cpy = [NaN; data(yr_ctr).cpy(1:length(data(yr_ctr).cpy)-1)];
c2cpy = [data(yr_ctr).cpy(1:length(data(yr_ctr).cpy)-1) ; NaN];
        
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 1-height
%% Calculate CO2 storage in column below system: One-Height approach
%%%*** Note the output of this is in umol/mol NOT IN mg/m^3 ***********
% data(yr_ctr).dcdt_1h(:,1) = (c2top-c1top).*(z/1800); 
data(yr_ctr).dcdt_1h(:,1) = (c2top-c1top).*rho_a./Ma.*z./1800; 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2-height

if col_flag == 2 % Calculate for the top and bottom halves
%%% top
    dcdt_top = (c2top-c1top).*rho_a./Ma.*ztop./1800; 
    
%%% bottom
    dcdt_cpy = (c2cpy-c1cpy).*rho_a./Ma.*zcpy./1800;   %% 
elseif col_flag == 1;
    dcdt_top(1:length(dt),1) = NaN;
    dcdt_cpy(1:length(dt),1) = NaN;
end

%%% Add top and bottom storages
data(yr_ctr).dcdt_2h(:,1) = dcdt_top + dcdt_cpy;  %% 2-height storage in umol/mol m^-2s^-1

%% Remove outliers
try
right_row = find(Storage_params(:,1) == site_num & Storage_params(:,2) == year_num);

data(yr_ctr).dcdt_1h(data(yr_ctr).dcdt_1h < Storage_params(right_row,3) | data(yr_ctr).dcdt_1h > Storage_params(right_row,4)) = NaN;
data(yr_ctr).dcdt_2h(data(yr_ctr).dcdt_2h < Storage_params(right_row,3) | data(yr_ctr).dcdt_2h > Storage_params(right_row,4)) = NaN;
st_pt = Storage_params(right_row,5);
st_pt2 = Storage_params(right_row,6);

z = Storage_params(right_row,7);
sdev = Storage_params(right_row,8);

real_spikes_1h = jjb_find_spike2(data(yr_ctr).dcdt_1h, z,sdev,st_pt);
if site_num ~=4
real_spikes_2h = jjb_find_spike2(data(yr_ctr).dcdt_2h, z,sdev,st_pt2);
else
   real_spikes_2h(1:length(real_spikes_1h),1) = 0; 
end

catch

% real_spikes_1h = jjb_find_spike2(data(yr_ctr).dcdt_1h, 15,1.5,[]);
% real_spikes_2h = jjb_find_spike2(data(yr_ctr).dcdt_2h, 15,1.5,[]);
% real_spikes_1h = jjb_find_spike2(data(yr_ctr).dcdt_1h, 8,1,[]);
% real_spikes_2h = jjb_find_spike2(data(yr_ctr).dcdt_2h, 15,1,[]);
real_spikes_1h = jjb_find_spike2(data(yr_ctr).dcdt_1h, 8,1,[]);
real_spikes_2h = jjb_find_spike2(data(yr_ctr).dcdt_2h, 15,1,[]);


end

data(yr_ctr).dcdt_1h(abs(real_spikes_1h) ==1,1) = NaN;
data(yr_ctr).dcdt_2h(abs(real_spikes_2h) ==1,1) = NaN;

%%% Tracker:
dcdt1h_tracker(1:length(dt),1) = 0; dcdt1h_tracker(~isnan(data(yr_ctr).dcdt_1h),1) = 1;
dcdt2h_tracker(1:length(dt),1) = 0; dcdt2h_tracker(~isnan(data(yr_ctr).dcdt_2h),1) = 1;

%%% Fill gaps in 2h from 1h
ind_fill_ok = find(isnan(data(yr_ctr).dcdt_2h) & ~isnan(data(yr_ctr).dcdt_1h));

data(yr_ctr).dcdt_2h(ind_fill_ok,1) = data(yr_ctr).dcdt_1h(ind_fill_ok,1);   
dcdt2h_tracker(ind_fill_ok,1) = 1;

%% Fill small gaps by linear interpolation

[data(yr_ctr).dcdt_2hfill] = jjb_interp_gap(data(yr_ctr).dcdt_2h,dt, 3);
ind_interp_2h = find(~isnan(data(yr_ctr).dcdt_2hfill) & isnan(data(yr_ctr).dcdt_2h));
dcdt2h_tracker(ind_interp_2h,1) = 2;

[data(yr_ctr).dcdt_1hfill] = jjb_interp_gap(data(yr_ctr).dcdt_1h,dt, 3);
ind_interp_1h = find(~isnan(data(yr_ctr).dcdt_1hfill) & isnan(data(yr_ctr).dcdt_1h));
dcdt1h_tracker(ind_interp_1h,1) = 2;


data(yr_ctr).gaps = length(find(isnan(data(yr_ctr).dcdt_2hfill)));
data(yr_ctr).FCgaps = length(find(isnan(data(yr_ctr).FC)));
data(yr_ctr).topgaps = length(find(isnan(data(yr_ctr).top)));
data(yr_ctr).Tagaps = length(find(isnan(data(yr_ctr).Ta)));
data(yr_ctr).Jtgaps = length(find(isnan(data(yr_ctr).Jtfill)));
data(yr_ctr).FCdtgaps = length(find(isnan(data(yr_ctr).FC) & isnan(data(yr_ctr).dcdt_2hfill) ));

disp(['we have : ' num2str(data(yr_ctr).gaps) ' gaps in storage data!']);
disp(['we have : ' num2str(data(yr_ctr).topgaps) ' gaps in CO2_top data!']);
disp(['we have : ' num2str(data(yr_ctr).FCgaps) ' gaps in FC data!']);
disp(['we have : ' num2str(data(yr_ctr).Tagaps) ' gaps in Ta data!']);
disp(['we have : ' num2str(data(yr_ctr).Jtgaps) ' gaps in Jt data!']);
disp(['we have : ' num2str(data(yr_ctr).FCdtgaps) ' coincident gaps between FC and dcdt data!']);

%% Raw NEE:
temp_NEE = [data(yr_ctr).FC' ; data(yr_ctr).dcdt_2hfill'];
data(yr_ctr).NEE = (sum(temp_NEE))';

%% Plot Some data:
%%% Figure 2 - Storage Comparisons

figure (2); clf
subplot(2,1,1)
hold on;
plot (dt,data(yr_ctr).dcdt_2hfill,'b')
plot (dt,data(yr_ctr).dcdt_2h,'r')
legend ('Filled', 'Raw');
title ('CO2 storage (raw vs filled) 2-height');
ylabel ('CO2 Storage (mg m^-^2 s^-^1)')
axis([0 365 min(data(yr_ctr).dcdt_2hfill) max(data(yr_ctr).dcdt_2hfill)]);

subplot(2,1,2)
hold on;
plot (dt,data(yr_ctr).dcdt_1hfill,'g')
plot (dt,data(yr_ctr).dcdt_2hfill,'b')
legend ('1-height', '2-height');
title ('CO2 storage (filled) 1-height vs 2-height');
ylabel ('CO2 Storage (mg m^-^2 s^-^1)');
xlabel ('Day of Year');
axis([0 365 min(data(yr_ctr).dcdt_2hfill) max(data(yr_ctr).dcdt_2hfill)]);


figure(3); clf
plot(dt,data(yr_ctr).NEE); hold on;
plot(dt,data(yr_ctr).FC, 'k'); hold on;
title('raw NEE')
legend('NEE','FC');
axis([0 366 -40 40]); 

figure(4)
plot(data(yr_ctr).top,'b'); hold on;
plot(data(yr_ctr).cpy,'r'); hold on;

figure(5)
plot(data(yr_ctr).Jt,'g');

%% SAVE Variables
temp_dcdt_1h = data(yr_ctr).dcdt_1h;         temp_dcdt_2h = data(yr_ctr).dcdt_2h; 
temp_dcdt_2hfill = data(yr_ctr).dcdt_2hfill; temp_dcdt_1hfill = data(yr_ctr).dcdt_1hfill; 
temp_Jt = data(yr_ctr).Jtfill; temp_NEE = data(yr_ctr).NEE; 


%%% Raw dcdt in umol/mol m^-2s^-1
save ([save_path 'dcdt_1h.dat'],'temp_dcdt_1hfill','-ASCII');
save ([save_path 'dcdt_2h.dat'],'temp_dcdt_2hfill','-ASCII');

save ([save_path 'Jt.dat'],'temp_Jt','-ASCII');
save ([save_path 'NEE_raw.dat'],'temp_NEE','-ASCII');

%%% save tracker files:
save([tracker_path 'dcdt_1h_tracker.dat'],'dcdt1h_tracker');
save([tracker_path 'dcdt_2h_tracker.dat'],'dcdt2h_tracker');

clear data dt temp* junk dcdt* dT*
inp = input('hit enter');
    end
end


