%this program read CO2 concentration at 26m at BS site
%
%(c) Bill Chen                      File created:  Jan. 27, 1999
%                                   Last modified: Jan. 27, 1999

% Altaf Aarain, March 22, 2000
% Altaf Aarain, April 05, 2001
% - Updated for 2000 to calculate CO2 in mg
% - Updated for Turkey Point to calculate CO2 in (mg/m^3)*(m/s) or (mg/m2/s)
% Modified for GRFS, Altaf Arain, Dec 8, 2004
% Modified for TP Met4 OPEC 2005 data. Altaf ad Mathias, May 25, 2006

% --- get time series ---
load decdoy_00.txt
dt = decdoy_00(1:17520);

% Read Metrol data
% 1	      2	      3	  4	    5	   6	    7	   8	  9	       10	     																									
%year	month	day	 JD	  hour	 minute	  airTC	  RH	ws_ms	wind_dir

%   11        12       13     14      15       16       17         18
%PAR down	PARup	NR Wm2	Hflux1	Hflux2	  rain	  m4Ts1A	m4Ts50A 

%    19        20      21      22      23      24       25      26      27
% m4Ts20A	m4Ts10A	m4Ts5A	m4Ts2A	m4Ts11B	m4Ts50B	m4Ts20B	m4Ts10B  m4Ts5B

%   28      29      30     31     32      33       34      35      36
%m4Ts2B	m4Sm50A	m4Sm40A	m4Sm10A	m4Sm5A	m4Sm50B	m4Sm40B	m4Sm10B	m4Sm5B	


load Meteo2005_m4.txt
m4met = Meteo2005_m4(:,:);

% Air temperature
ta = m4met(:,7);

% Load OPEC flux data
load opec2005m4.txt
m4flx = opec2005m4(:,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   1	  2	     3	   4	  5	      6	      7	       8	 9 	   10
% Year	Month	Day	  JD    hour	minute	Fc_wpl	LE_wpl	 Hs    H
% 11	  12	  13   14	15	   16     17        18       19     20   	        
% tau	u_star	  Uz   Ux   Uy   CO2avg  H2Oavg   Tsonic    Tfw    rho
%   21       22           23      24       25       26      27       28
% press	 wnd_dir_comp	wnd_spd	Fc_irga	 LE_irga  h2o_hmp  t_hmp	co2stor
% read data
% fc = m4(:,7);     % Fc_wpl in mg CO2/m2/s
% fc_umol = fc*1000/44; % Fc_wpl in umol CO2/m2/s
% LE = m4flx(:,8);
% Hs = m4flx(:,9);
% H = m4flx(:,10);
% tau = m4flx(:,11);
% u = m4flx(:,12);
% co2_top_mg = m4flx(:,16);
% Ts = m4flx(:,18);
% fw = m4flx(:,19);
% wd = m4flx(:,22);
% ws = m4flx(:,23);
% h_hmp = m4flx(:,26);
% t_hmp = m4flx(:,27);
% co2_cpy = m4flx(:,28);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Pressure data (kPa)
pr = m4flx(:,21);
ind = find(pr > 105);  pr(ind) = 99.00;
ind = find(pr < 95);   pr(ind) = 99.00;
ind = find(isnan(pr)); pr(ind) = 99.00;

co2mg_top = m4flx(:,16); % CO2 concentration at top from Li-7500 in mg/m3 at 16 m
co2_cpy = m4flx(:,28); % CO2 concentration from at canopy height from Li-800 in ppm (umol/mol) at 8 m

% remove bad values
ind = find(co2mg_top < -8000); co2mg_top(ind) = NaN;
ind = find(co2_cpy < -8000);   co2_cpy(ind)   = NaN;

% Conver CO2 in ppm to [ppm*(m/s)] (mole fraction of dry air) to [(mg/m^3)*(m/s)] 
[co2mg_cpy] = C_CONVER(co2_cpy,ta,pr,1);

% Clean CO2mgtop
ind = find(co2mg_cpy > 1050); co2mg_cpy(ind) = NaN;
ind = find(co2mg_cpy < 580);  co2mg_cpy(ind) = NaN;

ind = find(co2mg_top > 1050); co2mg_top(ind) = NaN;
ind = find(co2mg_top < 580);  co2mg_top(ind) = NaN;

save 'C:\data\turkey\m4\2005\m4CO2mgtop.txt' co2mg_top -ASCII
save 'C:\data\turkey\m4\2005\m4CO2mgcpy.txt' co2mg_cpy -ASCII 

% Check and plot data
close all
hold on
figure(1); plot(ta);
figure(2); plot(pr);

figure(3)
hold on
plot(m4flx(:,16),'b-x')
plot(m4flx(:,28),'r-x')

figure(4)
hold on
plot(co2mg_top,'b-x')
plot(co2mg_cpy,'m-x')