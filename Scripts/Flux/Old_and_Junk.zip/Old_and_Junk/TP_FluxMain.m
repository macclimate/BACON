% function [] = TP_FluxMain(site_num, start_yr, end_yr, ustar_th)
%% TEMPORARY: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear all
close all

site_num = 1;
start_yr = 2003; end_yr = 2007;
ustar_th = 0.3;
switch site_num
    case 1
        yr_agg = 'off';
    case 2
        yr_agg = 'on';
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
colorlist = ['r';'g';'b';'k';'c';'m'];

if ispc == 1
%     data_loc = 'C:/HOME/MATLAB/';
data_loc = 'E:/';
else
    data_loc = '/home/jayb/MATLAB/';
end

site_list = ['TP39'; 'TP74'; 'TP89'; 'TP02'];
    site = site_list(site_num,:);
disp(['site:' site]);
    

%% Input and Output locations -- always the same
load_path_prep =  ([data_loc 'Data/Flux/Final_Calculated/' site '/' site]);    
save_path = ([data_loc 'Data/Flux/Final_Calculated/' site '/Output/' site '_']);

%% Load Variables:
load([load_path_prep '_input_' num2str(start_yr) '_' num2str(end_yr) '.mat']);
%%% Structure of variables:  All necessary variables should be saved as a
%%% structure array.  When loaded, the title of this array is 'data'.  Each
%%% variable is stored seperately as one branch down from data, with the
%%% title of the branch corresponding to the variable:
%e.g:
%  data(1).Ta - Air Temp
% .VPD
% .PAR
% .Ts2
% .Ts5
% .WS
% .WDir
% .ustar
% .SM
% .SMa
% .SMb
% .NEE_raw
% .NEE (cleaned)
% .dt
% .year

%%%% data(1).tracker contains a matrix where each column corresponds to a
%%%% loaded variable.  
% A row value of 0 corresponds to missing data at that specific row of the corresponding variable.  
% A row value of 1 corresponds to real, untouched data at that specific row
% A value of 2 indicates data at that row has been filled from another site.
%%% ORDER FOR TRACKER:
%COLUMN --- VARIABLE:
% 1 --- Ta
% 2 --- APR
% 3 --- PAR
% 4 --- Ts2
% 5 --- Ts5
% 6 --- VPD
% 7 --- ustar
% 8 --- SM
% 9 --- SMa
% 10 -- SMb
% 11 -- NEE
%%% More columns may be added as more variables are added to analysis.
% 12 --- ustar threshold tracker -- created in Step 1 also.
% 13 --- daytime
% 14 --- nighttime
% 15 --- Respiration
% 16 --- Growing Season
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% MAIN SECTION: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 
%%
%% Step 1: Create some more trackers:

%%% Create ustar threshold tracker:
ustar_th_tracker(1:length(data(1).tracker(:,7)),1) = data(1).tracker(:,7);
ustar_th_tracker(data(1).PAR < 10 & data(1).ustar < ustar_th,1) = 0;
data(1).tracker(:,12) = ustar_th_tracker;
clear ustar_th_tracker;

%%% Daytime tracker:
day_tracker(1:length(data(1).tracker(:,3)),1) = 0;
day_tracker(data(1).PAR >= 10,1) = 1;

%%% Nighttime tracker:
night_tracker(1:length(data(1).tracker(:,3)),1) = 0;
night_tracker(data(1).PAR < 10,1) = 1;

data(1).tracker(:,13) = day_tracker;
data(1).tracker(:,14) = night_tracker;
clear day_tracker night_tracker;




%% Step 2: Respiration Function:
%%% Make a Respiration Tracker for model input:
resp_tracker(:,1) = data(1).tracker(:,5).*data(1).tracker(:,12).*data(1).tracker(:,14);
%%% Runs function to calculate respiration for all years:
resp = TP_resp(data(1).Ts5, data(1).NEE, data(1).year, resp_tracker, 'on', [], 'log', yr_agg, 'on');
%%% Track any NaNs in resp data:
r_tracker(1:length(resp),1) = 0;
r_tracker(~isnan(resp),1) = 1;
data(1).tracker(:,15) = r_tracker;
%%% Put respiration into separate structure array:
model(1).resp = resp;

clear resp r_tracker;

%%% growing season tracker:
gs_tracker(1:length(data(1).tracker(:,3)),1) = 0;
gs_tracker(data(1).Ts5 > 2,1) = 1;
data(1).tracker(:,16) = gs_tracker;
clear gs_tracker
%% Step 3: Get a raw GEP Value from predicted Respiration:
data(1).GEP = model(1).resp - data(1).NEE;

%% Take A Look at some general relationships btw environmental variables and GEP:
%%% Tracker -- specifies the right conditions: Ta x PAR x Ts5 x VPD x SM x
%%% NEE x daytime x respiration
GEP_tracker(:,1) = data(1).tracker(:,1).*data(1).tracker(:,3).*data(1).tracker(:,5).*data(1).tracker(:,6).*data(1).tracker(:,8) ...
    .*data(1).tracker(:,11).*data(1).tracker(:,13).*data(1).tracker(:,15);
ind_GEP = find(GEP_tracker ==1);
%%% Plot some relationships for fun:

figure(2);clf;

subplot(3,2,1); plot(data(1).Ts5(ind_GEP),  data(1).GEP(ind_GEP), 'b.'); title('Ts vs. GEP'); hold on;
subplot(3,2,2); plot(data(1).Ta(ind_GEP),   data(1).GEP(ind_GEP), 'b.'); title('T_{air} vs. GEP'); hold on;
subplot(3,2,3); plot(data(1).PAR(ind_GEP),  data(1).GEP(ind_GEP), 'b.'); title('PAR vs. GEP'); hold on;
subplot(3,2,4); plot(data(1).WDir(ind_GEP), data(1).GEP(ind_GEP), 'b.'); title('Wind dir. vs. GEP'); hold on;
subplot(3,2,5); plot(data(1).VPD(ind_GEP),  data(1).GEP(ind_GEP), 'b.'); title('VPD. vs. GEP'); hold on;
subplot(3,2,6); plot(data(1).SM(ind_GEP),   data(1).GEP(ind_GEP), 'b.'); title('SM. vs. GEP'); hold on;

% Block average data to see average trends
bavg.Ts = blockavg(data(1).Ts5(ind_GEP), data(1).GEP(ind_GEP),     0.50, 60, -20);
bavg.Ta = blockavg(data(1).Ta(ind_GEP), data(1).GEP(ind_GEP),   0.50, 60, -20);
bavg.PAR = blockavg(data(1).PAR(ind_GEP), data(1).GEP(ind_GEP),    100, 60, -20);
bavg.WDir = blockavg(data(1).WDir(ind_GEP), data(1).GEP(ind_GEP),  10, 60, -20);
bavg.VPD = blockavg(data(1).VPD(ind_GEP), data(1).GEP(ind_GEP),    0.1, 60, -20);
bavg.SM = blockavg(data(1).SM(ind_GEP), data(1).GEP(ind_GEP),      0.0025, 60, -20);

subplot(3,2,1); plot(bavg.Ts(:,1),  bavg.Ts(:,2), 'ro');
subplot(3,2,2); plot(bavg.Ta(:,1),  bavg.Ta(:,2), 'ro');
subplot(3,2,3); plot(bavg.PAR(:,1), bavg.PAR(:,2), 'ro');
subplot(3,2,4); plot(bavg.WDir(:,1),bavg.WDir(:,2), 'ro');
subplot(3,2,5); plot(bavg.VPD(:,1), bavg.VPD(:,2), 'ro');
subplot(3,2,6); plot(bavg.SM(:,1),  bavg.SM(:,2), 'ro');

%% Step 4: GEP Model:
input_vars = [data(1).PAR data(1).Ta data(1).Ts5 data(1).VPD data(1).SM];
model(1).GEP = TP_GEP(input_vars, data(1).GEP, data(1).year, data(1).tracker, 'off', 'scaled', 'on', 'on','old');


%% Step 5: Clean and Fill Final data:

NEE_final(1:length(data(1).NEE),1) = NaN;
Resp_final(1:length(data(1).NEE),1) = NaN;
GEP_final(1:length(data(1).NEE),1) = NaN;


%%% CLEAN GEP
data(1).GEP(data(1).GEP < 0,1) = NaN; % no negative GEPs
data(1).GEP(data(1).tracker(:,14)==1,1) = 0; % no GEP at night
data(1).GEP(data(1).Ts5 <= 0,1) = 0; % no GEP in wintertime:

GEP_final(:,1) = data(1).GEP(:,1);
GEP_final(isnan(GEP_final(:,1)),1) = model(1).GEP(isnan(GEP_final(:,1)),1);
GEP_final(GEP_final < 0,1) = 0;  

%%% CLEAN RESP
% fill respiration with NEE during night when ustar is high enough:
Resp_final((data(1).tracker(:,12).*data(1).tracker(:,11).*data(1).tracker(:,14))==1,1) = data(1).NEE((data(1).tracker(:,12).*data(1).tracker(:,11).*data(1).tracker(:,14))==1,1); 
Resp_final(Resp_final < 0,1) = NaN;
Resp_final(Resp_final > 15,1) = NaN;
%%% Fill with model when there are gaps:
Resp_final(isnan(Resp_final),1) = model(1).resp(isnan(Resp_final),1);

%%% Clean NEE 
%%%%% nighttime filled by respiration:
NEE_final(data(1).tracker(:,14)==1,1) = Resp_final(data(1).tracker(:,14)==1,1); % night NEE is respiration:
NEE_final((data(1).tracker(:,13).*data(1).tracker(:,11))==1,1) = data(1).NEE((data(1).tracker(:,13).*data(1).tracker(:,11))==1,1);
NEE_final(isnan(NEE_final),1) = Resp_final(isnan(NEE_final),1)- GEP_final(isnan(NEE_final),1);

%% Plot all final variables:
figure(17);clf;
plot(GEP_final,'g');hold on;
plot(NEE_final,'b');
plot(Resp_final,'r');

%% Find any holes in data:
missing_GEP = length(find(isnan(GEP_final) & ~isnan(data(1).year)));
missing_Resp = length(find(isnan(Resp_final) & ~isnan(data(1).year)));
missing_NEE = length(find(isnan(NEE_final) & ~isnan(data(1).year)));


disp(['missing numbers: GEP: ' num2str(missing_GEP) ' Resp: ' num2str(missing_Resp) ' NEE: ' num2str(missing_NEE)]);

for j = start_yr:1:end_yr
    yr_ctr = j-start_yr+1;
    
    NEP_yr_final = NEE_final(data(1).year == j).*-1; sum_NEE_yr = nansum(NEP_yr_final).*0.0216;
    Resp_yr_final = Resp_final(data(1).year == j); sum_Resp_yr = nansum(Resp_yr_final).*0.0216;
    GEP_yr_final = GEP_final(data(1).year == j); sum_GEP_yr = nansum(GEP_yr_final).*0.0216;
    Resp_mod_yr_final = model(1).resp(data(1).year == j); sum_Resp_mod_yr = nansum(Resp_mod_yr_final).*0.0216;
    GEP_mod_yr_final = model(1).GEP(data(1).year == j); sum_GEP_mod_yr = nansum(GEP_mod_yr_final).*0.0216;
  
    
   Results(yr_ctr,:) = [j sum_NEE_yr sum_Resp_yr sum_Resp_mod_yr sum_GEP_yr sum_GEP_mod_yr];

   final(yr_ctr).NEP = NEP_yr_final; final(yr_ctr).Resp = Resp_yr_final; final(yr_ctr).GEP = GEP_yr_final;
   final(yr_ctr).Resp_mod = Resp_mod_yr_final; final(yr_ctr).GEP_mod = GEP_mod_yr_final; 

   output = [NEP_yr_final Resp_yr_final GEP_yr_final Resp_mod_yr_final GEP_mod_yr_final];
   
   save([save_path num2str(j) '_Flux_Results.dat'],'output','-ASCII');
   
    clear NEP_yr_final Resp_yr_final GEP_yr_final Resp_mod_yr_final GEP_mod_yr_final output
end


%% Run analysis on model outputs:

% for j = start_yr:1:end_yr
%     yr_ctr = j-start_yr+1;
% figure(18); subplot(3,2,yr_ctr)
%     
%     
%     
% end












