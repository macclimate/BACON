% this program get soil surface heat flux G0 from soil heat 
% flux plats at 3cm (G3) and storage (M) between 0-3 cm 
% according to formula: G0 = G3 + M
% where M is the rate of change of heat stored in the top 3 cm
% layer per unit area and M = z*Cs*delta_T/delta_t. z is the thickness
% of layer above the flux plate (0.03m), Cs is the volumetric heat capacity 
% of the soil (J m^-3 K^-1) and delta_T/delta_t is the rate of change of 
% tht average temperature of teh top 3 cm (K s^-1). C can be calculated:
% C = 2.00*theta_m + 2.50*theta_o + 4.18*theta_w
% where theta_m, theta_o, theta_w are volume fractions of mineral soil, 
%organic matter and water respectively.
%
% (C) Bill Chen								File created : Apr. 28, 1998
%													Last modified: Apr. 06, 1999
% 
% Revision:  
%					Apr. 06, 1999 by Bill Chen
%					- calculate 1999 data
%					Sep. 29, 1998 by Bill Chen
%					- calculate 1998 data
%					Sep. 02, 1998 by Bill Chen
%					- using energy balance equation and linear interpolation 
%					  to fill 1996 missing data
%					- using linear interpolation to fill 1997 data gap
%					Jul. 14, 1998 by Bill Chen
%				  	- calculate 1997 data
%
%    Modified for Turkey Point Young site (Met2)
%    Altaf Aarin       Nov. 14, 2002
% Altaf and Mahmoud, GRFS, 17 Feb, 2005
% Modified for TP Met2 OPEC 2005 data. Altaf ad Mathias, May 25, 2006
% Modified for TP Met2 OPEC 2006 data by Matthias, Feb 25, 2007

% --- get time series ---
load decdoy_00.txt;
dt = decdoy_00(1:17520);
dt_gr = dt;


%Load m2 2006 data (Flux & Meteo):
%1	       2	  3	  4	       5	   6	 7	    8	         9	        10	 
%Year	Month	Day	Hour	Minute	 DTIME	FC	 CO2_top	CO2_midcanopy	SFC

% 11	   12	      13	14	15	16	   17	       18	    19	20	   21	     22	             23	     
% USTAR	H2O_Irga	H2O_HMP	LE	H	S	Gplate_1	Gplate_2	G	Rn   PARdown	PARreflected	PARdown_2m	

%  24	25	26	  27	  28	 29	  
% Tair	RH	WS	W_DIR	AtmoPr	PPT	

%   30	      31	  32	  33	  34	  35	   36	  37	  38	  39	  40	   41	     
% Ts2cmA	Ts5cmA	Ts10cmA	Ts20cmA	Ts50cmA	Ts100cmA Ts2cmB	Ts5cmB	Ts10cmB Ts20cmB	Ts50cmB	Ts100cmB	

%   42	       43	    44	    45	  46	      47	   48	   49	   50	   51	     
% SM5cmA	SM10cmA	SM20cmA	SM50cmA	SM100cmA	SM5cmB	SM10cmB	SM20cmB SM50cmB	SM100cmB	

% 52	     53	       54	         55	      56	  57	58	  
% NEP	GEP_filled	R_filled	NEP_filled	APAR	FPAR	ZL	

%   59	    60	   61	   62	    63	     64	   65	    66	      67	    68	   69
%TCmaxBN TCmaxBC TCmaxBS TCavgBN TCavgBQN TCavgBC TCavgBS TCavgBQS TCminBN	TCminBC	TCminBS


load WPP74data_Jan06Dec06.txt
m2 = WPP74data_Jan06Dec06(:,:); 

% air temperature (oC) for TP site to get respiration functions
Ta = m2(:,24); 

% Liner regression method following Blanken et al., 2001.
%Jt (W/m2) = a * Delta_ta + b

 ind     = 2:length(Ta)-1;
dT    = Ta(ind+1) - Ta(ind-1);
dT    = [NaN;dT;NaN];
Jt  = 44.5*0.4*dT + 1.66; % made assumption for 15m air column at Met2. Need confirmation from Blanken et al., 1997 (thesis).

save Jt.txt Jt -ASCII
figure(1)
plot(Jt)

 %%%%%%%%%%%%%%% Ts %%%%%%%%%%%%%%%%%%%%%%%%
% Soil temp of both N and S sensors 
TsA2  = m2(:,30); %ind = find(TsA2  < -8); TsA2(ind)  = NaN; TsA2  = interp_nan(dt,TsA2); 
TsA5  = m2(:,31); %ind = find(TsA5  < -8); TsA5(ind)  = NaN; TsA5  = interp_nan(dt,TsA5); 
TsA10 = m2(:,32); %ind = find(TsA10 < -8); TsA10(ind) = NaN; TsA10 = interp_nan(dt,TsA10); 
TsA20 = m2(:,33); %ind = find(TsA20 < -8); TsA20(ind) = NaN; TsA20 = interp_nan(dt,TsA20); 
TsA50 = m2(:,34); %ind = find(TsA50 < -8); TsA50(ind) = NaN; TsA50 = interp_nan(dt,TsA50); 
TsA100= m2(:,35); %ind = find(TsA100< -8); TsA100(ind)= NaN; TsA100= interp_nan(dt,TsA100); 

%TsB2  = m2(:,28); ind = find(TsB2  < -8); TsB2(ind)  = NaN; TsB2  = interp_nan(dt,TsB2); 
%TsB5  = m2(:,27); ind = find(TsB5  < -8); TsB5(ind)  = NaN; TsB5  = interp_nan(dt,TsB5); 
%TsB10 = m2(:,26); ind = find(TsB10 < -8); TsB10(ind) = NaN; TsB10 = interp_nan(dt,TsB10); 
%TsB20 = m2(:,25); ind = find(TsB20 < -8); TsB20(ind) = NaN; TsB20 = interp_nan(dt,TsB20); 
%TsB50 = m2(:,24); ind = find(TsB50 < -8); TsB50(ind) = NaN; TsB50 = interp_nan(dt,TsB50); 
%TsB100= m2(:,23); ind = find(TsB100< -8); TsB100(ind)= NaN; TsB100= interp_nan(dt,TsB100); 

%Ts2 = (TsA5 + TsB5)/2; % AVREGARE soil temperature of 5cm layer in two pits
Ts2 = TsA2;
Ts5 = TsA5;
Ts = Ts2;

% --- get soil heat flux ---
G1 = m2(:,17);
G2 = m2(:,18);

G_avg = (G1+G2)/2; %Average of two plates
clear  G1 G2
% 

theta_w   = 0.13;     % 11% water
theta_m	  = 0.01;     % 1% mineral soil
theta_o   = 160/1300; % theta_o = roh_b/roh_a where roh_b = 1300 kg/m2 and roh_o = 160 kg/m2 (Blanken et al., 2001)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%delta_T99 	= [NaN; diff(SoilTempINT3cm_99)];

% Function "Diff" calculate difference between two time intervals
% We do not have this function. Calculate it using following eq.

 ind 		= 2:length(Ts)-1;
 dTs 		= Ts(ind+1,:)-Ts(ind-1,:);
 delta_T 	= [NaN; dTs];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

z 				= 0.03; % Soil Heat Flux Plates at 3 cm depth
delta_t 		= 1800; % Half-hour data
M 			= NaN*ones(length(delta_T),1);
Cs 			= 2.00*theta_m + 2.50*theta_o + 4.18*theta_w;

M			= z*Cs.*delta_T/delta_t;
M   		= M*1.0e6; %unit: W m^-2

M = [M(1:end); M(end)];
G0 = G_avg + M;

% Assign a value to a particulet bad half-hour
%G0_99(7355) = -3;

% Fill in missing G0 data by linear interpolation
ind 			= [ ];
G0(ind)	= NaN*ones(length(ind),1);
G0(ind)	= (G0(ind+1)+G0(ind-1))/2;

% Fill longer missing gaps in G0 data by linear interpolation using
% interpolation function, interp_nan
%G0_99 = interp_nan(t_99,G0_99);

% Save data in ASCII form
%save 'c:\bill\data\boreas\tf\tf01\1999\halfhour\G0_99' G0_99 

save G0.txt G0 -ASCII
save M.txt M -ASCII
%%%%%%%%%%%%%%%%%%
figure(2)
hold on
plot(G_avg,'b')
plot(M,'r')
plot(Jt,'c')

plot(G_avg+M+Jt,'g')