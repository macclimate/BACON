% This is for TP_Respiration_hw.m and TP_Photosynth_hw.m
%
% (C)Bill Chen       	            		File created   Oct. 07, 1999
%   										Last modified  Oct. 07, 1999
%
% Revisions:
%
%%% March 22, 2000, Altaf Arain
%	- updated for SOBS site
%%% April 05, 2001, Altaf Arain
%	- updated for SOBS site for year 2000
%%% July 19, 2001
%  - updated using clean Fc file and profile CO2 storage data
%  - For 2000 average temp of NE and NW sensors used at Tsoil at 2cm
% Updated for 1999-2001 data; Altaf March 13, 2002
%global DATA_PATH_BILL 
% updated for Turkey Point, Altaf, July 28, 2003
% updated for GRFS, Altaf Arain, Dec 8, 2004
% Modified for TP Met2 OPEC 2005 data. Altaf ad Mathias, May 25, 2006

% --- get time series ---
load decdoy_00.txt;
dt = decdoy_00(1:17520);

% Read Meteorlogy data
% 1	      2	      3	  4	    5	   6	    7	   8	  9	       10	      11	   12         13	  14	  15	    16	         17	      18	  19	   20	   21	   22	   23	   24	   25	  26	   27     28       29     30      31     32      33      34       35     36		37		38	  39	40	  41	42	  43	44	  45	46		47																								
%year	month	day	 JD	  hour	 minute	  airTC	  RH	ws_ms	wind_dir   PAR up	PAR down	NR Wm2	Hflux1	Hflux2	  PARcanopy	  M2Ts1A	M2Ts50A M2Ts20A	M2Ts10A	M2Ts5A	M2Ts2A	M2Ts11B	M2Ts50B	M2Ts20B	M2Ts10B  M2Ts5B M2Ts2B	M2Sm50A	M2Sm20A	M2Sm10A	M2Sm5A	M2Sm50B	M2Sm20B	M2Sm10B	M2Sm5B	tree1 tree2 tree3 tree4 tree5 tree6 tree7 tree8 tree9 tree10 tree11
load Meteo2005_m2.txt;
m2met = Meteo2005_m2;
clear Meteo2005_m2

% air temperature (oC) for TP site to get respiration functions
Ta = m2met(:,7); 

% get PPFD down (umol m^-2 s^-1)
PARdn = m2met(:,12);
PPFD = PARdn;
Q0= PARdn; 

%get wind speed (m/s)
ws = m2met(:,9);
ind = find(ws < -1);
ws(ind) = NaN;

%%%%%%%%%%%%%%% Ts %%%%%%%%%%%%%%%%%%%%%%%%
% Soil temp of both N and S sensors 
TsA2  = m2met(:,22); ind = find(TsA2  < -8); TsA2(ind)  = NaN; TsA2  = interp_nan(dt,TsA2); 
TsA5  = m2met(:,21); ind = find(TsA5  < -8); TsA5(ind)  = NaN; TsA5  = interp_nan(dt,TsA5); 
TsA10 = m2met(:,20); ind = find(TsA10 < -8); TsA10(ind) = NaN; TsA10 = interp_nan(dt,TsA10); 
TsA20 = m2met(:,19); ind = find(TsA20 < -8); TsA20(ind) = NaN; TsA20 = interp_nan(dt,TsA20); 
TsA50 = m2met(:,18); ind = find(TsA50 < -8); TsA50(ind) = NaN; TsA50 = interp_nan(dt,TsA50); 
TsA100= m2met(:,17); ind = find(TsA100< -8); TsA100(ind)= NaN; TsA100= interp_nan(dt,TsA100); 

TsB2  = m2met(:,28); ind = find(TsB2  < -8); TsB2(ind)  = NaN; TsB2  = interp_nan(dt,TsB2); 
TsB5  = m2met(:,27); ind = find(TsB5  < -8); TsB5(ind)  = NaN; TsB5  = interp_nan(dt,TsB5); 
TsB10 = m2met(:,26); ind = find(TsB10 < -8); TsB10(ind) = NaN; TsB10 = interp_nan(dt,TsB10); 
TsB20 = m2met(:,25); ind = find(TsB20 < -8); TsB20(ind) = NaN; TsB20 = interp_nan(dt,TsB20); 
TsB50 = m2met(:,24); ind = find(TsB50 < -8); TsB50(ind) = NaN; TsB50 = interp_nan(dt,TsB50); 
TsB100= m2met(:,23); ind = find(TsB100< -8); TsB100(ind)= NaN; TsB100= interp_nan(dt,TsB100); 

%Ts = (0.33*(TsA2+TsA5+TsA10) + 0.33*(TsB2+TsB5+TsB10)); % AVREGARE soil temperature of 10cm layer in two pits
Ts2 = (TsA5 + TsB5)/2; % AVREGARE soil temperature of 5cm layer in two pits

% REad data from Met1 to fill bad data at Met2
load C:\data\turkey\m1\2005\meteorol_nonfilled\soil\soil_clean_05.dat
TsA5m1 = soil_clean_05(:,9);
TsB5m1 = soil_clean_05(:,15);
Ts5m1  = (TsA5m1 + TsB5m1)/2; 

ind = [1:5736];      Ts2(ind) = Ts5m1(ind); % bad Ts data from 1-5736
ind = [16306:17520]; Ts2(ind) = Ts5m1(ind); % bad Ts data from 16306 to 17520

%Ts2 = Ta; %use air temperature for respiration

%%%%%%%%%%%%%%% Storage %%%%%%%%%%%%%%%%%%%%%%%%
%------- CO2 storage
load C:\data\turkey\m2\2005\dcdt.txt

%Fill remaining missing storage with linear interpolation 
 dcdt = interp_nan(dt,dcdt); % umol CO2/m2/s

%----- load flux data
load opec2005m2.txt
m2flx = opec2005m2; clear opec2005m2
%   1	  2	     3	   4	  5	      6	      7	       8	 9 	   10
% Year	Month	Day	  JD    hour	minute	Fc_wpl	LE_wpl	 Hs    H
% 11	  12	  13   14	15	   16     17        18       19     20   	        
% tau	u_star	  Uz   Ux   Uy   CO2avg  H2Oavg   Tsonic    Tfw    rho
%   21       22           23      24       25       26      27       28
% press	 wnd_dir_comp	wnd_spd	Fc_irga	 LE_irga  h2o_hmp  t_hmp	co2stor

%-----get friction speed u* (m/s)
ustar = m2flx(:,12); 

% Fill in bad ustar data
ind = find(ustar > 1.8);
ustar(ind) = (ws(ind)/4);
ind = find(ustar <= 0.0);
ustar(ind) = (ws(ind)/4);
ind = find(isnan(ustar));
ustar(ind) = (ws(ind)/4);

%------- Pressure data (kPa)
pr = m2flx(:,21);
ind = find(pr > 105);  pr(ind) = 99.00;
ind = find(pr < 95);   pr(ind) = 99.00;
ind = find(isnan(pr)); pr(ind) = 99.00;

%------- calculate NEP 
fcmg = m2flx(:,7);     % Fc_wpl in mg CO2/m2/s
% Conver Fc in mg CO2/m2/s to umol CO2/m2/s 
[fc] = C_conver(fcmg,Ta,pr,2);

nee = fc + dcdt;
%Fc26m 		= Fc26m*1000/44;  %unit convert from mg/m2/s to umol/m2/s

%%%%%%%%%%%%%%%% u* vs NEE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%xx(1:17520) = 0.25; 
%indnight = find(PPFD26m <= 0 & ~isnan(ustar.*nee));
%figure(5) 
%hold on
%plot(-nee/10,'b-');
%plot(ustar,'r-');
%plot(xx,'k--')
%set(gca,'box','on','xlim',[0 2],'FontSize',12);
%set(gca,'box','on','ylim',[-2 15],'FontSize',12);
%ylabel('NEE (\mumol m^-^2 s^-^1)','FontSize',14)
%xlabel('u* (m s^-^1)','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%######################################################################
% Clean NEE data
ind = find(nee < -35);
nee(ind) = NaN*ones(length(ind),1);
ind = find(nee > 30);
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 0 & nee <= 0);
nee(ind) = NaN*ones(length(ind),1);

%%%%%ind = find(PPFD26m <= 0 & Ts2 < 5 & nee <= 0);

ind = find(Ts2 < 0 & nee <= 0);  % No Photosynthesis when soil is frozen
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 0 & Ts2 < 5 & nee >= 5); % night time/low temp  respiration cap
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 0 & nee > 15); % night time respiration cap
nee(ind) = NaN*ones(length(ind),1);

% *********************************************
ind = find(PPFD <= 20 & Ts2 > 10 & nee < 2 ); % ??? dusk/dawn respiration minimum ???
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 20 & Ts2 > 15 & nee < 5 ); % ??? dusk/dawn respiration minimum ???
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 20 & Ts2 < 7 & nee > 7 ); %??? dusk/dawn respiration cap ???
nee(ind) = NaN*ones(length(ind),1);

ind = find(PPFD <= 20 & nee > 15); % night time respiration cap
nee(ind) = NaN*ones(length(ind),1);
% ***************************************************
% 
%  ind = find(PPFD <= 0 & Ts2 < 9 & nee > 7); % night respiration cap
%  nee(ind) = NaN*ones(length(ind),1);

 ind = find(PPFD <= 0 & Ts2 > 9 & Ts2 < 17 & nee > 10);
 nee(ind) = NaN*ones(length(ind),1);
% 
%   ind = find(PPFD <= 0 & Ts2 > 20);
%   nee(ind) = NaN*ones(length(ind),1);

%######################################################################
% % Clean NEE data
% ind = find(nee < -35);
% nee(ind) = NaN*ones(length(ind),1);
% ind = find(nee > 30);
% nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 0 & nee <= 0);
% nee(ind) = NaN*ones(length(ind),1);
% 
% %%%%%ind = find(PPFD26m <= 0 & Ts2 < 5 & nee <= 0);
% 
% ind = find(Ts2 < 0 & nee <= 0);  % Only for Photosynthesis
% nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 0 & Ts2 < 5 & nee >= 5);
% nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 0 & nee > 15);
% nee(ind) = NaN*ones(length(ind),1);
% 
% %*********************************************
% %ind = find(nee < 0);
% %nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 20 & Ts2 > 10 & nee < 2 );
% nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 20 & Ts2 > 15 & nee < 5 );
% nee(ind) = NaN*ones(length(ind),1);
% 
% ind = find(PPFD <= 20 & Ts2 < 7 & nee > 7 );
% nee(ind) = NaN*ones(length(ind),1);
% 
% %***************************************************
% 
% %  ind = find(PPFD <= 0 & Ts2 < 9 & nee > 7);
% %  nee(ind) = NaN*ones(length(ind),1);
% % % 
% %  ind = find(PPFD <= 0 & Ts2 > 9 & Ts2 < 17 & nee > 10);
% %  nee(ind) = NaN*ones(length(ind),1);
% % 
% %   ind = find(PPFD <= 0 & Ts2 > 20);
% %   nee(ind) = NaN*ones(length(ind),1);


%9900 leafless data
%AA Tsdavg 	= dailyavg(dt,Ts2,999,-999);
%AA Rdavg 	= dailyavg(dt,nee,999,-999);
%AA ii 		= find(Tsdavg(:,1) <= 100 | Tsdavg(:,1) >= 275); 
%AA Rwin 		= [Tsdavg(ii,2) Rdavg(ii,2:4)];
%AA ind 		= find(Rwin(:,1) > 8 & Rwin(:,2) < 1);
%AA Rwin(ind,2) = NaN*ones(length(ind),1);

%iifall 	= find((Tsdavg(:,1)>=290 & Tsdavg(:,1)<=334)); 
%Rfall 	= [Tsdavg(iifall,2) Rdavg(iifall,2:4)];



