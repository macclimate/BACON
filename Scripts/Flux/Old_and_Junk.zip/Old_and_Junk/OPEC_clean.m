function [] = OPEC_clean(year, site)

%% OPEC_clean.m
%%%
%%%
%%%
%%%
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths and Load Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%% Met data paths
% load_path_met = (['C:\Home\Matlab\Data\Met\Organized2\Met' site '\Column\30min\Met' site '_' year '.']);
% hdr_path_met = (['C:\Home\Matlab\Data\Met\Organized2\Docs\Met' site 'Output_Columns_' year '.txt']);

%%% Master Flux Table paths
load_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Organized2\Met' site '\Column\Met' site '_' year '.']);
hdr_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Organized2\Docs\Met' site '_FluxColumns.csv']);
hdr_path_met = (['C:\Home\Matlab\Data\Met\Raw1\Docs\Met' site '_OutputTemplate.csv']);

%%% Calculated OPEC Variables path
calc_path = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated4\Met' site '\Met' site '_' year '_']);
calc_path_met = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);

%%% Cleaned OPEC Variables path
clean_path = (['C:\Home\Matlab\Data\Flux\OPEC\Cleaned3\Met' site '\Met' site '_' year '_']);

%%% Output path
out_path_met = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);
out_path_op = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated4\Met' site '\Met' site '_' year '_']);


%% Load Header Files
% [hdr_cell_met] = jjb_hdr_read(hdr_path_met,',',3);
[hdr_cell_op]  = jjb_hdr_read(hdr_path_op,',',2);

%% Load Variables
%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);

%%% Pressure 

Pres =  jjb_load_var(hdr_cell_op, load_path_op, 'Pressure');

% %%% Air Temperature
% T_air = jjb_load_var(hdr_cell_met, load_path_met, 'T_HMP_Top');
% %%% PPFD down (umol m^-2 s^-1)
% PAR = jjb_load_var(hdr_cell_met, load_path_met, 'Par_Down_30Avg');
% %%% Wind Speed
% WS = jjb_load_var(hdr_cell_met, load_path_met, 'WS_WVT');
% 
% %%% Soil Temperature -- Pit A & Pit B -- Adjust these as needed (use switch)
% Ts2a = jjb_load_var(hdr_cell_met, load_path_met, 'T_Soil_2a');
% Ts5a = jjb_load_var(hdr_cell_met, load_path_met, 'T_Soil_5a');
% % Ts2b = jjb_load_var(hdr_cell, load_path, 'T_Soil_2b');
% % Ts5b = jjb_load_var(hdr_cell, load_path, 'T_Soil_5b');
% 
% %%% Soil Moisture
% SM5a = jjb_load_var(hdr_cell_met, load_path_met, 'M_Soil_5a');
% SM10a = jjb_load_var(hdr_cell_met, load_path_met, 'M_Soil_10a');
% 
% %%% u*
% ustar = jjb_load_var(hdr_cell_op, load_path_op, 'USTAR');
% %%% Air Pressure
% Pres = load([clean_path 'pres_cl.dat']);


%%  Clean Pressure
Pres(Pres > 105 | Pres < 95) = NaN;

% Method 1 - interpolation
Pres = interp_nan(dt, Pres);
%%% Method 2 - make missing values constant
% Pres (Pres > 105 | Pres < 95 | isnan(Pres)==0) == 99;

%% Save Variables

save([clean_path 'pres_cl.dat'],'Pres','-ASCII');

