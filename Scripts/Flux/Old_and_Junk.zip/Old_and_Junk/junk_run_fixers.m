OPEC_10min_fixer('TP74',2);
OPEC_10min_fixer('TP89',2);
OPEC_10min_fixer('TP02',2);

OPEC_EdiRe_fixer('TP74',2);
OPEC_EdiRe_fixer('TP89',2);
OPEC_EdiRe_fixer('TP02',2);

OPEC_compiler('TP02');
OPEC_compiler('TP74');
OPEC_compiler('TP89');

