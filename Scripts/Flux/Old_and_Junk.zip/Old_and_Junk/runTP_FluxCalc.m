for ste = 1%:1:4
    disp(ste);
for iii = 3;%1:1:5

modellist = [1;3;4;5;6];
GEP_model = modellist(iii)

switch ste
    case 1
TP39_FluxCalc(GEP_model);
    case 2
TP74_FluxCalc(GEP_model);
    case 3
TP89_FluxCalc(GEP_model);
    case 4
TP04_FluxCalc(GEP_model);
end
end
end