%%%%%%%%%
% This program calculate annual LE, Hs, NEE, R, GEP (NEE = R - GEP) data. The missing
% NEE were fixed by the relation of R vs. Ts (2cm) and GEP vs. PAR.
%
% (C) Bill Chen									File created:  Feb. 17, 1999
%														Last modified: Oct  14, 1999
%
% Revision: 
%           Oct 14, 1999 by Bill Chen
%           - add 1999 data
%           Sep 10, 1999 by Bill Chen
%           - correct respiration accordding to energy balance
%           Jul 26, 1999 by Bill Chen
%           - correct energy balance based on half-hour
%           May 25, 1999 by Bill Chen
%           - do daytime energy balance correction
%
% Altaf Arain, March 23, 2000
% - Modified for SOBS site
% Altaf Arain, April 05, 2001
% - Modified for year 2000
%%% July 19, 2001
%  - updated using clean Fc file and profile CO2 storage data 
% updated for Turkey Point, Altaf August 2, 2003
% updated for GRFS, Altaf Arain, Dec 8, 2004

%global DATA_PATH_BILL
%metglob1

close all, clear all;
%ustarc   = 0.01; %critical value for high wind method
ustarc   = 0.1; %critical value for high wind method

% ------------- 2005 -----------------------------

% Coefficients for flux underestimation correction factor (u* > 0.25) 
cr1_03 = 1.00; 
cr2_03 = 0.00; 

% Coefficients for respiration function (Jarvis type, u* > 0.30)
%c1_99 = 1.10; % not used for GRFS site
%c2_99 = 0.10;

% Coefficients for Respiration function (Similar to Chen et al. 1999) but using air temperature
% Coefficients calculated using "SOBS_Respiration_hw.m"
% updated "SOBS_get_99.m" to use air temperature in this function
% Example how use this function to get coeff: >> [avv,coeff] = SOBS_Respiration_hw(1999,0.35)
% equations must be divided by the ratio of (LE+H)/(Rn - G0 -jt ) for U* > 0.35 & U* < 0.8
 %R_coef03W = [8.6204    0.4212   12.7846];   	% u* > 0.1 for Met2 2005
 %R_coef03W = [9.1668    0.2944   14.3355];   	% u* > 0.2 for Met2 2005
 R_coef03W = [8.1073    0.2235   15.1918];   	% u* > 0.1 for Met2 2005 Ts= 2cm
 
 
% coefficient calculate using "Photosynth_hw_pl.m" using air temp 
%P_coef03W = [0.0966   18.3533];  % u* > 0.1 TP Met2
%P_coef03W = [0.0899   18.0680];   % u* > 0.2 TP
P_coef03W = [0.0690   16.8579];  % u* > 0.1 TP Met2; Ts = 2cm


% Start and end of growing season (roughly May 15 to Sep 30 for black spruce)
%stleaf03R = 75; edleaf03R = 334; % TP Growing season March 15 to Nov 30 when Ta > 0 oC
stleaf03R = 91; edleaf03R = 334; % Growing season all year for TP temperate systems; 1 Mat to 31 Oct, 
stleaf03RcutGEP = 151; edleaf03RcutGEP = 273; % Reduce GEP outside Growing season 


% --- get time series ---

% --- get time series ---
load decdoy_00.txt;
dt = decdoy_00(1:17520);
CST03 = dt;

clear decdoy_00

% Read Meteorlogy data
% 1	      2	      3	  4	    5	   6	    7	   8	  9	       10	      11	   12         13	  14	  15	    16	         17	      18	  19	   20	   21	   22	   23	   24	   25	  26	   27     28       29     30      31     32      33      34       35     36		37		38	  39	40	  41	42	  43	44	  45	46		47																								
%year	month	day	 JD	  hour	 minute	  airTC	  RH	ws_ms	wind_dir   PAR up	PAR down	NR Wm2	Hflux1	Hflux2	  PARcanopy	  M2Ts1A	M2Ts50A M2Ts20A	M2Ts10A	M2Ts5A	M2Ts2A	M2Ts11B	M2Ts50B	M2Ts20B	M2Ts10B  M2Ts5B M2Ts2B	M2Sm50A	M2Sm20A	M2Sm10A	M2Sm5A	M2Sm50B	M2Sm20B	M2Sm10B	M2Sm5B	tree1 tree2 tree3 tree4 tree5 tree6 tree7 tree8 tree9 tree10 tree11
load Meteo2005_m2.txt;
m2met = Meteo2005_m2;
clear Meteo2005_m2

%%%%%%%%%%%%%%% Ts %%%%%%%%%%%%%%%%%%%%%%%%
% Soil temp of both N and S sensors 
TsA2  = m2met(:,22); ind = find(TsA2  < -8); TsA2(ind)  = NaN; TsA2  = interp_nan(dt,TsA2); 
TsA5  = m2met(:,21); ind = find(TsA5  < -8); TsA5(ind)  = NaN; TsA5  = interp_nan(dt,TsA5); 
TsA10 = m2met(:,20); ind = find(TsA10 < -8); TsA10(ind) = NaN; TsA10 = interp_nan(dt,TsA10); 
TsA20 = m2met(:,19); ind = find(TsA20 < -8); TsA20(ind) = NaN; TsA20 = interp_nan(dt,TsA20); 
TsA50 = m2met(:,18); ind = find(TsA50 < -8); TsA50(ind) = NaN; TsA50 = interp_nan(dt,TsA50); 
TsA100= m2met(:,17); ind = find(TsA100< -8); TsA100(ind)= NaN; TsA100= interp_nan(dt,TsA100); 

TsB2  = m2met(:,28); ind = find(TsB2  < -8); TsB2(ind)  = NaN; TsB2  = interp_nan(dt,TsB2); 
TsB5  = m2met(:,27); ind = find(TsB5  < -8); TsB5(ind)  = NaN; TsB5  = interp_nan(dt,TsB5); 
TsB10 = m2met(:,26); ind = find(TsB10 < -8); TsB10(ind) = NaN; TsB10 = interp_nan(dt,TsB10); 
TsB20 = m2met(:,25); ind = find(TsB20 < -8); TsB20(ind) = NaN; TsB20 = interp_nan(dt,TsB20); 
TsB50 = m2met(:,24); ind = find(TsB50 < -8); TsB50(ind) = NaN; TsB50 = interp_nan(dt,TsB50); 
TsB100= m2met(:,23); ind = find(TsB100< -8); TsB100(ind)= NaN; TsB100= interp_nan(dt,TsB100); 


% ind = find(isnan(TsA2));  TsA2 = TsB2;
% ind = find(isnan(TsA5));  TsA5 = TsB5;
% ind = find(isnan(TsA10)); TsA10 = TsB10;
% ind = find(isnan(TsA20)); TsA20 = TsB20;
% ind = find(isnan(TsA50)); TsA50 = TsB50;

%Ts = (0.33*(TsA2+TsA5+TsA10) + 0.33*(TsB2+TsB5+TsB10)); % AVREGARE soil temperature of 10cm layer in two pits
Ts2 = (TsA5 + TsB5)/2; % AVREGARE soil temperature of 5cm layer in two pits

% REad data from Met1 to fill bad data at Met2
load C:\data\turkey\m1\2005\meteorol_nonfilled\soil\soil_clean_05.dat
TsA5m1 = soil_clean_05(:,9);
TsB5m1 = soil_clean_05(:,15);
Ts5m1  = (TsA5m1 + TsB5m1)/2; 

ind = [1:5736];      Ts2(ind) = Ts5m1(ind); % bad Ts data from 1-5736
ind = [16306:17520]; Ts2(ind) = Ts5m1(ind); % bad Ts data from 16306 to 17520

ST2CM03F= Ts2;


Sm5a  = m2met(:,32); %ind = find(TsA5  < -8); TsA5(ind)  = NaN; TsA5  = interp_nan(dt,TsA5); 
Sm10a = m2met(:,31); %ind = find(TsA10 < -8); TsA10(ind) = NaN; TsA10 = interp_nan(dt,TsA10); 
Sm20a = m2met(:,30); %ind = find(TsA20 < -8); TsA20(ind) = NaN; TsA20 = interp_nan(dt,TsA20); 
Sm50a = m2met(:,29); %ind = find(TsA50 < -8); TsA50(ind) = NaN; TsA50 = interp_nan(dt,TsA50); 

Sm5b  = m2met(:,36); %ind = find(TsA5  < -8); TsA5(ind)  = NaN; TsA5  = interp_nan(dt,TsA5); 
Sm10b = m2met(:,35); %ind = find(TsA10 < -8); TsA10(ind) = NaN; TsA10 = interp_nan(dt,TsA10); 
Sm20b = m2met(:,34); %ind = find(TsA20 < -8); TsA20(ind) = NaN; TsA20 = interp_nan(dt,TsA20); 
Sm50b = m2met(:,33); %ind = find(TsA50 < -8); TsA50(ind) = NaN; TsA50 = interp_nan(dt,TsA50); 


Sm50 = (Sm50a + Sm50b)/2;
Sm20 = (Sm20a + Sm20b)/2;
Sm10 = (Sm10a + Sm10b)/2;
Sm5 = (Sm5a + Sm5b)/2;


save C:\data\turkey\m3\2005\Sm50.dat    Sm50   -ASCII
save C:\data\turkey\m3\2005\Sm20.dat    Sm20   -ASCII
save C:\data\turkey\m3\2005\Sm10.dat    Sm10   -ASCII
save C:\data\turkey\m3\2005\Sm5.dat     Sm5   -ASCII

% air temperature (oC) for TP site to get respiration functions
Ta = m2met(:,7); 
ta03= Ta;
clear Ta

% --- get PPFD ---
% Note: used incident PAR data 
PARdn = m2met(:,12);
PPFD = PARdn;
Qa03 = PPFD;

% Wind Speed
%get wind speed (m/s)
ws = m2met(:,9);
ind = find(ws < -1);
ws(ind) = NaN;

%%%%%%%%%%%%%%% Storage %%%%%%%%%%%%%%%%%%%%%%%%
% CO2 storage
load C:\data\turkey\m2\2005\dcdt.txt
%Fill remaining missing storage with linear interpolation 
 dcdt   = interp_nan(dt,dcdt); % umol CO2/m2/s
 dcdt03 = dcdt; % CO2 storage

%%%%%%%%%%%%%%% NEP %%%%%%%%%%%%%%%%%%%%%%%%

%----- load flux data
load opec2005m2.txt
m2flx = opec2005m2; clear opec2005m2
%   1	  2	     3	   4	  5	      6	      7	       8	 9 	   10
% Year	Month	Day	  JD    hour	minute	Fc_wpl	LE_wpl	 Hs    H
% 11	  12	  13   14	15	   16     17        18       19     20   	        
% tau	u_star	  Uz   Ux   Uy   CO2avg  H2Oavg   Tsonic    Tfw    rho
%   21       22           23      24       25       26      27       28
% press	 wnd_dir_comp	wnd_spd	Fc_irga	 LE_irga  h2o_hmp  t_hmp	co2stor

%------- Pressure data (kPa)
pr = m2flx(:,21);
ind = find(pr > 105);  pr(ind) = 99.00;
ind = find(pr < 95);   pr(ind) = 99.00;
ind = find(isnan(pr)); pr(ind) = 99.00;

% ------- Fc
fcmg = m2flx(:,7);     % Fc_wpl in mg CO2/m2/s
% Conver Fc in mg CO2/m2/s to umol CO2/m2/s 
[fc] = C_conver(fcmg,ta03,pr,2);

nee = fc + dcdt;
nep2005raw = nee * -1;
save 'C:\data\turkey\m2\2005\nep2005raw'      nep2005raw  -ASCII

%Fc26m 		= Fc26m*1000/44;  %unit convert from mg/m2/s to umol/m2/s
nee03= nee;

%-----get friction speed u* (m/s)
ustar = m2flx(:,12); 

% Fill in bad ustar data
ind = find(ustar > 1.8);
ustar(ind) = (ws(ind)/4);
ind = find(ustar <= 0.0);
ustar(ind) = (ws(ind)/4);
ind = find(isnan(ustar));
ustar(ind) = (ws(ind)/4);

Ustar03 = ustar;

% rainfall
%load C:\data\GRFS\Flux\ppt.txt; 
%ppt= [ppt(1:end); ppt(17555:17561)];
%rain03 = ppt;

%%%%%%%%%%%%%%% Hs %%%%%%%%%%%%%%%%%%%%%%%%
% --- get sensible heat flux ---
% H = m2flx(:,10);
Hs = m2flx(:,9);
H03 = Hs;

%%%%%%%%%%%%%%% LE %%%%%%%%%%%%%%%%%%%%%%%%
% --- get latent heat flux ---
LE = m2flx(:,8);
le03 = LE;
LE03 = le03;

%%%%%%%%%%%%%%% Rn %%%%%%%%%%%%%%%%%%%%%%%%
% --- get net radiation ---
Rn = m2met(:,13);
Rn03 = Rn;
%Rn03 = [Rn03(1:4368); Rn03(4376:17568); Rn03(1:7) ];

% --- get soil heat flux ---
load G0.txt
G003 = G0;

% Heat Storage in air column
load Jt.txt; 
Jt03 = Jt;

% --- relationship of R vs Ts (2cm) ----
%=== high wind method ===
% Calculated with "SOBS_Respiration_hw.m" 
% Altaf: To produce the actual respiration relationship the first coefficient "4.3888" in the following
% equations must be divided by the ratio of (LE+H)/(Rn - G0 -jt ) for U* > 0.30 & U* < 1.0

% Logistic function
R03W = R_coef03W(1)./(1+exp(R_coef03W(2)*(R_coef03W(3)-ST2CM03F)));

% Exponential function
% Calculate Respiration using air tempearture (Function derived using nighttime Ta and Fc for u* > 0.35) 
% R03W = c1_03 * exp(c2_03.*ta03);

% --- calculate photosynthesis according to model ---

%=== high wind method ===
% coefficient calculate using "SOBS_Photosynth_hw_pl.m" 

P03W = P_coef03W(1).*Qa03.*P_coef03W(2)./(P_coef03W(1).*Qa03+P_coef03W(2));

% reduce model GEP outside growing seaosn by 
 ind = find(P03W > 0 & CST03 < stleaf03RcutGEP );
 P03W(ind) = P03W(ind)*0.50; % Cut winter model GEP by 1/3 (Altaf and Matthias)

 ind = find(P03W > 0 & CST03 > edleaf03RcutGEP);
 P03W(ind) = P03W(ind)*0.75; % Cut winter model GEP by 1/3 (Altaf and Matthias)

% ----- Remove spikes from NEE data 
% using sigma W data
%ind = find(sigmaw_03bs > 6);
%nee03(ind) = NaN*ones(length(ind),1);

ind = find(nee03 < -25);
nee03(ind) = NaN*ones(length(ind),1);
ind = find(nee03 > 20);
nee03(ind) = NaN*ones(length(ind),1);

ind = find(Qa03 <= 0 & nee03 <= 0);
nee03(ind) = NaN*ones(length(ind),1);

% --- fill missing nee by using model ---
%High Wind Method
%==============
nee03W 	= nee03;

ind = find(Qa03 <= 10 & (isnan(nee03W) | Ustar03 < ustarc)); % for night missing NEE data when u* < u*crt
nee03W(ind) = R03W(ind);

ind = find(Qa03 > 10 & isnan(nee03W) & CST03 >= stleaf03R & CST03 <= edleaf03R); % for daytime missing NEE data in growing season
nee03W(ind) = R03W(ind) - P03W(ind);

%nee03W(6880:6884) = (nee03W(6879)+nee03W(6885))/2; %interpolate few bad data points

%nee03W = interp_nan(CST03,nee03W); %delete later (just temporately use)


% --- respiration ---

%High Wind Method
%==============
R03WR = NaN*ones(17520,1);
ind 			= find(Qa03 <= 10 & Ustar03 >= ustarc); %nighttime R data at high wind
R03WR(ind) 	= nee03(ind);
ind 			= find(Qa03 <= 10 & Ustar03 < ustarc); %nighttime R data at low wind filled with model
R03WR(ind) 	= R03W(ind);
ind 			= find(Qa03 > 10 & CST03 >= stleaf03R & CST03 <= edleaf03R); %daytime growing season R with model 
R03WR(ind)  = R03W(ind);
ind 	    = find(isnan(R03WR)); % all others with model
R03WR(ind)	= R03W(ind);


% --- daytime energy balance correction ---
nee03W_ec_d = nee03W;

Ustar03 = interp_nan(CST03,Ustar03);

% a1 and a2 from fitting the ratio (H+LE)/(Rn-G-Jt) versus ustar obtained using "SOBS_EBC_ust_94_96_03" 
% Look for values at ustar=0.35 and ustar=1.0 to fit the curve
% This is based on available energy
%cr1 = 0.1723; cr2 = 0.9779; 
%rf03 = cr1*log(Ustar03) + cr2;

% cr1_03 = 0.96; cr2_03 = 0.05; for u* > 0.01

rf03 = cr1_03*(1-exp(-Ustar03./cr2_03));

% Use 0.8 threshhold for rf03 < 0.8. This would not create spikes during early morning and late evening low wind periods.
ind03 = find(rf03 <= 0.80);
rf03(ind03) = 0.80;

ind03 = find(Qa03 > 10 & ~isnan(Ustar03));
%nee03W_ec_d(ind03) = nee03W(ind03)./rf03(ind03);  %corrected according to energy inbalance factor
nee03W_ec_d(ind03) = nee03W(ind03)./1.0;           %corrected according to energy inbalance factor

ind03 = find(Qa03 > 10 & isnan(Ustar03));
%nee03W_ec_d(ind03) = nee03W(ind03)/0.96;          %correct 10%
nee03W_ec_d(ind03) = nee03W(ind03)/1.0;            %correct 10%

% --- nighttime energy balance correction ---
nee03W_ec_dn = nee03W_ec_d;
ind03 = find(Qa03 <= 10);
%nee03W_ec_dn(ind03) = nee03W_ec_dn(ind03)/0.96; % 10% nighttime correction because highwind night data was not corrected for energy balance. The value 0.96 comes from the (H+LE)/(Rn-G0-Jt) versus ustar curve for ustar > 0.35 and ustar < 0.8 since most ustar data at night are < 0.8
nee03W_ec_dn(ind03) = nee03W_ec_dn(ind03)/1.0; % 10% nighttime correction because highwind night data was not corrected for energy balance. The value 0.96 comes from the (H+LE)/(Rn-G0-Jt) versus ustar curve for ustar > 0.35 and ustar < 0.8 since most ustar data at night are < 0.8
%R03W_ec = R03WR/0.96;                            % for the same reason as above
R03W_ec = R03WR/1.0;                            % for the same reason as above

% ---- Remove spikes from NEE data 
% Manually 
 ind = [ ];
 
nee03W(ind)       = NaN*ones(length(ind),1);
nee03W(ind)       = (nee03W(ind-1) + nee03W(ind+1))/2;
nee03W_ec_dn(ind) = NaN*ones(length(ind),1);
nee03W_ec_dn(ind) = (nee03W_ec_dn(ind-1) + nee03W_ec_dn(ind+1))/2;

% Fill rest of missing NEE data with linear interpolation
nee03W       = interp_nan(CST03,nee03W); % fill with linear interpolation
nee03W_ec_d  = interp_nan(CST03,nee03W_ec_d); % fill with linear interpolation
nee03W_ec_dn = interp_nan(CST03,nee03W_ec_dn); % fill with linear interpolation

nep2005_ec_dn = nee03W_ec_dn * -1
save 'C:\data\turkey\m2\2005\nep2005_ec_dn.dat'      nep2005_ec_dn  -ASCII


%--- Respiration
% Jarvis function respiration
ind = [ ];

R03WR(ind) = NaN*ones(length(ind),1);
R03WR(ind) = (R03WR(ind-1) + R03WR(ind+1))/2;
R03W_ec(ind) = NaN*ones(length(ind),1);
R03W_ec(ind) = (R03W_ec(ind-1) + R03W_ec(ind+1))/2;

% Fill rest of missing R data with linear interpolation
ind = find(R03W < 0);
R03W(ind) = NaN;
ind = find(R03W_ec < 0);
R03W_ec(ind) = NaN;

R03WR   = interp_nan(CST03,R03WR); % fill with linear interpolation
R03W_ec = interp_nan(CST03,R03W_ec); % fill with linear interpolation

% ignore largeer gaps
%ind          = [8221:8268 9613:9756 10045:10089 12253:12297];
%R03WR(ind)   = NaN*ones(length(ind),1);
%R03W_ec(ind) = NaN*ones(length(ind),1);

%------------ Winter Crabon uptake problem -------------------

%ind = find(ta03 < 0 & ST2CM03F < 0 & nee03W_ec_dn < 0); %Fill winter daytime NEE uptake with model Resp (Altaf and Mathias)
%nee03W_ec_dn(ind) = R03W_ec(ind);

% Delete -ve NEE outside growing seaosn by 
%ind = find(GEP > 0 & isnan(nee03W) & CST03 < stleaf03R & CST03 > edleaf03R);
ind = find(nee03W_ec_dn < 0 & CST03 < 60 );
nee03W_ec_dn(ind) = R03W_ec(ind) ; % by 1/3 (Altaf and Matthias)


%------ Calculae GEP

GEP03W_ec  = R03W_ec - nee03W_ec_dn;

 ind = find(GEP03W_ec < 0); 
 GEP03W_ec(ind) = 0;

% --- calculate annual nee ---

% NEE = NEE * 12E-6 * 1800  = NEE * 0.0216

% From umolCO2/m2/s to g C/m2/h-hr = 12 * 1E-6 * 1800 = 0.0216

%nee03sumW_ec_d = sum(nee03W_ec_d)*216*1.0e-4 %annual carbon sequestration daytime (gC m^-2 y^-1)
nee03sumW_ec_dn = sum(nee03W_ec_dn)*216*1.0e-4 %annual carbon sequestration day and night (gC m^-2 y^-1)
%nee03sumW = sum(nee03W)*216*1.0e-4 %annual carbon sequestration only highwind correction (gC m^-2 y^-1)

R03sumW_ec = sum(R03W_ec)*216*1.0e-4 %annual respiration energy balance and highwind correction (gC m^-2 y^-1)

GEP03sumW = R03sumW_ec - nee03sumW_ec_dn

  

% -----------  claculate LE and Hs data, 2003-04  -----------

rf03 = cr1_03*(1-exp(-Ustar03./cr2_03));

%LE03tpW_ec = LE03./rf03;
%SHF03tpW_ec = H03./rf03;

LE03tpW_ec = LE03./1.0;
SHF03tpW_ec = H03./1.0;

% Clean data
%ind = find(sigmaw_03tp > 6);
%LE03tpW_ec(ind)  = NaN*ones(length(ind),1);
%SHF03tpW_ec(ind) = NaN*ones(length(ind),1);

% ind = [   ];
% 
% LE03tpW_ec(ind) = NaN*ones(length(ind),1);
% LE03tpW_ec(ind) = (LE03tpW_ec(ind-1) + LE03tpW_ec(ind+1))/2;

% Remove large spikes
ind = find(LE03tpW_ec > 800); 
LE03tpW_ec(ind) = NaN*ones(length(ind),1);
LE03tpW_ec(ind) = (LE03tpW_ec(ind-1) + LE03tpW_ec(ind+1))/2;

ind = find(LE03tpW_ec < -200); 
LE03tpW_ec(ind) = NaN*ones(length(ind),1);
LE03tpW_ec(ind) = (LE03tpW_ec(ind-1) + LE03tpW_ec(ind+1))/2;

% Fill all other smaller gaps by interpolation
% LE03tpW_ec = interp_nan(CST03,LE03tpW_ec);

%%%% Sensibel Heat Flux %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fill large gaps with previous days. Largest gap is 70 data points
ind = [   ];

SHF03tpW_ec(ind) = NaN*ones(length(ind),1);
SHF03tpW_ec(ind) = (SHF03tpW_ec(ind-1) + SHF03tpW_ec(ind+1))/2;


ind = find(SHF03tpW_ec > 800);
SHF03tpW_ec(ind) = NaN*ones(length(ind),1);
SHF03tpW_ec(ind) = (SHF03tpW_ec(ind-1) + SHF03tpW_ec(ind+1))/2;

ind = find(SHF03tpW_ec < -200);
SHF03tpW_ec(ind) = NaN*ones(length(ind),1);
SHF03tpW_ec(ind) = (SHF03tpW_ec(ind-1) + SHF03tpW_ec(ind+1))/2;

% Fill all other smaller gaps by interpolation
% SHF03tpW_ec = interp_nan(CST03,SHF03tpW_ec);


% --- save data ---
R03tpW         = R03WR;
R03tpW_ec      = R03W_ec;
nee03tpW       = nee03W;
nee03tpW_ec_dn = nee03W_ec_dn;
GEP03tpW_ec    = GEP03W_ec;

% Cumulative annual ET 
% Fill all other smaller gaps by interpolation
ta03 = interp_nan(CST03,ta03);

%E2005 = LE03tpW_ec./lambda(ta03)*60*30;  %evapotrsnpiration rate in mm/hhour
E2005 = LE03tpW_ec./343;  %evapotrsnpiration rate in mm/hhour
cumE2005 = cumsum(E2005);
cumE2005(end)

%if 1==1
   
%save  'C:\data\turkey\m2\2005\R2005m2W.dat'         R03tpW     -ASCII
save  'C:\data\turkey\m2\2005\R2005m2W_ec.dat'      R03tpW_ec  -ASCII
save  'C:\data\turkey\m2\2005\GEP2005m2W_ec.dat'    GEP03tpW_ec  -ASCII
%save  'C:\data\turkey\m2\2005\nee2005m2W.dat'       nee03tpW     -ASCII
save  'C:\data\turkey\m2\2005\nee2005m2W_ec_dn.dat' nee03tpW_ec_dn  -ASCII
save  'C:\data\turkey\m2\2005\LE2005m2W_ec.dat'     LE03tpW_ec      -ASCII
save  'C:\data\turkey\m2\2005\E2005m2W_ec_mmhhour.dat'     E2005      -ASCII
save  'C:\data\turkey\m2\2005\SHF2005m2W_ec.dat'    SHF03tpW_ec     -ASCII


%end

% Plot data for visual ispection
%figure(1)
%plot([-nee03W,sigmaw_03tp])

figure(032)
plot(-nee03tpW_ec_dn,'b')
hold on
%plot(Qa03/50,'r')

figure(033)
plot(R03tpW_ec)

figure(034)
plot(GEP03tpW_ec)

figure(035)
hold on
% plot(Rn03,'r')
plot(LE03tpW_ec)

figure(036)
hold on
plot(Rn03,'c')
plot(SHF03tpW_ec,'r')
plot(LE03tpW_ec,'b')
plot((G003+Jt03),'g')

% Coefficients for 2002-03 nighttime NEE correction

a  = SHF03tpW_ec + LE03tpW_ec;
%ind = find(a > 650); a(ind) = NaN;
b = Rn03 - G003 - Jt03;
resid = b - a; 

% Coefficients for 2002-03 nighttime NEE correction
%ind = find(M1Rain > 0);
ind = 1;

a(ind) = NaN;
b(ind) = NaN;

ind = find(~isnan(a) & ~isnan(b)); 
aa = a(ind);
bb = b(ind);

% Correlation Coef

corc = corrcoef(bb, aa);
corc = num2str(corc(1,2), 2)

% Fit reg line, spruce
cc= polyfit(bb,aa,1);
%jj = min(bb):0.5:max(aa);
jj = min(bb):0.5:800;
kk = polyval(cc,jj);

% Slope of regression line
s = num2str((kk(end)-kk(1))/(jj(end)-jj(1)), 3)

% Intercept of regression line
% Note: jj is X-axis and kk is Y-axis
% For visual: plot(jj,kk,'k-'); grid on; zoom on
jjintc = round(min(jj):0.5:max(jj));
ind = find(jjintc == 0);
interc = num2str(kk(ind),4)

figure(37)
hold on
plot(bb,aa,'k.');
hold on
plot(jj,kk,'k-','LineWidth',2)
axis([-100 900 -100 900])
%title('2002-03','color','k','FontSize',16) 
ylabel('H+LE (W m^{-2})','FontSize',16)
xlabel('Rn-G-J (W m^{-2})','FontSize',16)
box on
hold off

print -dmeta C:\data\turkey\m2\2005\EBalance_2005m2



