function [GEP_model] = TP_GEP(indep_vars, GEP, yr_list, tracker, block_avg, model_type, yr_agg, AB_corr, max_method)

GEP_model(1:length(indep_vars),1) = NaN;
%% SET DEFAULTS:

if isempty(model_type);
    model_type = 'scaled'
end

if isempty(block_avg);
    block_avg = 'on'
end

if isempty(yr_agg);
    yr_agg = 'off'
end

if isempty(AB_corr);
    AB_corr = 'off'
end

[rows cols] = size(indep_vars);
if cols == 1;
    PAR(:,1) = indep_vars(:,1);
else
    PAR(:,1) = indep_vars(:,1);
    Ta(:,1) = indep_vars(:,2);
    Ts(:,1) = indep_vars(:,3);
    VPD(:,1) = indep_vars(:,4);
    SM(:,1) = indep_vars(:,5);
end

colorlist = ['r';'g';'b';'k';'c';'m'];
%%
figure(12);clf;
PAR_test = (0:100:2500)';
GEP_tracker(:,1) = tracker(:,1).*tracker(:,3).*tracker(:,5).*tracker(:,6).*tracker(:,8) ...
    .*tracker(:,11).*tracker(:,13).*tracker(:,15).*tracker(:,12);
switch model_type
    %% CASE 1: SCALING OF GEP ACCORDING TO ENVIRONMENTAL VARIABLES:
    case 'scaled'
        max_GEP(1:length(GEP),1) = NaN;

        if strcmp(yr_agg,'off') == 1;
            %%% Find different years included for analysis
            [yrs,starts,ends]= jjb_find_diff(yr_list);
        else
            yrs = 1;
            yr_list(~isnan(yr_list),1) = 1;
            starts = 1;
            ends = length(yr_list);
        end

        sp_ctr = 1; ii = 0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for j = 1:1:length(yrs)
            year_num = yrs(j); disp(year_num);
            start_col = starts(j);
            end_col = ends(j);


            switch max_method
                case 'new'
                    %%%%%%%%%%%%% TANGENT %%%%%%%%%%%%%%%%%%%%
                    GEP_use(:,1) = GEP(yr_list == yrs(j));
                    GEP_use_r = reshape(GEP_use,48,[]);
                    PAR_use(:,1) = PAR(yr_list == yrs(j));
                    PAR_use_r = reshape(PAR_use,48,[]);

                    for k = 1:1:48
                        GEP_ens(:,1) = GEP_use_r(k,:);
                        GEP_ens(isnan(GEP_ens),1) = -5;
                        [B,IX] = sort(GEP_ens,'descend');
                        GEP_max2(1:10,k) = B(1:10,1);
                        PAR_max2(1:10,k) = PAR_use_r(k,IX(1:10,1));
                        clear GEP_ens B IX
                    end

                    GEP_max3 = reshape(GEP_max2,[],1);
                    PAR_max3 = reshape(PAR_max2,[],1);
                    GEP_max4(~isnan(GEP_max3.*PAR_max3),1) = GEP_max3(~isnan(GEP_max3.*PAR_max3),1);
                    PAR_max4(~isnan(GEP_max3.*PAR_max3),1) = PAR_max3(~isnan(GEP_max3.*PAR_max3),1);

                    GEP_max4(PAR_max4==0,1) = 0;
                    figure(12+ii); subplot(3,2,sp_ctr); plot(PAR_max4,GEP_max4,'b.'); hold on;

                    [coeff y_pred_en r2_en sigma_en] = hypmain1([0.01 10 0.1], 'fit_hyp1', PAR_max4, GEP_max4);
                    GEP_test = coeff(1).*PAR_test.*coeff(2)./(coeff(1).*PAR_test + coeff(2));

                    plot(PAR_test,GEP_test,'r','LineWidth',4);
                    title(['Ideal PAR vs GEP for year: ' num2str(year_num)])
                    ylabel('GEP'); xlabel('PAR');


                case 'old'
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    %%% For low-PAR times:
                    ind_ideal_low = find(GEP_tracker == 1 & yr_list == yrs(j) & Ts > 17 & Ta > 21 & VPD > 0 & VPD < 0.8 & PAR >= 10 & PAR < 800 & SM > 0.08 & GEP > 2);
                    %%% For high-PAR times:
                    ind_ideal_high = find(GEP_tracker == 1 & yr_list == yrs(j) & Ts > 18 & Ta > 22 & VPD > 0 & VPD < 0.8 & PAR >= 800 & SM > 0.08 & GEP > 10);
                    disp(['ideal low pts: ' num2str(length(ind_ideal_low)) ', ideal high pts: ' num2str(length(ind_ideal_high))]);
                    %%% Overall Ideal Points:
                    ind_ideal = [ind_ideal_low; ind_ideal_high];
                    %% Plot all ideal points and bin averaged points
                    figure(12+ii); subplot(3,2,sp_ctr); plot(PAR(ind_ideal),GEP(ind_ideal),'b.'); hold on;
                    bavg = blockavg(PAR(ind_ideal), GEP(ind_ideal), 100, 70, -25);
                    ind_ok = find(~isnan(bavg(:,1).*bavg(:,2)) & bavg(:,4) > 4);
                    plot(bavg(ind_ok,1),bavg(ind_ok,2),'ro','MarkerFaceColor','r')

                    %% Select the proper x and y for regression:
                    switch block_avg
                        case 'on'
                            x = [0; bavg(ind_ok,1)];
                            y = [0; bavg(ind_ok,2)];
                        case 'off'
                            x = PAR(ind_ideal,1);
                            y = GEP(ind_ideal,1);
                    end
                    %%% Run hyperbolic hyperbola eqn
                    [coeff y_pred r2 sigma] = hypmain1([0.01 10 0.1], 'fit_hyp1', x, y);
                    %%% Produce the ideal curve:
                    GEP_test = coeff(1).*PAR_test.*coeff(2)./(coeff(1).*PAR_test + coeff(2));
                    %%% Plot the results onto the graph:
                    plot(PAR_test,GEP_test,'r','LineWidth',4);
                    title(['Ideal PAR vs GEP for year: ' num2str(year_num)])
                    ylabel('GEP'); xlabel('PAR');
                    %%% Produce the max GEP for the entire year:
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
            max_GEP_temp(1:length(PAR(yr_list == year_num)),1) = 0;
            max_GEP_temp(PAR(yr_list == year_num) >=10,1) = coeff(1).*PAR(PAR(yr_list == year_num) >=10,1).*coeff(2)./(coeff(1).*PAR(PAR(yr_list == year_num) >=10 ,1) + coeff(2));
            max_GEP(yr_list == year_num,1) = max_GEP_temp(:,1);

            clear max_GEP_temp coeff y ind_ideal_low ind_ideal_high bavg ind_ok x y GEP_test GEP_max* PAR_max* GEP_u* PAR_u*
            sp_ctr = sp_ctr + 1;
            if sp_ctr == 7; sp_ctr = 1; ii = ii+1; end

        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCALING FACTORS %%%%%%%%%%%%%%%%%%
        % Ta_tracker(:,1) = tracker(:,1).*tracker(:,11).*tracker(:,13).*tracker(:,16);
        %  [GEP_adj Ta_sf] = TP_Ta_sf(Ta, GEP, Ta_tracker, 'off');
        Ts_tracker(:,1) = tracker(:,5).*tracker(:,11).*tracker(:,13).*tracker(:,16);
        [GEP_adj_Ts Ts_sf] = TP_Ts_sf(Ts, GEP, Ts_tracker, 'off');

        VPD_tracker(:,1) = tracker(:,3).*tracker(:,6).*tracker(:,11).*tracker(:,13).*tracker(:,16);
        [GEP_adj_VPD VPD_sf] = TP_VPD_sf(VPD, GEP_adj_Ts, VPD_tracker, 'off','single');

        SM_tracker(:,1) = tracker(:,8).*tracker(:,11).*tracker(:,13).*tracker(:,16);
        [GEP_adj_SM SM_sf] = TP_SM_sf(SM, GEP_adj_VPD, SM_tracker, 'off');

        final_sf = Ts_sf.*VPD_sf.*SM_sf;
        figure(77);clf; plot(final_sf);
        GEP_model = max_GEP.*final_sf;


        figure(34); clf
        plot(max_GEP); hold on;
        plot(GEP,'g');
        plot(GEP_model,'r');
        %%
    case 'avg'
        GEP_model(1:length(GEP),1) = NaN;

        if strcmp(yr_agg,'off') == 1;
            %%% Find different years included for analysis
            [yrs,starts,ends]= jjb_find_diff(yr_list);
        else
            yrs = 1;
            yr_list(~isnan(yr_list),1) = 1;
            start_col = 1;
            end_col = length(yr_list);
        end

        sp_ctr = 1; ii = 0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for j = 1:1:length(yrs)
            year_num = yrs(j); disp(year_num);
            start_col = starts(j);
            end_col = ends(j);
            ind_good = find((GEP_tracker.*tracker(:,16)) == 1 & yr_list == yrs(j));
            x = PAR(ind_good);
            y = GEP(ind_good);

            figure(12+ii); subplot(3,2,sp_ctr); plot(x,y,'b.'); hold on;

            [coeff y_pred r sigma] = hypmain1([0.01 10 0.1], 'fit_hyp1', x, y);
            GEP_test = coeff(1).*PAR_test.*coeff(2)./(coeff(1).*PAR_test + coeff(2));

            plot(PAR_test,GEP_test,'r','LineWidth',4);
            title(['Ideal PAR vs GEP for year: ' num2str(year_num)])
            ylabel('GEP'); xlabel('PAR');

            %%% Real numbers for the year:
            GEP_model(yr_list == yrs(j),1) = coeff(1).*PAR(yr_list == yrs(j),1).*coeff(2)./(coeff(1).*PAR(yr_list == yrs(j),1) + coeff(2));

            clear x y GEP_test
            sp_ctr = sp_ctr + 1;
            if sp_ctr == 7; sp_ctr = 1; ii = ii+1; end
        end

        figure(35); clf
        plot(GEP,'g');hold on;
        plot(GEP_model,'r');

    case 'window'

        disp('this option is not installed yet.');

end


switch AB_corr
    case 'on'

        pw_total = jjb_AB_gapfill(GEP_model, GEP, (1:1:length(GEP))',100, 20, 'off', [], [0 45]);

        GEP_model = GEP_model.*pw_total(:,2);

        figure(36); clf
        plot(GEP,'g');hold on;
        plot(GEP_model,'r');
        figure(37); clf; plot(pw_total(:,1),pw_total(:,2),'b.-');
    case 'off'

end
