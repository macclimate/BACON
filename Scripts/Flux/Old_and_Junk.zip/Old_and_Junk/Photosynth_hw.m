function avg = TP_Photosynth_hw(year)
% this program to process the relation between PPFD and Photosynthesis
% the relationship of respiration with soil temperature at 2 cm depth is
% according to high wind method.
%
% (C) Bill Chen									File created:  03 Mar. 1998
%														Last modified: 19 Mar. 1999
%
% Altaf Arain, March 22, 2000
% - For SOBS site
% Altaf Arain, April 05, 2001
% - updated for year 2000
% updated for Turkey Point, Altaf July 31, 2003
% Modified for GRFS, Altaf Arain, Dec 8, 2004
% Modified for TP Met2 OPEC 2005 data. Altaf ad Mathias, May 25, 2006

% global DATA_PATH_BILL

switch year
case 2005
   get_2005
   td = [1:365];

 % Coefficinet from Respiration_hw function  
 %R_coeff = [9.8005    0.1095   17.8285  ];   %u* > 0.15   
 % R_coeff = [ 9.2726    0.1842   11.7468 ];   %u* > 0.25 for GRFS site - One soil pit used%

 %R_coeff = [8.6204    0.4212   12.7846];   %u* > 0.1 for Met2 2005 for Ts at 5 cm
%R_coeff = [9.1668    0.2944   14.3355];   %u* > 0.2 for Met2 2005 for Ts at 5 cm
 
 R_coeff = [8.1073    0.2235   15.1918];   %u* > 0.1 for Met2 2005 for Ts at 2 cm
 
 
 
%   leafstart = 1;
%   leafend = 365;
   leafstart = 90;
   leafend = 304;

end

Qthresh 	= 10; %(daytime Q >= 10 umol m^-2 s^-1)
Awa		    = 0.62;
ka			= 0.540;
kh			= 0.756;
alpha       = 0.03;

%ALa = ALa/0.98 - 0.62;
%ALh = ALh/0.98 - 0.34;

R	= R_coeff(1)./(1+exp(R_coeff(2).*(R_coeff(3)-Ts2))); %respiration
%Qa       = Q0.*(1-exp(-ka*ALa)+exp(-ka*(ALa+Awa)).*(1-exp(-kh*ALh)))*(1-alpha);

Qa = Q0;
GEP = R - nee;

ind = find(GEP < 0);
GEP(ind) = NaN;

figure(1)
plot(GEP,'g')
figure(2)
plot(R,'r')
figure(3)
plot(-nee,'b')


% Clear GEP vs PPFD curve for photosynthesis model

 ind = find(year==2005 & Qa > 1400 & Qa < 2200 & GEP < 10);
 GEP(ind) = NaN*ones(length(ind),1);
 
 ind = find(year==2005 & Qa > 1200 & Qa < 2200 & GEP < 8);
 GEP(ind) = NaN*ones(length(ind),1);
 
 ind = find(year==2005 & Qa > 1000 & Qa < 2200 & GEP < 6);
 GEP(ind) = NaN*ones(length(ind),1);

ind = find(year==2005 & Qa > 500 & Qa < 2200 & GEP < 5);
GEP(ind) = NaN*ones(length(ind),1);

ind = find(year==2005 & Qa > 400 & Qa < 2200 & GEP < 4);
GEP(ind) = NaN*ones(length(ind),1);

ind = find(year==2005 & Qa > 300 & Qa < 2200 & GEP < 3);
GEP(ind) = NaN*ones(length(ind),1);

ind = find(year==2005 & Qa > 250 & Qa < 2200 & GEP < 2);
GEP(ind) = NaN*ones(length(ind),1);

ind = find(year==2005 & Qa > 100 & Qa < 2200 & GEP < 1);
GEP(ind) = NaN*ones(length(ind),1);

ind   	= find(dt > leafstart & dt < leafend & Qa > Qthresh & Qa < 1900);
%ind   	= find(TimeX > leafstart & TimeX < leafend & Q_av > Qthresh);

%plot(Qa(ind),GEP(ind),'.');grid;

figure(4)
plot(Qa(ind),GEP(ind),'.')

avg   = blockavg(Qa(ind),GEP(ind),50,100,0);
%avg   = blockavg(Q_av(ind)',GEP_av(ind)',50,9999,-9999);
%% plot(avg(:,1),avg(:,2),'gs');



