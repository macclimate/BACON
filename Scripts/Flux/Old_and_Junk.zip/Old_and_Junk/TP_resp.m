function [resp] = TP_resp(T, NEE, yr_list, tracker, block_avg, bavg_params, fn_type, yr_agg, AB_corr)


resp(1:length(T),1) = NaN;
%% SET DEFAULTS:

if isempty(fn_type);
    fn_type = 'log'
end

if isempty(block_avg);
    block_avg = 'on'
end

if isempty(bavg_params);
    bavg_params = [0.5 25 -10];
end

if isempty(AB_corr);
    AB_corr = 'off'
end

if isempty(yr_agg);
    yr_agg = 'off'
end
colorlist = ['r';'g';'b';'k';'c';'m'];
%% Create index:
if strcmp(yr_agg,'off') == 1;
    %%% Find different years included for analysis
    [yrs,starts,ends]= jjb_find_diff(yr_list);
else
    yrs = 1;
    yr_list(~isnan(yr_list),1) = 1;
    starts = 1;
    ends = length(yr_list);
end

sp_ctr = 1; ii = 0;
for j = 1:1:length(yrs)
    year_num = yrs(j);
    start_col = starts(j);
    end_col = ends(j);

    ind_resp = find(tracker == 1 & yr_list == yrs(j));

    switch block_avg
        case 'on'
            test_T = (-5:1:35);
            %%% Block average
            bavg = blockavg(T(ind_resp),NEE(ind_resp),bavg_params(1),bavg_params(2),bavg_params(3));
            %%% Use only "good" data rows:
            ind_ok_bavg = find(~isnan(bavg(:,1).*bavg(:,2)) & bavg(:,4) > 5);
            %%% declare x and y
            x = bavg(ind_ok_bavg,1); y = bavg(ind_ok_bavg,2);
        case 'off'
            x = T(ind_resp); y = NEE(ind_resp);
    end


    switch fn_type
        case 'log'
            [coeff,y,r2,sigma] = fitmain([5 .1 .1], 'fitlogi5', x, y);
            %%% Estimate Respiration Function using logistic function:
            test_resp = coeff(1) ./(1 + exp(coeff(2).*(coeff(3)-test_T)));
            %%% Estimate Respiration for all data:
            real_resp(1:length(T(yr_list == year_num,1))) = coeff(1) ./(1 + exp(coeff(2).*(coeff(3)-T(yr_list == year_num,1))));

        case 'exp'
            %%% Fit data to linear function
            X = [x ones(length(x),1)];
            [b_ln,bint_ln,r_ln,rint_ln,stats_ln] = regress_analysis(real(log(y)),X,0.05);

            test_resp = (exp(b_ln(2))).* exp(test_T.*b_ln(1));
            real_resp(1:length(T(yr_list == year_num,1))) = (exp(b_ln(2))).* exp(T(yr_list == year_num,1).*b_ln(1));

    end

    figure(1+ii)
    subplot(3,2,sp_ctr)
    plot(T(ind_resp),NEE(ind_resp),'k.'); hold on;
    try
        plot(bavg(ind_ok_bavg,1), bavg(ind_ok_bavg,2),'bo')
    catch
    end
    plot(test_T,test_resp,'r-','LineWidth',6);
    ylabel('NEE (Resp) ');
    xlabel('Ts');
    title(['Resp Curve with bin avg ' block_avg ' and ' fn_type ' function - year ' num2str(year_num)]);

    figure(11)
    plot(test_T,test_resp,colorlist(j),'LineWidth',6); hold on;
    title(' Resp curves')
    ylabel('NEE (Resp) ');
    xlabel('Ts');

figure(21+ii)
subplot(3,2,sp_ctr);
plot((1:1:length(real_resp))', real_resp, colorlist(j));
title(['resp for year: ' num2str(year_num)]);
    sp_ctr = sp_ctr + 1;
    if sp_ctr == 7; sp_ctr = 1; ii = ii+1; end

    
    resp(yr_list == year_num,1) = real_resp;
    clear real_resp;
end
figure(11)
yr_str = num2str(yrs);
legend(yr_str,2);
%% AB corr
switch AB_corr
    case 'on'
resp_meas(:,1) = NEE(:,1);
resp_meas(tracker~=1,1) = NaN;

        pw_total = jjb_AB_gapfill(resp, resp_meas, (1:1:length(resp))',100, 20, 'off', [], []);

        resp_AB = resp.*pw_total(:,2);
        
        figure(46); clf
        plot(resp_meas,'g');hold on;
        plot(resp,'r');
        figure(47); clf; plot(pw_total(:,1),pw_total(:,2),'b.-');
        
   figure(20); clf
plot(resp_meas,resp,'r.'); hold on;
axis([-20 20 -20 20])
plot([-20 20],[-20 20],'k--')
figure(21); clf
plot(resp_meas,resp_AB,'r.'); hold on;
plot([-20 20],[-20 20],'k--')
axis([-20 20 -20 20])
       
% Check goodness of fit for each model (if AB correction is used);
disp('for no AB correction: ')
[stats] = jjb_model_stats(NEE, resp)
disp('for AB correction data: ')
   stats2 = jjb_model_stats(NEE, resp_AB)
   
   
   
   
   
   
   resp = resp_AB; 
    case 'off'
disp('for no AB correction: ')
[stats] = jjb_model_stats(NEE, resp)
      

        


end

