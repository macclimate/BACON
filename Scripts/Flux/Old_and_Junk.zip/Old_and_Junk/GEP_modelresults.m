%% Flux calculation model comparison:
% 
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M2_model1.dat','M2_model1','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M2_model3.dat','M2_model3','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M2_model4.dat','M2_model4','-ASCII');
% 
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M3_model1.dat','M3_model1','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M3_model3.dat','M3_model3','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M3_model4.dat','M3_model4','-ASCII');
% 
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M4_model1.dat','M4_model1','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M4_model3.dat','M4_model3','-ASCII');
% save('C:\HOME\MATLAB\Data\Data_Analysis\Model_Comparison\M4_model4.dat','M4_model4','-ASCII');

if ispc == 1
    dataloc = 'C:/HOME/'
else
    dataloc = '/home/jayb/'
end

M2_model1 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M2_model1.dat']);
M2_model3 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M2_model3.dat']);
M2_model4 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M2_model4.dat']);

M3_model1 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M3_model1.dat']);
M3_model3 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M3_model3.dat']);
M3_model4 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M3_model4.dat']);

M4_model1 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M4_model1.dat']);
M4_model3 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M4_model3.dat']);
M4_model4 = load([dataloc 'MATLAB/Data/Data_Analysis/Model_Comparison/M4_model4.dat']);

yr_labels = ['2003';'2004';'2005';'2006';'2007'];
yr_ticks = (1:1:5);

%% Figure 1 - comparison of outputs for Met 2:
figure(1);clf
title('Comparison for Met 2');
subplot(3,1,1)
plot(M2_model1(:,1),'b.-'); hold on
plot(M2_model3(:,1),'rx-'); 
plot(M2_model4(:,1),'gp-'); 
title('NEE - Met 2')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
plot(M2_model1(:,2),'b.-'); hold on
plot(M2_model3(:,2),'rx-'); 
plot(M2_model4(:,2),'gp-'); 
title('Resp (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
plot(M2_model1(:,4),'b.-'); hold on
plot(M2_model3(:,4),'rx-'); 
plot(M2_model4(:,4),'gp-'); 
title('GEP (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

%% Figure 2 - comparison of outputs for Met 3:
figure(2);clf
title('Comparison for Met 3');
subplot(3,1,1)
plot(M3_model1(:,1),'b.-'); hold on
plot(M3_model3(:,1),'rx-'); 
plot(M3_model4(:,1),'gp-'); 
title('NEE - Met 3')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
plot(M3_model1(:,2),'b.-'); hold on
plot(M3_model3(:,2),'rx-'); 
plot(M3_model4(:,2),'gp-'); 
title('Resp (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
plot(M3_model1(:,4),'b.-'); hold on
plot(M3_model3(:,4),'rx-'); 
plot(M3_model4(:,4),'gp-'); 
title('GEP (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on


%% Figure 3 - comparison of outputs for Met 4:
figure(3);clf
title('Comparison for Met 4');
subplot(3,1,1)
plot(M4_model1(:,1),'b.-'); hold on
plot(M4_model3(:,1),'rx-'); 
plot(M4_model4(:,1),'gp-'); 
title('NEE - Met 4')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,2)
plot(M4_model1(:,2),'b.-'); hold on
plot(M4_model3(:,2),'rx-'); 
plot(M4_model4(:,2),'gp-'); 
title('Resp (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on

subplot(3,1,3)
plot(M4_model1(:,4),'b.-'); hold on
plot(M4_model3(:,4),'rx-'); 
plot(M4_model4(:,4),'gp-'); 
title('GEP (Filled)')
legend('Mod1 - all pooled','Mod2 - Pooled R', 'Mod3 - All indiv',3)
set(gca,'XTick',yr_ticks);
set(gca,'XTickLabel',yr_labels);
grid on
