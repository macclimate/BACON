% this program calculate heat sotrage at BS site, using Peter Blanken's model
%
% (c) Bill Chen                                    File created:  Jan. 28, 1999
%                                                  Last modified: Jan. 28, 1999

% Altaf Arain; April 05, 2001
% - upadted for 2000 data

%global DATA_PATH_BILL
%metglob1 

load  C:\data\sobs\2000\halfhour\air_temperature_hmp_ventilated_24m % get air temperature (oC)at 26 m
Ta1 = air_temperature_hmp_ventilated_24m;

ind     = 2:length(Ta1)-1;
dT99    = Ta1(ind+1) - Ta1(ind-1);
dT99    = [NaN;dT99;NaN];
Jt = 22.25*0.6*dT99 + 1.66;

save 'C:\data\sobs\2000\halfhour\Jt_00bs.txt' Jt -ASCII
