function [std_pred] = NEE_random_error_estimator(data, tol, Ustar_th)
% NEE_uncert_estimator.m
% This function 
% Data should be in a structure file with the form: data.<variable_name> of
% arbitrary length (as long as data.Year and data.dt are there, they can be
% any length)
% inputs:
% 1. structure file with all variables as next level
% 2. tolerances for differences in PAR, Ta, Ts, WS, NEE, SM, WDir, VPD
% 3. A ustar threshold, above which we can assume profile to be well-mixed

if isempty(tol)
    Ta_tol = 3;
    PAR_tol = 100;
    Ts_tol = 1;
    SM_tol = 0.02;
    WS_tol = 2;
%     VPD_tol = 0.5;
end

% Calculate VPD if it doesn't exist
if isfield(data,'VPD')==0;
    data.VPD = VPD_calc(data.RH, data.Ta);
end

%% Create Comparison of conditions of one day, and the day before it.
ind_all = (1:1:length(data.Year)-48)';
ind_d_after = (49:1:length(data.Year))';


%%% Compare PAR
PAR_diff = abs(data.PAR(ind_all)-data.PAR(ind_d_after));
%%% Compare T_air
Ta_diff = abs(data.Ta(ind_all)-data.Ta(ind_d_after));
%%% Compare Ts
Ts_diff = abs(data.Ts5(ind_all)-data.Ts5(ind_d_after));
%%% Compare WS
WS_diff = abs(data.WS(ind_all)-data.WS(ind_d_after));
%%% Compare NEE
NEE_diff = data.NEE(ind_all)-data.NEE(ind_d_after);
%%% Compare SM
SM_diff = abs(data.SM_a(ind_all) - data.SM_a(ind_d_after));
%%% Compare RH
VPD_diff = abs(data.VPD(ind_all) - data.VPD(ind_d_after));
%%% Compare ustar
% ustar_diff = abs(ustar(ind_all) - ustar(ind_d_after));

% For prediction purposes, we'll be considering that the gs is any period
% with Ts >= 0.5, and nongs any period with Ts < 0.5;

%% 1. Relationship for Growing Season: 
ind_goodpair_gs = find( Ta_diff < Ta_tol & Ts_diff < Ts_tol & WS_diff < WS_tol & PAR_diff < PAR_tol & SM_diff < SM_tol ...
                    & data.Ustar(1:length(data.Ustar)-48) > Ustar_th & data.Ts5(1:length(data.Ts5)-48) > 0.5 & data.Ta(1:length(data.Ta)-48) > 2 ...
                    & data.dt(1:length(data.dt)-48) > 85 & data.dt(1:length(data.dt)-48) < 330 & ~isnan(NEE_diff)); %& ~isnan(data.NEE(1:length(data.NEE)-48)) );
                
               
%%% Calculate Error Term
stdev_gs = std(NEE_diff(ind_goodpair_gs));
error_gs = (stdev_gs.*(NEE_diff(ind_goodpair_gs))) ./ sqrt(2) ;
%%% Calculate Beta value
Beta_gs = stdev_gs./sqrt(2);

%%% Create histogram of error to check distribution:
[y_gs xout_gs] = hist(error_gs,100);
figure('Name', 'Error Distribution - Growing Season')
bar(xout_gs,y_gs)

%%% Look at relationship of NEE magnitude to magnitude of error
% figure('Name','error vs NEE - Growing Season')
% clf;
% subplot(2,2,1); plot(data.NEE(ind_goodpair_gs),error_gs,'b.'); title('error vs NEE - Growing Season')
% subplot(2,2,2); plot(data.NEE(ind_goodpair_gs),abs(error_gs),'b.'); title('|error| vs NEE - Growing Season')
% subplot(2,2,3); plot(log(abs(data.NEE(ind_goodpair_gs))),log(abs(error_gs)),'b.'); title('ln|error| vs ln |NEE| - Growing Season')
% subplot(2,2,4); plot(abs(data.NEE(ind_goodpair_gs)),abs(error_gs),'b.'); title('|error| vs  |NEE| - Growing Season')
% 
% figure('Name','error vs env. variables - Growing Season')
% clf;
% subplot(3,2,1); plot(data.WS(ind_goodpair_gs),error_gs,'b.'); title('WS vs. error (in NEE)')
% subplot(3,2,2); plot(data.WS(ind_goodpair_gs),abs(error_gs),'b.'); title('WS vs. |error| (in NEE)')
% 
% subplot(3,2,3); plot(data.Ta(ind_goodpair_gs),error_gs,'b.'); title('T_{air} vs. error (in NEE)')
% subplot(3,2,4); plot(data.Ta(ind_goodpair_gs),abs(error_gs),'b.'); title('T_{air} vs. |error| (in NEE)')
% 
% subplot(3,2,5); plot(data.Ts5(ind_goodpair_gs),error_gs,'b.'); title('Ts vs. error (in NEE)')
% subplot(3,2,6); plot(data.Ts5(ind_goodpair_gs),abs(error_gs),'b.'); title('Ts vs. |error| (in NEE)'); hold on;

% changed error_all_gs to NEE_diff
[Ts_std_gs]= jjb_mov_window_stats(data.Ts5(ind_goodpair_gs),NEE_diff(ind_goodpair_gs), 0.5, 0.5);
[NEE_std_gs]= jjb_mov_window_stats(data.NEE(ind_goodpair_gs),NEE_diff(ind_goodpair_gs), 0.5, 0.5);
[Ta_std_gs]= jjb_mov_window_stats(data.Ta(ind_goodpair_gs),NEE_diff(ind_goodpair_gs), 0.5, 0.5);
[PAR_std_gs]= jjb_mov_window_stats(data.PAR(ind_goodpair_gs),NEE_diff(ind_goodpair_gs), 100, 100);

ind_use_Ts_gs = find(Ts_std_gs(:,5)>50);
ind_use_NEE_gs = find(NEE_std_gs(:,5)>50);
ind_use_Ta_gs = find(Ta_std_gs(:,5)>50);
ind_use_PAR_gs = find(PAR_std_gs(:,5)>50);

figure('Name', 'env variables vs. std dev of error - Growing Season');
subplot(2,2,1); plot(Ts_std_gs(ind_use_Ts_gs,1),Ts_std_gs(ind_use_Ts_gs,4),'b.'); title('Ts vs. std dev (in NEE)')
subplot(2,2,2); plot(NEE_std_gs(ind_use_NEE_gs,1),NEE_std_gs(ind_use_NEE_gs,4),'b.'); title('NEE vs. std dev (in NEE)')
subplot(2,2,3); plot(Ta_std_gs(ind_use_Ta_gs,1),Ta_std_gs(ind_use_Ta_gs,4),'b.'); title('Ta vs. std dev (in NEE)')
subplot(2,2,4); plot(PAR_std_gs(ind_use_PAR_gs,1),PAR_std_gs(ind_use_PAR_gs,4),'b.'); title('PAR vs. std dev (in NEE)')


%% 2. Relationship for Non-Growing Season: 
ind_goodpair_nongs = find( Ta_diff < Ta_tol & Ts_diff < Ts_tol & WS_diff < WS_tol & PAR_diff < PAR_tol & SM_diff < SM_tol ...
                    & data.Ustar(1:length(data.Ustar)-48) > Ustar_th & data.Ts5(1:length(data.Ts5)-48) <= 0.5 ...
                    & (data.dt(1:length(data.dt)-48) < 90 | data.dt(1:length(data.dt)-48) > 330)  & ~isnan(NEE_diff)); %& ~isnan(data.NEE(1:length(data.NEE)-48)) );
                
               
%%% Calculate Error Term
stdev_nongs = std(NEE_diff(ind_goodpair_nongs));
error_nongs = (stdev_nongs.*(NEE_diff(ind_goodpair_nongs))) ./ sqrt(2) ;
%%% Calculate Beta value
Beta_nongs = stdev_nongs./sqrt(2);

%%% Create histogram of error to check distribution:
[y_nongs xout_nongs] = hist(error_nongs,100);
figure('Name', 'Error Distribution - Non-Growing Season')
bar(xout_nongs,y_nongs)

%%% Look at relationship of NEE magnitude to magnitude of error
% figure('Name','error vs NEE - Non-Growing Season')
% clf;
% subplot(2,2,1); plot(data.NEE(ind_goodpair_nongs),error_nongs,'b.'); title('error vs NEE - Growing Season')
% subplot(2,2,2); plot(data.NEE(ind_goodpair_nongs),abs(error_nongs),'b.'); title('|error| vs NEE - Growing Season')
% subplot(2,2,3); plot(log(abs(data.NEE(ind_goodpair_nongs))),log(abs(error_nongs)),'b.'); title('ln|error| vs ln |NEE| - Growing Season')
% subplot(2,2,4); plot(abs(data.NEE(ind_goodpair_nongs)),abs(error_nongs),'b.'); title('|error| vs  |NEE| - Growing Season')
% 
% figure('Name','error vs env. variables - Non-Growing Season')
% clf;
% subplot(3,2,1); plot(data.WS(ind_goodpair_nongs),error_nongs,'b.'); title('WS vs. error (in NEE)')
% subplot(3,2,2); plot(data.WS(ind_goodpair_nongs),abs(error_nongs),'b.'); title('WS vs. |error| (in NEE)')
% 
% subplot(3,2,3); plot(data.Ta(ind_goodpair_nongs),error_nongs,'b.'); title('T_{air} vs. error (in NEE)')
% subplot(3,2,4); plot(data.Ta(ind_goodpair_nongs),abs(error_nongs),'b.'); title('T_{air} vs. |error| (in NEE)')
% 
% subplot(3,2,5); plot(data.Ts5(ind_goodpair_nongs),error_nongs,'b.'); title('Ts vs. error (in NEE)')
% subplot(3,2,6); plot(data.Ts5(ind_goodpair_nongs),abs(error_nongs),'b.'); title('Ts vs. |error| (in NEE)'); hold on;
% [Ts_std_nongs]= jjb_mov_window_stats(data.Ts5(ind_goodpair_nongs),error_nongs, 0.5, 0.5);
% [NEE_std_nongs]= jjb_mov_window_stats(data.NEE(ind_goodpair_nongs),error_nongs, 0.5, 0.5);
% [Ta_std_nongs]= jjb_mov_window_stats(data.Ta(ind_goodpair_nongs),error_nongs, 0.5, 0.5);
[Ts_std_nongs]= jjb_mov_window_stats(data.Ts5(ind_goodpair_nongs),NEE_diff(ind_goodpair_nongs), 0.5, 0.5);
[NEE_std_nongs]= jjb_mov_window_stats(data.NEE(ind_goodpair_nongs),NEE_diff(ind_goodpair_nongs), 0.5, 0.5);
[Ta_std_nongs]= jjb_mov_window_stats(data.Ta(ind_goodpair_nongs),NEE_diff(ind_goodpair_nongs), 0.5, 0.5);
ind_use_Ts_nongs = find(Ts_std_nongs(:,5)>50);
ind_use_NEE_nongs = find(NEE_std_nongs(:,5)>50);
ind_use_Ta_nongs = find(Ta_std_nongs(:,5)>50);
figure('Name', 'env variables vs. std dev of error - Non-Growing Season');
subplot(2,2,1); plot(Ts_std_nongs(ind_use_Ts_nongs,1),Ts_std_nongs(ind_use_Ts_nongs,4),'b.'); title('Ts vs. std dev (in NEE)')
subplot(2,2,2); plot(NEE_std_nongs(ind_use_NEE_nongs,1),NEE_std_nongs(ind_use_NEE_nongs,4),'b.'); title('NEE vs. std dev (in NEE)')
subplot(2,2,3); plot(Ta_std_nongs(ind_use_Ta_nongs,1),Ta_std_nongs(ind_use_Ta_nongs,4),'b.'); title('Ta vs. std dev (in NEE)')

[PAR_std_nongs]= jjb_mov_window_stats(data.PAR(ind_goodpair_nongs),error_nongs, 100, 100);
ind_use_PAR_nongs = find(PAR_std_nongs(:,5)>50);
subplot(2,2,4); plot(PAR_std_nongs(ind_use_PAR_nongs,1),PAR_std_nongs(ind_use_PAR_nongs,4),'b.'); title('PAR vs. std dev (in NEE)')

%% 3. Relationship for All-Season: 
ind_goodpair_all = find( Ta_diff < Ta_tol & Ts_diff < Ts_tol & WS_diff < WS_tol & PAR_diff < PAR_tol & SM_diff < SM_tol ...
                    & data.Ustar(1:length(data.Ustar)-48) > Ustar_th & ~isnan(NEE_diff)); %& ~isnan(data.NEE(1:length(data.NEE)-48)) );                
               
%%% Calculate Error Term
stdev_all = std(NEE_diff(ind_goodpair_all));
error_all = (stdev_all.*(NEE_diff(ind_goodpair_all))) ./ sqrt(2) ;
%%% Calculate Beta value
Beta_all = stdev_all./sqrt(2);

%%% Create histogram of error to check distribution:
[y_all xout_all] = hist(error_all,100);
figure('Name', 'Error Distribution - All Season')
bar(xout_all,y_all)

%%% Look at relationship of NEE magnitude to magnitude of error
% figure('Name','error vs NEE - All Season')
% clf;
% subplot(2,2,1); plot(data.NEE(ind_goodpair_all),error_all,'b.'); title('error vs NEE - Growing Season')
% subplot(2,2,2); plot(data.NEE(ind_goodpair_all),abs(error_all),'b.'); title('|error| vs NEE - Growing Season')
% subplot(2,2,3); plot(log(abs(data.NEE(ind_goodpair_all))),log(abs(error_all)),'b.'); title('ln|error| vs ln |NEE| - Growing Season')
% subplot(2,2,4); plot(abs(data.NEE(ind_goodpair_all)),abs(error_all),'b.'); title('|error| vs  |NEE| - Growing Season')
% 
% figure('Name','error vs env. variables - All Season')
% clf;
% subplot(3,2,1); plot(data.WS(ind_goodpair_all),error_all,'b.'); title('WS vs. error (in NEE)')
% subplot(3,2,2); plot(data.WS(ind_goodpair_all),abs(error_all),'b.'); title('WS vs. |error| (in NEE)')
% 
% subplot(3,2,3); plot(data.Ta(ind_goodpair_all),error_all,'b.'); title('T_{air} vs. error (in NEE)')
% subplot(3,2,4); plot(data.Ta(ind_goodpair_all),abs(error_all),'b.'); title('T_{air} vs. |error| (in NEE)')
% 
% subplot(3,2,5); plot(data.Ts5(ind_goodpair_all),error_all,'b.'); title('Ts vs. error (in NEE)')
% subplot(3,2,6); plot(data.Ts5(ind_goodpair_all),abs(error_all),'b.'); title('Ts vs. |error| (in NEE)'); hold on;
% [Ts_std_all]= jjb_mov_window_stats(data.Ts5(ind_goodpair_all),error_all, 0.5, 0.5);
% [NEE_std_all]= jjb_mov_window_stats(data.NEE(ind_goodpair_all),error_all, 0.5, 0.5);
% [Ta_std_all]= jjb_mov_window_stats(data.Ta(ind_goodpair_all),error_all, 0.5, 0.5);
[Ts_std_all]= jjb_mov_window_stats(data.Ts5(ind_goodpair_all),NEE_diff(ind_goodpair_all), 0.5, 0.5);
[NEE_std_all]= jjb_mov_window_stats(data.NEE(ind_goodpair_all),NEE_diff(ind_goodpair_all), 0.5, 0.5);
[Ta_std_all]= jjb_mov_window_stats(data.Ta(ind_goodpair_all),NEE_diff(ind_goodpair_all), 0.5, 0.5);
ind_use_Ts_all = find(Ts_std_all(:,5)>50);
ind_use_NEE_all = find(NEE_std_all(:,5)>50);
ind_use_Ta_all = find(Ta_std_all(:,5)>50);
figure('Name', 'env variables vs. std dev of error - All Season');
subplot(2,2,1); plot(Ts_std_all(ind_use_Ts_all,1),Ts_std_all(ind_use_Ts_all,4),'b.'); title('Ts vs. std dev (in NEE)')
subplot(2,2,2); plot(NEE_std_all(ind_use_NEE_all,1),NEE_std_all(ind_use_NEE_all,4),'b.'); title('NEE vs. std dev (in NEE)')
subplot(2,2,3); plot(Ta_std_all(ind_use_Ta_all,1),Ta_std_all(ind_use_Ta_all,4),'b.'); title('Ta vs. std dev (in NEE)')
[PAR_std_all]= jjb_mov_window_stats(data.PAR(ind_goodpair_all),error_all, 100, 100);
ind_use_PAR_all = find(PAR_std_all(:,5)>50);
subplot(2,2,4); plot(PAR_std_all(ind_use_PAR_all,1),PAR_std_all(ind_use_PAR_all,4),'b.'); title('PAR vs. std dev (in NEE)')

%% Make relationships for error - do growing season and non-gs seperately
% % 1. Growing season: Estimate linearly by PAR, then scale logistically by
% % Ta
% p_PAR_std_gs = polyfit(PAR_std_gs(ind_use_PAR_gs,1), PAR_std_gs(ind_use_PAR_gs,4),1);
% test = polyval(p_PAR_std_gs,(0:100:2500));
% figure(2);hold on;
% subplot(2,2,4); hold on;
% plot((0:100:2500),test,'r--')
% % fit logistic function through Ta vs std:
% 
% [coeff,y,r2,sigma] = fitmain([10 .3 10], 'fitlogi5', Ta_std_gs(ind_use_Ta_gs,1), Ta_std_gs(ind_use_Ta_gs,4));
% figure(2);hold on;
% subplot(2,2,3);hold on;
% plot(Ta_std_gs(ind_use_Ta_gs,1),y,'r--')

% Above is discarded, in favour of modeling by NEE in gs and non-gs
% % %%%%%%%%%%%%%%%%%%% 1. Growing season:
% % NEE_gs_reg_x = NEE_std_gs(ind_use_NEE_gs,1);
% % NEE_gs_reg_y = NEE_std_gs(ind_use_NEE_gs,4);
% % 
% % ind_gs_min = find(NEE_gs_reg_y == min(NEE_gs_reg_y));
% % 
% % p_lt_min_gs = polyfit(NEE_gs_reg_x(1:ind_gs_min), NEE_gs_reg_y(1:ind_gs_min),1);
% % p_gt_min_gs = polyfit(NEE_gs_reg_x(ind_gs_min:end), NEE_gs_reg_y(ind_gs_min:end),1);
% % 
% % std_pred = NaN.*ones(length(data.NEE),1);
% % % std when NEE is less than point at which it has minimum std (<~1.5)
% % ind_gs_lt = find(data.Ts5 > 0.5 & data.NEE < NEE_gs_reg_x(ind_gs_min));
% % std_pred(ind_gs_lt,1) = polyval(p_lt_min_gs,data.NEE(ind_gs_lt));
% % % std when NEE is greater than point at which it has minimum std (>~1.5)
% % ind_gs_gt = find(data.Ts5 > 0.5 & data.NEE >= NEE_gs_reg_x(ind_gs_min));
% % std_pred(ind_gs_gt,1) = polyval(p_gt_min_gs,data.NEE(ind_gs_gt));
% % 
% % %%%%%%%%%%%%%% 2. Non- Growing Season:
% % % declare x and y variables for regression
% % NEE_nongs_reg_x = NEE_std_nongs(ind_use_NEE_nongs,1);
% % NEE_nongs_reg_y = NEE_std_nongs(ind_use_NEE_nongs,4);
% % 
% % % find NEE value where std is minimum:
% % ind_nongs_min = find(NEE_nongs_reg_y == min(NEE_nongs_reg_y));
% % % linear relationships on both sides of this minimum:
% % p_lt_min_nongs = polyfit(NEE_nongs_reg_x(1:ind_nongs_min), NEE_nongs_reg_y(1:ind_nongs_min),1);
% % p_gt_min_nongs = polyfit(NEE_nongs_reg_x(ind_nongs_min:end), NEE_nongs_reg_y(ind_nongs_min:end),1);
% % 
% % % std when NEE is less than point at which it has minimum std (<~1.5)
% % ind_nongs_lt = find(data.Ts5 <= 0.5 & data.NEE < NEE_nongs_reg_x(ind_nongs_min));
% % std_pred(ind_nongs_lt,1) = polyval(p_lt_min_nongs,data.NEE(ind_nongs_lt));
% % % std when NEE is greater than point at which it has minimum std (>~1.5)
% % ind_nongs_gt = find(data.Ts5 <= 0.5 & data.NEE >= NEE_nongs_reg_x(ind_nongs_min));
% % std_pred(ind_nongs_gt,1) = polyval(p_gt_min_nongs,data.NEE(ind_nongs_gt));

%%%%%%%%%%%%% ATTEMPT 3: std as a function of Ta:
% Shows good adherence to relationship for all seasons, and includes
% seasonal and diurnal influences.
% the logistic function doesn't level out at 0, so we need to find an
% offset and remove that offset:
std_in = Ta_std_all(ind_use_Ta_all,4);
Ta_in = Ta_std_all(ind_use_Ta_all,1);

std_sort = sort(std_in,'ascend');
offset = mean(std_sort(1:4));
std_in = std_in - offset;


[coeff,y,r2,sigma] = fitmain([10 .3 10], 'fitlogi5', Ta_in, std_in);

figure(6);hold on;
subplot(2,2,3);hold on;
plot(Ta_std_all(ind_use_Ta_all,1),y+offset,'r--')

% Now, predict std for all measurements based on Ta (must add offset back into data:
std_pred=( (coeff(1))./(1 + exp(coeff(2).*(coeff(3)-data.Ta))) ) + offset;

figure(99);clf
plot(std_pred);

