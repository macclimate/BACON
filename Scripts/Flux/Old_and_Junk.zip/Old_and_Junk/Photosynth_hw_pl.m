% This program plots the relation between GEP and incident PPFD 
% for 1999 SOBS 
%
% (C) Bill Chen											File created:  Mar. 10, 1998
%																Last modified: Oct. 14, 1999
%
% Revision: 
%				Oct. 14, 1999 by Bill Chen
%           - add 1999 data
%				Feb. 18, 1999 by Bill Chen
%				-  Forcing it pass the origin [0,0] (using hypmain1 and fit_hyp1)
%				Sep. 24, 1998 by Bill Chen
%				- plot 1998 data

% Altaf Arain, March 22, 2000
% - updated for SOBS

% Altaf Arain, April 05, 2001
% - updated for year 2000 
% Updated for 1999-2001, Altaf 13 March 2002
% updated for GRFS, Altaf Arain, Dec 8, 2004
% Modified for TP Met2 OPEC 2005 data. Altaf ad Mathias, May 25, 2006
 
close all; clear all

% ------------- 2005 -------------------------
avg2005 = Photosynth_hw(2005);

x2005 = avg2005(:,1); % PPFD
y2005 = avg2005(:,2); % GEP

ind = find(x2005 < 50);
x2005(ind) = NaN;


ind2005 = find(~isnan(x2005.*y2005));

x2005 = x2005(ind2005); y2005 = y2005(ind2005);


[coeff_hat2005,Y_hat2005,R2_2005,sigma2005] = hypmain1([0.01 10 0.1],'fit_hyp1',x2005, y2005);

X   = [50:20:1900];

Y2005 = coeff_hat2005(1)*coeff_hat2005(2)*X./(coeff_hat2005(1)*X + coeff_hat2005(2));


coeff_hat2005

R2_2005

%slides
figure(2005)
clf
hold on

plot(x2005,y2005,'ko',...
   				'MarkerEdgeColor','k',...
                'MarkerFaceColor','k',...
                'MarkerSize',8);
plot(X,Y2005,'k')


h = legend('Measured','Fitted',4);

set(h,'visible','off')
axis([0 2000 0 18])
%axis([0 700 0 12])
%title('At Turkey Point 2002-03','color','k') 
%xlabel('\itQ_a\rm (\mumol m^-^2 s^-^1)')
%ylabel('\itP\rm (\mumol m^-^2 s^-^1)')
xlabel('PPFD (\mumol m^{-2} s^{-1})','FontSize',18)
ylabel('GEP (\mumol m^{-2} s^{-1})','FontSize',18)
box
hold off
%set(gca,'XColor','y','YColor','y')

print -dmeta C:\data\GRFS\Flux\Photosyth_2005

xy2005 = [X', Y2005'];

save 'C:\data\GRFS\Flux\avg2005photo.txt'   avg2005  -ASCII
save 'C:\data\GRFS\Flux\xy2005photo.txt'    xy2005   -ASCII


