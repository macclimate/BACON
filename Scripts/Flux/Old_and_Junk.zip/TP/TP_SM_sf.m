function [GEP_adj SM_sf] = TP_SM_sf(SM, GEP, tracker, block_avg)
SM_sf(1:length(SM),1) = 1;

if isempty(block_avg)
    block_avg = 'off'
end


SM_test = (0:0.0025:0.15)';
ind_ok = find(~isnan(SM) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50);

%% block average to get idea of where data is going trend-wise:
%%%%%%%%%%%%%%%%%%%%%%
bavg = blockavg(SM(ind_ok),GEP(ind_ok),0.003,60,-20);
ind_ok_bavg = find(~isnan(bavg(:,1).*bavg(:,2)) & bavg(:,4) > 10 & bavg(:,1) > 0);
bavg2 = bavg(ind_ok_bavg,:);
clear bavg; bavg = bavg2; clear bavg2 slope slope_x;
%% Try to find where the curve begins to trend downwards (at end);
if length(bavg) > 40
    incr = 5;
    addt = 2;
elseif length(bavg) > 20 && length(bavg) <=40
    incr = 3;
    addt = 1;
else
    incr = 2;
    addt = 0;
end

for j = 1:1:length(bavg)-incr;
    slope(j,1) = (bavg(j+incr,2) - bavg(j,2))./(bavg(j+incr,1) - bavg(j,1));
end

figure(42); clf;
plot(SM(ind_ok),GEP(ind_ok),'b.');hold on;
plot(bavg(:,1),bavg(:,2),'ro');

slope_x = (1:1:length(slope))';

figure(52);clf
plot(bavg(slope_x,1),slope,'.-');

%% location of curve peak

peak_loc = find(slope_x <(length(bavg)./2) & slope < 0,1,'first') + addt;
if isempty(peak_loc)
    peak_loc = 1;
    curve_type = 'single';
end

%% x and y values at curve peak
peak_x = bavg(peak_loc,1);
peak_y = bavg(peak_loc,2);
%%%%
    ind = find(~isnan(SM) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50 & SM < peak_x);
    x = SM(ind); y = GEP(ind);
    % Normalize y:
    y = y./peak_y;
                %%% Run hyperbolic hyperbola eqn
            [coeff y_pred r2 sigma] = hypmain1([58 1 -200], 'fit_hyp1', x, y);

            figure(10); clf
    plot(x,y,'.'); hold on;
    plot(bavg(1:peak_loc,1),bavg(1:peak_loc,2)./peak_y,'ro')
% plot(x,pR_y,'gx')
    plot(x,y_pred,'r.')

%%% Estimate scaling Factor:
            SM_sf_test = coeff(1).*SM_test.*coeff(2)./(coeff(1).*SM_test + coeff(2));
SM_sf(ind_ok) = coeff(1).*SM(ind_ok).*coeff(2)./(coeff(1).*SM(ind_ok) + coeff(2));
SM_sf(SM_sf > 1,1) = 1; SM_sf(SM_sf < 0,1) = 0; 

figure(72)
plot(SM_sf)

GEP_adj = GEP.*SM_sf;
