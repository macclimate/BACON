%   Turkey Point Raw Data Processing and Previewing Script
%   J. McLaren 
%   Feb 2006
%
clear all
%
load decdoy_00.txt;
dt = decdoy_00(1:17520);
%
k = menu('CHOOSE THE PROCEEDURE','Met file for fluxes','Met 1 Atmo View','Met 1 Soil View','Met 2 View','Met 3 View','Met 4 View','SF/TF View');
%
% Met file for Flux calculation
%
if k == 1
    %
    %
    patha = input('Path of the Met 1 Atmo data file:','s');
    pathb = input('Path of the Met 1 Soil data file:','s');
    sav_loc = input('Path of the folder you want to save to:','s');
    %
    %
    %
    %
    [tv_c,climateData]=fr_read_csi(patha,[],[],31,1);
    [tv_s,soil]=fr_read_csi(pathb,[],[],136);
    
    press = soil(:,16);
    
    % Fill missing Pressure data by linear interpolation
    indx = find(press < 90);
    press(indx) = NaN;
    press = interp_nan(dt,press);
    
    dv = datevec(tv_c);%produces a matrix of dates for climateData file in format [yyyy mm dd hh mm ss]
    d_str = datestr(dv,'ddmmyy');%turns dv into a string in format ddmmyy - June 21 1976 = 210676
    d_num = str2num(d_str);%turns d_str into a number in same format - drops any 0 found at beginning eg. June 1 1976 = 10676
    x = findstr('.',patha);
    %ext = patha(x:end);%create extension from path
    ext = '.dat';
    %
    %
    n = length(climateData);
    start_day = climateData(1,3);%first julian day
    end_day = climateData(n,3);%last julian day
    %
    %
    ind = find(climateData(:,3)==start_day);%find first full start day
    m = length(ind);
    if m < 48
            disp('First day was dropped  - not complete')
            start = start_day + 1;
            ind  = [];
        else
            start = start_day;
    end
    %
    %
    ind = find(climateData(:,3)==end_day);%find last full end day
    m = length(ind);
    if m < 48
            disp('Last day was dropped - not complete')
            finish = end_day - 1;
            ind = [];
        else
            finish = end_day;
    end
    %
    %
    no_days = (finish - start)+1;
    beg = ((start - 1)*48)+1
    fini = finish*48
    hh_tv = [beg:1:fini];% half hour integer time vector for one year is 1:17520
    hh_tv = hh_tv';    
    %
    %
    for a = start:finish%create final files for use in flux calculation
        if a == start%creates index (b) for d_num of current julian day (a)               
            b = 1;                                                                        
        elseif a == finish                                                                 
            b = no_days*48;                                                                
        else                                                                               
            b = (a - start)*48;                                                        
        end                                                                               
        ind = find(climateData(:,3)==a);
        m = length(ind);                                                                
        a_str = num2str(a);                                                                
        mess = strcat('The operation was halted. Day-',a_str,' is missing values. Please gap fill all data and try again.');
        if m < 48                                                                         
            disp(mess)                                                                   
            break                                                                    
        elseif m == 48                                                                 
            disp('working...')                                                               
        end  
        
        num = d_num(b,1);                                                                
        n_s = num2str(num);
        if num < 99999
            str = strcat('0',n_s);
        else 
            str = n_s;
        end

        filename = strcat(sav_loc,'\meteo',str,ext);
        
        h1='Year ';h2='Mnt  ';h3='Day  ';h4='JD   ';h5='HH   ';h6='MM   ';h7='SS   ';h8='Time ';h9='airTc';h10='press';
        
        fid = fopen(filename,'w');
        
        fprintf(fid,'%s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t %s\t\r',h1,h2,h3,h4,h5,h6,h7,h8,h9,h10);
        
        fclose(fid);
        
        inds = find(soil(:,3)==a);
        
        halfh = [dv(ind,1) dv(ind,2) dv(ind,3) climateData(ind,3) dv(ind,4) dv(ind,5) dv(ind,6) hh_tv(ind) climateData(ind,6) press(inds)]; 
        
        for i= 1:48
            
            fid = fopen(filename,'a+');
        
            fprintf(fid,'%6.1f\t %6.1f\t %6.1f\t %6.1f\t %6.1f\t %6.1f\t %6.1f\t %6.1f\t %6.3f\t %6.3f\t\r',halfh(i,:));
        
            fclose(fid);
        
        end
               
    end
    %
    %       PART 1 - Meteorological Plots
    %
elseif k == 2
    
    path = input('Enter the path of the Met 1 Atmo dat file here:  ','s');
    %
    [tv_c2,climateData]=fr_read_csi(path,[],[],31,1);
    [tv_day,daily_batt]=fr_read_csi(path,[],[],24);
    [tv_ts,tree_snow]=fr_read_csi(path,[],[],22);

    %
    %   
    figure(1);
    hold on
    plot(tv_c2,climateData(:,3));
    datetick('x');
    ylabel('Julian Day');
    title('DOY - Look for missing days')
    %
    %
    figure(2);
    hold on
    plot(tv_c2,climateData(:,5),'r');
    plot(tv_c2,climateData(:,6),'g');
    plot(tv_c2,climateData(:,7),'b');
    datetick('x');
    ylabel('Ta');
    title('Avg. Air Temps - r = ground - g = top - b = canopy')
    %
    %
    figure(3);
    hold on
    plot(tv_c2,climateData(:,8),'r');
    plot(tv_c2,climateData(:,9),'g');
    plot(tv_c2,climateData(:,10),'b');
    datetick('x');
    ylabel('RH');
    title('Relative Humidity - r = ground - g = top - b = canopy')
    %
    %
    figure(4);
    hold on
    plot(tv_c2,climateData(:,11));
    datetick('x');
    ylabel('WS');
    title('Wind Speed - Prop. Anemometer')
    %
    %
    figure(5);
    hold on
    hist(climateData(:,12));
    ylabel('Count');
    xlabel('Direction - 0 N - 90 E - 180 S - 270 W')
    title('Wind Direction - Should usually be from southwest ~200)')
    %
    %
    figure(6);
    hold on
    plot(tv_c2,climateData(:,13),'r');
    plot(tv_c2,climateData(:,14),'b');
    datetick('x');
    ylabel('PAR');
    title('PAR - r = UP - b = DOWN')
    %
    %
    rain=climateData(:,15);
    [time,avg,ppt,max,min,std,n]=dailystats_number(tv_c2,rain,500,-9999,1);
    %
    %
    figure(7);
    hold on
    bar(ppt);
    xlabel('Day #');
    ylabel('Rain');
    title ('Daily Rainfall totals in mm')
    %
    %
    figure(8);
    plot(tv_c2,climateData(:,16));
    datetick('x');
    ylabel('NR');
    title('Net Radiation')
    %
    %
    figure(9);
    plot(tv_c2,climateData(:,17));
    datetick('x');
    ylabel('T');
    title('Atmospheric Data Logger Temp')
    %
    %
    %       PART 2 - System Check
    %
    %
    figure(10);
    plot(daily_batt(:,5));
    ylabel('Voltage - Daily Minimum');
    title('Battery Check')
    %
    %
    figure(11);
    plot(daily_batt(:,6));
    title('Program Signal Check')
    %
    %
    %       PART 3 - Tree and Snow Temps
    %
    %
    figure(12);
    hold on
    plot(tv_ts,tree_snow(:,5),'y');
    plot(tv_ts,tree_snow(:,6),'m');
    plot(tv_ts,tree_snow(:,7),'c');
    plot(tv_ts,tree_snow(:,8),'r');
    plot(tv_ts,tree_snow(:,9),'g');
    plot(tv_ts,tree_snow(:,10),'b');
    plot(tv_ts,tree_snow(:,11),'k');
    datetick('x');
    title('Trees 1-7')
    %
    %
    figure(13);
    hold on
    plot(tv_ts,tree_snow(:,12),'y');
    plot(tv_ts,tree_snow(:,13),'m');
    plot(tv_ts,tree_snow(:,14),'c');
    plot(tv_ts,tree_snow(:,15),'r');
    plot(tv_ts,tree_snow(:,16),'g');
    plot(tv_ts,tree_snow(:,17),'b');
    plot(tv_ts,tree_snow(:,18),'k');
    datetick('x');
    title('Trees 8-14')
    %
    %
    figure(14);
    hold on
    plot(tv_ts,tree_snow(:,19),'y');
    plot(tv_ts,tree_snow(:,20),'m');
    plot(tv_ts,tree_snow(:,21),'c');
    plot(tv_ts,tree_snow(:,22),'r');
    plot(tv_ts,tree_snow(:,23),'g');
    plot(tv_ts,tree_snow(:,24),'b');
    plot(tv_ts,tree_snow(:,25),'k');
    datetick('x');
    title('Trees 15-21')
    %
    %
    figure(15);
    hold on
    plot(tv_ts,tree_snow(:,26),'y');
    datetick('x');
    title('Tree 22')
    %
    %
    figure(16);
    hold on
    plot(tv_ts,tree_snow(:,27),'y');
    plot(tv_ts,tree_snow(:,28),'c');
    plot(tv_ts,tree_snow(:,29),'r');
    plot(tv_ts,tree_snow(:,30),'g');
    plot(tv_ts,tree_snow(:,31),'b');
    plot(tv_ts,tree_snow(:,32),'k');
    plot(tv_ts,tree_snow(:,33),'m');
    datetick('x');
    title('Snow Temp 1-7')
    %
    %
    figure(17);
    hold on
    plot(tv_ts,tree_snow(:,34),'b');
    plot(tv_ts,tree_snow(:,35),'k');
    plot(tv_ts,tree_snow(:,36),'r');
    datetick('x');
    title('Snow Temp 8-10')
    %
    %
   
elseif k == 3
    disp('Met 1 soil data viewer coming soon to a PC near you!!!!!')
elseif k == 4
    disp('Met 2 data viewer coming soon to a PC near you!!!!!')
elseif k == 5
    disp('Met 3 data viewer coming soon to a PC near you!!!!!')
elseif k == 6
    disp('Met 4 data viewer coming soon to a PC near you!!!!!')
else k == 7
    disp('Sapflow/Throughfall data viewer coming soon to a PC near you!!!!!')
end


