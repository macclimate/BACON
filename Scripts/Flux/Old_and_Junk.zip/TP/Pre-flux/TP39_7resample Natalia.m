%it generates the meteo files required for running the CP flux calculation
%program... and it is call resample. good for formats and that kind of
%stuff
%Natalia Restrepo
load data2005m1ALL.dat;
A=data2005m1ALL;
B=(A(:,2:26));B(:,2:24)=[];
[nM1,mM1]= size(B);

%date vector
DTm1o=datenum(2005,1,1,0,0,0); DTm1f=datenum(2005,5,31,23,30,0);
halfhour =datenum(0,0,0,0,30,0); day=datenum(0,0,1,0,0,0);
DTm1=(DTm1o:halfhour:DTm1f); DTm1=DTm1';
[Ym1,Mm1,Dm1,HRm1,MMm1,SSm1]=datevec(DTm1);

DTm1day=(DTm1o:day:DTm1f); DTm1day=DTm1day';
[Ym1day,Mm1day,Dm1day,HRm1day,MMm1day,SSm1day]=datevec(DTm1day);
Ym1day=Ym1day-2000;
% Ym1day =  num2str(Ym1day); Mm1day =  num2str(Mm1day); Dm1day =  num2str(Dm1day);
[nM1day,mM1day]= size(DTm1day);

data2004m1=zeros(48,10);

i=0; for i=0:nM1day-1;
    j=1; for j=1:48;
        k=(i*48)+j;
        data2004m1(j,1) = Ym1(k,1); data2004m1(j,2) = Mm1(k,1);
        data2004m1(j,3) = Dm1(k,1); data2004m1(j,4) = Dm1(k,1); 
        data2004m1(j,5) = HRm1(j,1);
        data2004m1(j,6) = MMm1(j,1);
        data2004m1(j,7) = SSm1(j,1); data2004m1(j,8) = HRm1(j,1);
        data2004m1(j,9) = B(k,1); data2004m1(j,10) = B(k,2);
    end;
    Ym1st=num2str(Ym1day(i+1),'%02i'); 
    Mm1st=num2str(Mm1day(i+1),'%02i'); 
    Dm1st=num2str(Dm1day(i+1),'%02i'); 
    FileNameTime = [Dm1st Mm1st Ym1st];
    FileName = ['c:\met-data\data\meteo' FileNameTime '.dat']
    fid = fopen(FileName,'w');
    header='year	month	day	JD	HH	MM	SS	time	airTCtop	Presure'
    fprintf(fid,'%s\n',header);
    fclose(fid);
    fid = fopen(FileName,'a');
    fprintf(fid,'%4i\t%02i\t%02i\t%02i\t%02i\t%02i\t%1i\t%02i\t%6.3f\t%6.3f\n', data2004m1');
    fclose(fid);
end;