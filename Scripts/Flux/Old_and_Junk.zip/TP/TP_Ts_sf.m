function [GEP_adj Ts_sf] = TP_Ts_sf(Ts, GEP, tracker, block_avg)
Ts_sf(1:length(Ts),1) = NaN;
if isempty(block_avg)
    block_avg = 'on'
end

Ts_test = (-5:1:35)';
ind_ok = find(~isnan(Ts) & ~isnan(GEP) & tracker == 1);

%% block average to get idea of where data is going trend-wise:
%%%%%%%%%%%%%%%%%%%%%%
bavg = blockavg(Ts(ind_ok),GEP(ind_ok),0.5,60,-20);
ind_ok_bavg = find(~isnan(bavg(:,1).*bavg(:,2)) & bavg(:,4) > 4);
bavg2 = bavg(ind_ok_bavg,:);
clear bavg; bavg = bavg2; clear bavg2;

%% Moving average:
mov_avg = jjb_mov_avg(bavg(:,2),7, 'on','off');
% mov_avg = mov_avg./peak_y;

figure(7); clf
plot(bavg(:,1),bavg(:,2),'rx-'); hold on;
plot(bavg(:,1),mov_avg,'go')

%% Try to find where the curve begins to trend downwards (at end);
if length(bavg) > 40
    incr = 5;
elseif length(bavg) > 20 && length(bavg) <=40
    incr = 3;
else
    incr = 2;
end

for j = 1:1:length(bavg)-incr;
    slope(j,1) = (mov_avg(j+incr) - mov_avg(j))./(bavg(j+incr,1) - bavg(j,1));
end

slope_x = (1:1:length(slope))';



%% location of curve peak

peak_loc = find(slope_x >(length(bavg)./2) & slope < 0,1,'first') + floor(incr./2);
if isempty(peak_loc)
    peak_loc = length(bavg);
end

%% x and y values at curve peak
peak_x = bavg(peak_loc,1);
peak_y = mov_avg(peak_loc,1);
%%%%



switch block_avg
    case 'on'
        x = [bavg(1:peak_loc,1); peak_x.*ones(5,1)] ; 
        y = [mov_avg(1:peak_loc,1) peak_y.*ones(5,1)];
        %%% Normalize values (to make factor from 0 to 1)
        y = y./ peak_y;
    case 'off'
        x = Ts(ind_ok); y = GEP(ind_ok);
        %%% Normalize values (to make factor from 0 to 1)
        peak_y = mov_avg(peak_loc,1); %max(bavg(ind_ok_bavg,2));
        y = y./peak_y;
end
%%%%%%%%%%%%%%%%%%%%%%%%

%% Fit these data with the logistic model:
[b,y_pred,stats,sigma] = fitmain([1 1 1], 'fitlogi5', x, y);

% pred = (b(1).*peak_y)./(1+exp(b(2).*(b(3)-x)));

pred_norm = b(1)./(1+exp(b(2).*(b(3)-Ts_test)));

%%% Move the Curve Down to reach 0 at 0
% bot_shift = pred_norm(Ts_test == 0);
% % sl = polyfit([-1 0 1],[pred_norm(find(Ts_test==0)-1) pred_norm(Ts_test==0) pred_norm(find(Ts_test==0)+1)],1);
% % back_shift_x = round(-sl(2)./sl(1));
% % back_shift = find(min(bot_shift - pred_norm));
% %%% Adjust
% pred_norm = pred_norm - bot_shift;
% % Ts_test = Ts_test + back_shift_x;
% %%% Expand the Curve so that it peaks at 1 at the peak_x location
% top_scale = pred_norm(Ts_test == ceil(peak_x));
% %%% Adjust
% pred_norm = pred_norm./top_scale;
pred_norm(pred_norm < 0) = 0; pred_norm(pred_norm>1) = 1;


figure(32); clf;
plot(x,y, 'b.'); hold on;
plot(bavg(:,1), bavg(:,2)./peak_y, 'ro','MarkerFaceColor','r');
plot(Ts_test, pred_norm, 'kx-', 'LineWidth',2);
% plot(bavg(:,1),mov_avg,'go-')

Ts_sf = b(1)./(1+exp(b(2).*(b(3)-Ts)));
% Ts_sf = Ts_sf - bot_shift;
% Ts_sf = Ts_sf./top_scale;
Ts_sf(Ts_sf < 0 | Ts < 0) = 0; Ts_sf(Ts_sf > 1 | Ts > peak_x) = 1;

figure(42);clf
plot(Ts_sf)

GEP_adj = GEP./Ts_sf;