if exist('T_air1') == 0;
clear all
end

close all
site = '1';
gsstart = 90;
gsend = 330;
st_yr = 2003; end_yr = 2007;
ustar_th = 0.25;
%%% For Plotting
colorlist = ['b';'r';'g';'m';'c'];
yrlist = ['2003';'2004';'2005';'2006';'2007'];
%%
if ispc == 1
    path = ['C:\HOME\MATLAB\Data\Data_Analysis\M' site '_allyears\'];
else
    path = ['/home/jayb/MATLAB/Data/Data_Analysis/M' site '_allyears/'];
end
%% Load Met and CO2 Flux variables for 2003-2007
if exist('T_air1') == 0; %% these variables will not load if already loaded (time saver)
all_vars = load([path 'M' site '_all_yrs_data.dat']);

T_air1 = all_vars(:,1);
PAR1 = all_vars(:,2);
Ts1_2 = all_vars(:,3);
SM1 = all_vars(:,4);
NEE1 = all_vars(:,5); %NEE1(NEE1 > 35 | NEE1 < -35) = NaN;
ustar1 = all_vars(:,6);
dt1 = all_vars(:,7);
year1 = all_vars(:,8);
WS1 = all_vars(:,9);
Wdir1 = all_vars(:,10);
VPD1 = all_vars(:,11);
Ts1_5 = all_vars(:,12);
clear all_vars;

%% For the time being.... use 5cm soil temp as the main one:
Ts1 = Ts1_5;
clear Ts1_5;

end
%% Load EB Variables
all_vars2 = load([path 'M' site '_EB_data.dat']);

Hs1 = all_vars2(:,1);
LE1 = all_vars2(:,2);
Jt1 = all_vars2(:,3); 
G01 = all_vars2(:,4);
Rn1 = all_vars2(:,5);

clear all_vars2
%% Clean LE and Hs
%%% Visually set thresholds:
LE1(LE1 > 600 | LE1 < -50) = NaN; %% is -50 too high? removing real data?
LE1(dt1 < 120 & LE1 > 400) = NaN;
LE1(dt1 < 100 & LE1 > 150) = NaN;
LE1(dt1 > 310 & LE1 > 200) = NaN;
%%% Removing obvious bad data:
LE1(71100:71220,1) = NaN;
LE1(87040:87110,1) = NaN;

%%% Visually set thresholds:
Hs1(Hs1 > 800 | Hs1 < -200) = NaN;
Hs1(dt1 > 300 & Hs1 > 500) = NaN; 
%%% Removing obvious bad data:
Hs1(64636,1) = NaN;

Hs_raw = Hs1;
LE_raw = LE1;

Hs_filled = Hs1;
LE_filled = LE1;

%% Fill Gaps in H 
x_var1 = Rn1-G01+Jt1; %%% Jt is backwards in sign -- -'ve during day, +'ve at night

%%% Model Hs based on incoming energy for 5-day average window
[Hs1_fill, Hs1_model_5]= jjb_WLR_gapfill(x_var1, Hs1, 240,'on'); 
%%% Fill all possible gaps:
Hs_filled(isnan(Hs_filled)) = Hs1_model_5(isnan(Hs_filled));

%%% Model Hs based on incoming energy for 10-day average window
[Hs1_fill, Hs1_model_10] = jjb_WLR_gapfill(x_var1, Hs1, 480,'on'); 
%%% Fill all possible gaps:
Hs_filled(isnan(Hs_filled)) = Hs1_model_10(isnan(Hs_filled));

%%% Model Hs based on incoming energy for 15-day average window
[Hs1_fill, Hs1_model_15]= jjb_WLR_gapfill(x_var1, Hs1, 720,'on'); 
%%% Fill all possible gaps:
Hs_filled(isnan(Hs_filled)) = Hs1_model_15(isnan(Hs_filled));

%%% Model Hs based on incoming energy for 20-day average window
[Hs1_fill, Hs1_model_20]= jjb_WLR_gapfill(x_var1, Hs1, 960,'on'); 
%%% Fill all possible gaps:
Hs_filled(isnan(Hs_filled)) = Hs1_model_20(isnan(Hs_filled));


%% Fill LE Gaps
%%% Step 1 - make LE gaps 0 if at night
LE_filled(isnan(LE_filled) & PAR1 <= 10) = 0;

%%% Step 2 - Growing-season daytime LE filling method
%%% Use a moving window approach; the same method as Hs
[LE_fill1 LE1_model_5] = jjb_WLR_gapfill(x_var1, LE1, 240,'on'); 
%%% Fill gaps:
LE_filled(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend) = LE1_model_5(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend);

%%% 10-day window
[LE_fill2 LE1_model_10] = jjb_WLR_gapfill(x_var1, LE1, 480,'on'); 
%%% Fill gaps:
LE_filled(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend) = LE1_model_10(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend);

%%% 15-day window
[LE_fill3 LE1_model_15] = jjb_WLR_gapfill(x_var1, LE1, 720,'on'); 
%%% Fill gaps:
LE_filled(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend) = LE1_model_15(isnan(LE_filled) & PAR1 > 10 & dt1 > gsstart & dt1 < gsend);


%%% Step 3 - Non Growing Season daytime LE filling method
%%% Use average 1/2hr value for period five days before to five days after.
LE_fill_MDV = jjb_MDV_gapfill(LE1, 10, 48);

LE_filled(isnan(LE_filled) & PAR1 > 10 & (dt1 < gsstart | dt1 > gsend)) = LE_fill_MDV(isnan(LE_filled) & PAR1 > 10 & (dt1 < gsstart | dt1 > gsend));

%%% Fill in any remaining gaps with MDV
LE_filled(isnan(LE_filled)) = LE_fill_MDV(isnan(LE_filled));
%% Calculate Annual Evapotranspiration
%%% Convert LE in W/m^2 to mm/hhour 
%%% by using either (LE/lambda(T_air).*1800) --- What is Lambda?????
%%% or LE/343
LE_mm = (LE_filled./lambda(T_air1)).*1800;
LE_mm(isnan(LE_mm),1) = LE_filled(isnan(LE_mm))./1372;
  ctr = 1;
for jj = st_yr:1:end_yr
ET(ctr).cumsum = nancumsum(LE_filled(year1==jj)./1372);
ET(ctr).sum = ET(ctr).cumsum(end);
ctr = ctr +1;
output = [LE_filled(year1==jj) Hs_filled(year1==jj)];
save([path 'M' site '_ETEB_output_' num2str(jj) '.dat'],'output', '-ASCII')
end

%% Visual Inspection of LE- NEED TO BETTER CLEAN LE BEFORE FILLING (use dt)
figure(3); clf;
subplot(2,1,1)
plot(LE_filled,'b')
hold on;
plot(LE1,'g')
plot(dt1,'k')
title('LE')
ylabel('LE - W m^{-2} s^{-1}')
legend('LE - filled', 'LE - raw', 'dt')

subplot(2,1,2)
plot(Hs_filled,'b')
hold on;
plot(Hs1,'g')
plot(dt1,'k')
title('H')
ylabel('H - W m^{-2} s^{-1}')
legend('H - filled', 'H - raw', 'dt')

figure(4); clf
  ctr = 1;
for jj = st_yr:1:end_yr
plot(dt1(year1 == jj),ET(ctr).cumsum,'Color',colorlist(ctr)); hold on;
ctr = ctr +1;
end
legend(yrlist)
ylabel('Cumulative ET -- mm')

%% Energy Balance:

e_in = x_var1;
e_out = Hs1 + LE1;

figure(5);clf;
plot(e_in,e_out,'k.'); hold on
plot((-200:50:800),(-200:50:800),'b--', 'LineWidth',4)
axis([-200 900 -200 900])



%%% Select good data:
good_data = find(~isnan(e_in) & ~isnan(e_out));
p_x_all = polyfit(e_in(good_data), e_out(good_data),1);

eb_line(:,1) = polyval(p_x_all,(-200:50:800));

figure(5)
plot((-200:50:800),eb_line,'r-', 'LineWidth',4)
title('Energy Budget -- 2003-2007','FontSize', 16)
xlabel ('Available Energy -- (QE - QG - \DeltaQ)','FontSize', 16) %xlabel('Rn-G-Jt');
ylabel('Turbulent Energy -- (QE + QH)','FontSize', 16);
set(gca, 'FontSize',16)
legend('1/2 hour EB','1:1 Line','Actual')
print('C:\HOME\MATLAB\Figs\EB\TP39_EB','-dmeta')


%% Examine Energy balance on different timescales:
%%% at 10 days (i.e. 480 data points)
win_size = 480;

num_loops = floor(length(e_out)/win_size);
%%% Span is half the window size -- number of datapoints to consider on
%%% each side of the middlepoint of the window
span = win_size/2;
%%% Specify the rows in the data that will be the mid-points of the data
loop_int = (span:win_size:length(e_out))';
loop_int(1,1) = span+1;  %% Add one to avoid sampling 0th point at start

%%% If the window size does not fit perfectly into the vector, adjust the
%%% size of the last window to accomodate
if rem(length(e_out),win_size) ~= 0 %span
    num_loops = num_loops +1;
    loop_int(num_loops,1) = length(e_out)-span;
end

p_x(1:length(loop_int),1:2) = NaN;
for ctr = 1:1:length(loop_int)
  %%% proper rows to be considered inside window
  y_rows(:,1) = (loop_int(ctr) - span : loop_int(ctr) + span); 
    
  ok_data = find(~isnan(e_in(y_rows)) & ~isnan(e_out(y_rows)));
  
  p_x(ctr,1:2) = polyfit(e_in(y_rows(ok_data),1),e_out(y_rows(ok_data),1),1);
  
  Hs_10d(ctr,1) = nanmean(Hs1(y_rows,1));
  dt_10d(ctr,1) = nanmean(dt1(y_rows,1));
  
  clear y_rows ok_data
end

figure(6); clf
plot(p_x(:,1))
hold on
plot(Hs_10d./max(Hs_10d),'g')
plot(dt_10d./366,'k')
grid on
title('10-day average energy budget closure')
ylabel('EB closure')
legend('EB Closure','H Flux','DOY')
% set(gca,'XTick',dt_10d)

%% Yearly EB:
ctr2 = 1;
p_x_yr(1:5,1:2) = NaN;
figure(7); clf;
for jj = st_yr:1:end_yr
   ind_yr = find(year1 == jj);
   e_in_yr = e_in(ind_yr);
   e_out_yr = e_out(ind_yr);
   ok_data = find(~isnan(e_in_yr) & ~isnan(e_out_yr));
   p_x_yr(ctr2,1:2) = polyfit(e_in_yr(ok_data,1), e_out_yr(ok_data,1),1);
   
   
    clear ok_data e_in_yr e_out_yr ind_yr;
   figure(7)
   subplot(2,1,1)
   plot(jj,p_x_yr(ctr2,1),'o','Color',colorlist(ctr2)); hold on;
    
   ctr2 = ctr2+1;
end

figure(7)
legend(yrlist);
subplot(2,1,1);
title('EB closure by year')



%% Seasonal EB:
% A. Spring:
ind_spr = find(dt1 >= 60 & dt1 < 152 & ~isnan(e_in) & ~isnan(e_out));
p_spr = polyfit(e_in(ind_spr),e_out(ind_spr),1);
% B. Summer:
ind_sum = find(dt1 >= 152 & dt1 < 244 & ~isnan(e_in) & ~isnan(e_out));
p_sum = polyfit(e_in(ind_sum),e_out(ind_sum),1);
% C. Autumn
ind_aut = find(dt1 >= 244 & dt1 < 335 & ~isnan(e_in) & ~isnan(e_out));
p_aut = polyfit(e_in(ind_aut),e_out(ind_aut),1);
% D. Winter
ind_win = find((dt1 >= 335 | dt1 < 60) & ~isnan(e_in) & ~isnan(e_out));
p_win = polyfit(e_in(ind_win),e_out(ind_win),1);

figure(7)
subplot(2,1,2)
plot([1 2 3 4]',[p_spr(1,1) p_sum(1,1) p_aut(1,1) p_win(1,1)]','ro')
set(gca,'XTick',[1;2;3;4])
set(gca,'XTickLabel',['Spring'; 'Summer'; 'Autumn'; 'Winter'])
title('EB closure by season')
ylabel('EB Closure')

% Full time series of filled data:
figure(9); clf
plot(Rn1,'r')
hold on;
plot(Hs_filled,'b')
plot(LE_filled,'g')
plot(G01,'y')
plot(Jt1,'k')

% Yearly Diurnal Average:
yr_starts = 1:17568:87000;
yr_ends = [17520;35136; 52704-48; 70272-48; 87840-48];

for i = 2003:1:2007
    yr_ctr = i - 2002;
    Rn_yr = reshape(Rn1(yr_starts(yr_ctr):yr_ends(yr_ctr)),48,[]);
    Rn_yr_avg(yr_ctr,:) = row_nanmean(Rn_yr);
    Hs_yr = reshape(Hs_filled(yr_starts(yr_ctr):yr_ends(yr_ctr)),48,[]);
    Hs_yr_avg(yr_ctr,:) = row_nanmean(Hs_yr);    
    LE_yr = reshape(LE_filled(yr_starts(yr_ctr):yr_ends(yr_ctr)),48,[]);
    LE_yr_avg(yr_ctr,:) = row_nanmean(LE_yr);    
    G_yr = reshape(G01(yr_starts(yr_ctr):yr_ends(yr_ctr)),48,[]);
    G_yr_avg(yr_ctr,:) = row_nanmean(G_yr);  
    Jt_yr = reshape(Jt1(yr_starts(yr_ctr):yr_ends(yr_ctr))*-1,48,[]);
    Jt_yr_avg(yr_ctr,:) = row_nanmean(Jt_yr);      
    
    
    clear Rn_yr Hs_yr LE_yr G_yr Jt_yr
end
    
for i = 2003:1:2007
    yr_ctr = i - 2002;


figure(9+yr_ctr); clf
plot(Rn_yr_avg(yr_ctr,:),'k','LineWidth',4);
hold on;
plot(Hs_yr_avg(yr_ctr,:),'r','LineWidth',4)
plot(LE_yr_avg(yr_ctr,:),'b','LineWidth',4)
plot(G_yr_avg(yr_ctr,:),'g','LineWidth',4)
plot(Jt_yr_avg(yr_ctr,:),'m','LineWidth',4)
axis([1 48 -80 500]);
xunits = (1:48)'./2;
Xticks = (6:6:48)';
Xlabels = ['03:00'; '06:00'; '09:00'; '12:00'; '15:00'; '18:00'; '21:00';'24:00'];
set(gca,'XTick',Xticks)
set(gca,'XTicklabel',Xlabels)
set(gca,'FontSize',14)
ylabel('Energy  (W m^{-2})', 'FontSize', 16)
xlabel('Hour (Local Time)', 'FontSize', 16)
grid on
legend('Qs*', 'QH', 'QE', 'QG', '\DeltaQ');
print(['C:\HOME\MATLAB\Figs\EB\TP39_' num2str(i) '_ensemble'],'-dmeta')

figure(14+yr_ctr); clf
Res(yr_ctr,:) = (Rn_yr_avg(yr_ctr,:)-G_yr_avg(yr_ctr,:)+Jt_yr_avg(yr_ctr,:))-(Hs_yr_avg(yr_ctr,:)+LE_yr_avg(yr_ctr,:));
plot(Rn_yr_avg(yr_ctr,:)-G_yr_avg(yr_ctr,:)+Jt_yr_avg(yr_ctr,:),'k','LineWidth',4);
hold on;
plot(Hs_yr_avg(yr_ctr,:)+LE_yr_avg(yr_ctr,:),'r','LineWidth',4)
plot(Res(yr_ctr,:),'b--','LineWidth',2)
axis([1 48 -80 500]);
xunits = (1:48)'./2;
Xticks = (6:6:48)';
Xlabels = ['03:00'; '06:00'; '09:00'; '12:00'; '15:00'; '18:00'; '21:00';'24:00'];
set(gca,'XTick',Xticks)
set(gca,'XTicklabel',Xlabels)
set(gca,'FontSize',14)
ylabel('Energy  (W m^{-2})', 'FontSize', 16)
xlabel('Hour (Local Time)', 'FontSize', 16)
grid on
legend('Qs*-QG-\DeltaQ', 'QH+QE', 'Residual');
print(['C:\HOME\MATLAB\Figs\EB\TP39_' num2str(i) '_ensemble_bal'],'-dmeta')
end







