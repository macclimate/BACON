%% OPEC_run.m
%% This file runs all necessary files in sequence to calculate fluxes
% year = '2005'; %% adjust these accordingly
% site = '4';
clear all
close all

% year_list = (2003:1:2007);
year_list = (2007);
site_list = 1%(2:1:4);
% year_list = (2003:1:2006);

% % site_list = (4);

flux_source = 'processed';
met_source = 'processed';
%  flux_source = 'master';
%   met_source = 'master';

for i = 1:length(site_list)
site = num2str(site_list(i));

%     if site == '1'
%         flux_source = 'master';
%         met_source = 'master';
%     else  
%         flux_source = 'master';
%         met_source = 'master';
%         
%     end

    for j = 1:length(year_list)
        year = num2str(year_list(j));
        close all
        disp(['site = ' num2str(site_list(i))]); 
        disp(['year = ' num2str(year_list(j))]); 
     
        
% metSHFlux(year, site, flux_source, met_source)
% close all
% OPEC_storage(year, site, flux_source, met_source)
% close all
OPEC_Resp(year, site, flux_source, met_source)
close all
% OPEC_Photosynth(year, site, flux_source, met_source)
% close all
% OPEC_Fluxes(year, site, flux_source, met_source)
% close all

end
end
  
        
        
       

%         
% 
        
% 
%         
% 
