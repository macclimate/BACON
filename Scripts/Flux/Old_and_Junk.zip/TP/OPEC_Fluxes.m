function [] = OPEC_Fluxes(year,site,flux_source, met_source)

%% OPEC_Fluxes.m
%%%% Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option
%%%
%%%
%%%
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% flux_filled_path = (['C:\Home\Matlab\Data\Flux\OPEC\Filled4\Met' site '\Met' site '_' year '_']);

%%% Output path
flux_calc_path = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated5\Met' site '\Met' site '_' year '_']);

%%% Calculated met files
met_calc_path = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);

%%% Path for logs & figs
log_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Logs\Met' site '\Met' site '_' year '_FluxLog.txt']);
fig_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Figs\Met' site '\Met' site '_' year '_']);

%% Load Variables
%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);

vars = jjb_flux_load('Fluxes', year, site, flux_source, met_source);

T_air = vars(:,1);
PAR = vars(:,2);
WS = vars(:,3);
Rn = vars(:,4);
% SM5a = vars(:,5);
% SM5b = vars(:,6);
% SM10a = vars(:,7);
% SM10b = vars(:,8);
% SM20a = vars(:,9);
% SM20b = vars(:,10);
ustar = vars(:,11);
Hs_orig = vars(:,12);
LE_orig = vars(:,13);

clear vars;

%%% Respiration Coefficients
R_coeff = load([flux_calc_path 'NEE_Ts_cx.dat']);
%%% Photosynthesis Coefficients
P_coeff = load([flux_calc_path 'GEP_PAR_cx.dat']);

%%% Sensible Heat Storage (Jt)
Jt = load([flux_calc_path 'Jt.dat']);

%%% NEE (calculated in OPEC_Resp.m)
NEE_raw = load([flux_calc_path 'NEE_raw.dat']);
NEP_raw = -1.*NEE_raw;  %% possibly not needed
NEE = NEE_raw; %% tracking variable

%%% Soil Heat Flux
G0 = load([met_calc_path 'g0.dat']);

% %%% Soil temperature
Ts = load ([met_calc_path 'Ts.dat']);

%%% Air Pressure
% Pres = load([clean_path 'pres_cl.dat']);

%% Load Parameters
param = params(year, site, 'Fluxes');
gsstart = param(:,1); gsend = param(:,2); GEPcutstart = param(:,3);
GEPcutend = param(:,4); corr_1 = param(:,5); corr_2 = param(:,6);
ustar_crit = param(:,7);


%% High - Wind Method for modelling Respiration and Photosynthesis
%%%Create Logistic function for Respiration (w.r.t. Ts)
R_log = R_coeff(1)./(1+exp(R_coeff(2)*(R_coeff(3)-Ts)));
%%% Create Logistic function for Photosynthesis (w.r.t. PAR)
P_log = P_coeff(1).*PAR.*P_coeff(2)./(P_coeff(1).*PAR+P_coeff(2));

%% REDUCE Photosynthesis model outside of the growing season
%%% Use third order equation / filter / hyperbolic, logarithmic?

%% Fill modeled data into real data during necessary periods -- STEP 1

%%% Replace for night when NEE is missing or ustar is less than the
%%% critical value
% ind_bad_night = find(PAR <= 10 & (isnan(NEE) | ustar < ustar_crit));
% NEE(ind_bad_night,1) = R_log(ind_bad_night);
NEE(PAR <= 10 & (isnan(NEE) | ustar < ustar_crit)) = R_log(PAR <= 10 & (isnan(NEE) | ustar < ustar_crit));

%%% Fill in data for outside of G.S. during the day
NEE(PAR > 10 & (isnan(NEE) | ustar < ustar_crit) & (dt < gsstart | dt > gsend)) = ...
    R_log(PAR > 10 & (isnan(NEE) | ustar < ustar_crit) & (dt < gsstart | dt > gsend));

%%% Replace for day when values are missing
% ind_bad_day = find(PAR > 10 & isnan(NEE) & dt >= gsstart & dt <= gsend);
% NEE(ind_bad_day) = R_log(ind_bad_day) - P_log(ind_bad_day);
NEE(PAR > 10 & isnan(NEE) & dt >= gsstart & dt <= gsend) = ...
    R_log(PAR > 10 & isnan(NEE) & dt >= gsstart & dt <= gsend) - ...
    P_log(PAR > 10 & isnan(NEE) & dt >= gsstart & dt <= gsend);

NEE_fill = NEE;     %%%% tracking variable

%% Respiration
Resp(1:1:length(dt)) = NaN;
%########################################################
%%% Nighttime value filled by model
Resp(PAR <= 10) = R_log(PAR <= 10);

%%% Nighttime with ustar > critical overwritten with measured NEE
Resp(PAR <= 10 & ustar >= ustar_crit) = NEE(PAR <= 10 & ustar >= ustar_crit);

%%% Daytime Growing Season R with Model
Resp(PAR > 10 & dt >= gsstart & dt <= gsend) = R_log(PAR > 10 & dt >= gsstart & dt <= gsend);
% Resp(PAR > 10 & dt >= gsstart & dt <= gsend) = 25;
%%% All other times filled with model
%%% Daytime Non - Growing Season R with Model
Resp(PAR > 10 & (dt < gsstart | dt > gsend)) = NEE(PAR > 10 & (dt < gsstart | dt > gsend));

%%% Transpose and remove where Resp < 0
Resp = Resp';
Resp(Resp < 0) = NaN;
% % Fill missing data up to 3 points wide by linear interpolation
% [Resp] = jjb_interp_gap(Resp,dt, 3); 

%%% Fill rest of missing data with modeled data
resp_nan = find(isnan(Resp(:,1)));
Resp(resp_nan,1) = R_log(resp_nan,1);
%Resp(resp_nan,1) = 30;

%% ########################################################
%%% Play around with modeled Photosynthesis to see if modeled sum is
%%% anywhere close to the calculated sum.

P_log((dt < gsstart | dt > gsend)) = 0;
P_sum = nansum(P_log)*0.0216;


% Resp(isnan(Resp),1) = R_log(isnan(Resp),1);

%% Energy Balance Correction (Daytime) -- STEP 2

%%% Fill missing data into ustar --- Should this be done sooner???
ustar = jjb_interp_gap(ustar,dt,3);

%%%********************** UNUSED *****************************
% corr_1 = 0.1723; corr_2 = 0.9779; % for u* > 0.01
% rf_NEE = corr_1.*log(ustar) + corr_2;
% corr_1 = 0.96; corr_2 = 0.05; % for u* > 0.01
%%%***********************************************************

%%% Correction factor
rf_NEE = corr_1.*(1-exp(-ustar./corr_2));
%%% Set bottom value of rf_NEE to 0.8
rf_NEE(rf_NEE < 0.8) = 0.8;

%%% Correction that doesn't do anything because it is divided by 1
%NEE(PAR > 10 & ~isnan(ustar)) = NEE(PAR > 10 & ~isnan(ustar))./1;
% %%% Alternative (commented) ---- corrected according to correction factor
% NEE_EC(PAR > 10 & ~isnan(ustar)) = NEE(PAR > 10 & ~isnan(ustar))./rf_NEE(PAR > 10 & ~isnan(ustar));

%%% Correction for ustar = Nan --- BUT THIS IS REMOVED BY INTERPOLATION??
%NEE(PAR > 10 & isnan(ustar)) = NEE(PAR > 10 & isnan(ustar))./1; %% also 0.96

NEE_d_corr = NEE; %% tracking variable

%% Energy Balance Correction (Nighttime)
%%% These corrections provide a 10% correction factor to the flux data
%%% because the night data during high-wind conditions  are not corrected
%%% for energy balance.  0.96 comes from (H+LE)/(Rn-G0-Jt) versus ustar for
%%% ustar > 0.35 and ustar < 0.8, since most night data have ustar < 0.8
% NEE(PAR <= 10) = NEE(PAR <= 10)./ 0.96;
%NEE(PAR <= 10) = NEE(PAR <= 10)./ 1; %% Doesn't change anything 

%%% Respiration is corrected for the same reason stated above.
% Resp = Resp./ 0.96;
%Resp = Resp./ 1; %% Changes nothing

NEE_dn_corr = NEE;

%% Fill rest of missing NEE data with linear interpolation
% NEE = interp_nan(dt, NEE);  %% All corrections
[NEE] = jjb_interp_gap(NEE,dt, 3); %% All corrections

% NEE_d_corr = interp_nan(dt, NEE_d_corr); %% Day correction % high-wind
[NEE_d_corr] = jjb_interp_gap(NEE_d_corr,dt, 3); %% Day correction % high-wind

% NEE_dn_corr = interp_nan(dt, NEE_dn_corr); %% Day/Night Corr & high wind
[NEE_dn_corr] = jjb_interp_gap(NEE_dn_corr,dt, 3); %% Day/Night Corr & high wind

% NEE_fill = interp_nan(dt, NEE_fill);  % high-wind only
[NEE_fill] = jjb_interp_gap(NEE_fill,dt, 3); %% High-wind correction only




%% Correcting Winter Uptake Problem
%%% Remove -'ve NEE outside of growing season and replace with respiration
NEE(NEE < 0 & (dt < gsstart | dt > gsend)) = Resp(NEE < 0 & (dt < gsstart | dt > gsend));
%%% Do the same for other measurement in order to compare
% NEE_d_corr(NEE_d_corr < 0 & (dt < gsstart | dt > gsend)) = Resp(NEE_d_corr < 0 & (dt < gsstart | dt > gsend));
% NEE_dn_corr(NEE_dn_corr < 0 & (dt < gsstart | dt > gsend)) = Resp(NEE_dn_corr < 0 & (dt < gsstart | dt > gsend));


%% Calculating GEP
GEP = Resp - NEE;
%%% Remove any negative GEP (Since it's impossible)
GEP(GEP < 0) = 0;

%% Calculating Annual NEE, Respiration and GEP
%%% Calculating Annual NEE as: NEE * 12e-06 * 1800 = NEE * 0.0216
%%% Converts umolCO2 m^-2 s^-1 to gC m^-2 hh^-1
NEE_sum  = nansum(NEE).*0.0216;  %% Annual sum with all corrections 
NEE_d_corr_sum = nansum(NEE_d_corr).*0.0216;  %% day & high wind corrections
NEE_dn_corr_sum = nansum(NEE_dn_corr).*0.0216;  %% day/night & high wind
NEE_fill_sum = nansum(NEE_fill).*0.0216;  %% high-wind only

Resp_sum = nansum(Resp).*0.0216;
GEP_sum = Resp_sum - NEE_sum;

%% Calculating LE and Hs Data
%%% Correction factor
rf_LE = rf_NEE; %%% Use the same correction factor as us used for carbon flux

%%% Correct LE and H according to Correction Factor
% LE = LE_orig./rf_LE;    %% Commented
% Hs = Hs_orig./rf_LE;    %% Commented
LE = LE_orig./1;    % Does not change value
Hs = Hs_orig./1;    % Does not change value

%% Clean LE and Hs
%%% Eliminate data when std. dev. is too high -- Where is sigma from??????
% LE(sigma > 6) = NaN;
% Hs(sigma > 6) = NaN;

%%% Remove large spikes
LE(LE > 800 | LE < -200) = NaN;
Hs(Hs > 800 | Hs < -200) = NaN;

Hs_orig2 = Hs;
LE_orig2 = LE;
%% Fill Gaps in H 
x_var = Rn-G0;
Hs = jjb_WLR_gapfill(x_var, Hs, 240,'on'); 
Hs = jjb_WLR_gapfill(x_var, Hs, 720,'on'); 

%% Fill LE Gaps
%%% Step 1 - make LE gaps 0 if at night
LE(isnan(LE) & PAR <= 20) = 0;

%%% Step 2 - Growing-season daytime LE filling method
%%% Use a moving window approach; the same method as Hs
LE_fill1 = jjb_WLR_gapfill(x_var, LE, 240,'on'); 
LE_fill2 = jjb_WLR_gapfill(x_var, LE_fill1, 720,'on'); 

LE(isnan(LE) & PAR > 20 & dt > gsstart & dt < gsend) = LE_fill2(isnan(LE) & PAR > 20 & dt>gsstart & dt < gsend);

%%% Step 3 - Non Growing Season daytime LE filling method
%%% Use average 1/2hr value for period five days before to five days after.
LE_fill_MDV = jjb_MDV_gapfill(LE, 10, 48);

LE(isnan(LE) & PAR > 20 & (dt < gsstart | dt > gsend)) = LE_fill_MDV(isnan(LE) & PAR > 20 & (dt < gsstart | dt > gsend));

%% Calculate Annual Evapotranspiration
%%% Convert LE in W/m^2 to mm/hhour 
%%% by using either (LE/lambda(T_air).*1800) --- What is Lambda?????
%%% or LE/343  
ET_cumsum = nan_cumsum(LE./1372);
ET_sum = ET_cumsum(end);

%% Investigate Energy Budget Closure Losses
energy_in = (Rn - G0 + Jt); % For time being, Jt is backwards in notation.
% energy_in = (Rn - G0 - Jt);

energy_out = (Hs + LE);
resid = energy_in - energy_out;

%%% **********************************
% %%% Not Sure what this is
% ind = 1;
% energy_out(ind) = NaN;
% energy_in(ind) = NaN;

%%%************************************
energy_in2 = energy_in(~isnan(Hs_orig2) & ~isnan(LE_orig2) &  ~isnan(G0) &  ~isnan(Jt) &  ~isnan(Rn));
energy_out2 = energy_out(~isnan(Hs_orig2) & ~isnan(LE_orig2) &  ~isnan(G0) &  ~isnan(Jt) &  ~isnan(Rn));

% 
% energy_in2 = energy_in(~isnan(energy_out) & ~isnan(energy_in));
% energy_out2 = energy_out(~isnan(energy_out) & ~isnan(energy_in));

%%% Correlation Coefficient
corr_coef = corrcoef(energy_in2,energy_out2);


%% Fit regression line through energy balance variables
energy_fit = polyfit(energy_in2,energy_out2,1);
x_fit = (min(energy_in2):0.5:max(energy_out2));
energy_eval = polyval(energy_fit, x_fit);

%%% Slope of regression line
s_energy = (energy_eval(end)- energy_eval(1)) ./(x_fit(end) - x_fit(1));
%%% Intercept of Regression Line
int_energy_c = round(min(x_fit):0.5:max(x_fit));
interc_energy = int_energy_c(int_energy_c==0);

%% Output results to the screen for inspection
disp (['Report for Flux calculation for year ' year]);
disp (['Annual NEE is ' num2str(NEE_sum)]); 
disp (['Annual NEE (fill only) is ' num2str(NEE_fill_sum)]); 
disp (['Annual NEE (fill & day correction) is ' num2str(NEE_d_corr_sum)]); 
disp (['Annual NEE (fill & day/night correction) is ' num2str(NEE_dn_corr_sum)]);
disp (['Annual Respiration is ' num2str(Resp_sum)]); 
disp (['Annual GEP is ' num2str(GEP_sum)]); 
disp (['Annual ET is ' num2str(ET_sum)]);
disp (['Correlation Coeff for EB is ' num2str(corr_coef(2,1))]);
disp (['Slope of EB Regression is ' num2str(s_energy)]);
disp (['Intercept of EB Regression is ' num2str(interc_energy)]);

%% SAVE DATA

save([flux_calc_path 'NEE_final_4.dat'], 'NEE', '-ASCII');
save([flux_calc_path 'NEE_fill_1.dat'], 'NEE_fill', '-ASCII');
save([flux_calc_path 'NEE_dcorr_2.dat'], 'NEE_d_corr', '-ASCII');
save([flux_calc_path 'NEE_dncorr_3.dat'], 'NEE_dn_corr', '-ASCII');
save([flux_calc_path 'GEP.dat'], 'GEP', '-ASCII');
save([flux_calc_path 'Resp.dat'], 'Resp', '-ASCII');
save([flux_calc_path 'LE.dat'], 'LE', '-ASCII');
save([flux_calc_path 'Hs.dat'], 'Hs', '-ASCII');
save([flux_calc_path 'ET_cumsum.dat'], 'ET_cumsum', '-ASCII');
%%% Cumulative numbers
save([flux_calc_path 'NEE_final_sum.dat'], 'NEE_sum', '-ASCII');
save([flux_calc_path 'NEE_fill_sum.dat'], 'NEE_fill_sum', '-ASCII');
save([flux_calc_path 'NEE_dcorr_sum.dat'], 'NEE_d_corr_sum', '-ASCII');
save([flux_calc_path 'NEE_dncorr_sum.dat'], 'NEE_dn_corr_sum', '-ASCII');
save([flux_calc_path 'GEP_sum.dat'], 'GEP_sum', '-ASCII');
save([flux_calc_path 'ET_sum.dat'], 'ET_sum', '-ASCII');

%% Save data to log file
fid = fopen(log_path,'a');
fprintf(fid,'%s\n', datestr(now));
fprintf(fid,'%s\n', 'Parameters are: ');
fprintf(fid,'%s\n', ['GS start: ' num2str(gsstart) ' GS end:' num2str(gsend)]);
fprintf(fid,'%s\n', ['GEP cut start: ' num2str(GEPcutstart) ' GEP cut end:' num2str(GEPcutend)]);
fprintf(fid,'%s\n', ['Flux correction 1: ' num2str(corr_1) 'Flux correction 2: ' num2str(corr_2)]);
fprintf(fid,'%s\n', ['critical u*: ' num2str(ustar_crit)]);
fprintf(fid,'%s\n', ['Annual NEE is ' num2str(NEE_sum)]);
fprintf(fid,'%s\n', ['Annual NEE (fill only) is ' num2str(NEE_fill_sum)]);
fprintf(fid,'%s\n', ['Annual NEE (fill & day correction) is ' num2str(NEE_d_corr_sum)]);
fprintf(fid,'%s\n', ['Annual Respiration is ' num2str(Resp_sum)]);
fprintf(fid,'%s\n', ['Annual GEP is ' num2str(GEP_sum)]);
fprintf(fid,'%s\n', ['Annual ET is ' num2str(ET_sum)]);
fprintf(fid,'%s\n', ['Correlation Coeff for EB is ' num2str(corr_coef(2,1))]);
fprintf(fid,'%s\n', ['Slope of EB Regression is ' num2str(s_energy)]);
fprintf(fid,'%s\n', ['Intercept of EB Regression is ' num2str(interc_energy)]);
comment = input('add comment.. hit enter for no comment','s');
if ~isempty(comment)
fprintf(fid,'%s\n', comment);
end
fprintf(fid,'%s\n', '----------------------------------------' );
fclose(fid);

%% Plot data for visual inspection
%%%%%%%%%%%%%% FIGURE 1 - NEE comparison
figure (1) 
clf;
h1 = plot(dt,NEE, 'b');
hold on;
h2 = plot(dt,NEE_fill,'r');
% h3 = plot(dt,NEE_d_corr, 'g');
% h4 = plot(dt,NEE_dn_corr,'c');
title('NEE vs. Filled NEE');
legend([h1 h2], 'final NEE','filled only');
axis([0 365 min(NEE) max(NEE)]);
ylabel('NEE (\mumol m^-^2 s^-^1)')
xlabel('Day of Year')
print('-dill',[fig_path 'NEEvsFill']);
print('-dtiff',[fig_path 'NEEvsFill']);

%%%%%%%%%%%%%% FIGURE 2 - NEE, GEP and Respiration
figure (2) 
clf;
subplot(4,1,1)
h5 = plot(dt,NEE, 'b');
legend(h5,'NEE')
axis([0 365 min(NEE) max(NEE)]);

subplot(4,1,2)
h6 = plot(dt,GEP,'g');
legend('GEP')
axis([0 365 min(GEP) max(GEP)]);

subplot(4,1,3)
h7 = plot(dt,Resp,'g');
legend('Resp')
ylabel('\mumol m^-^2 s^-^1')
axis([0 365 min(Resp) max(Resp)]);

subplot(4,1,4)
h5 = plot(dt,NEE, 'b');
hold on;
h6 = plot(dt,GEP,'r');
h7 = plot(dt,Resp, 'g');
xlabel('Day of Year');
title('NEE, GEP and Resp');
legend([h5 h6 h7], 'NEE','GEP','Respiration');
axis([0 365 min(NEE) max(GEP)]);
print('-dill',[fig_path 'NEE_GEP_R']);
print('-dtiff',[fig_path 'NEE_GEP_R']);
%%%%%%%%%%%%%% FIGURE 3 - LE and H
figure (3) 
clf;
subplot(2,1,1)
h8 = plot(dt,LE, 'b');
title('LE');
ylabel('W m^{-2}')
axis([0 365 min(LE) max(LE)]);

subplot(2,1,2)
h9 = plot(dt,Hs,'r');
title('Hs');
ylabel('W m^-^2')
xlabel('Day of Year');
axis([0 365 min(Hs) max(Hs)]);
print('-dill',[fig_path 'NEEvsFill']);
print('-dtiff',[fig_path 'NEEvsFill']);

%%%%%%%%%%%%%% FIGURE 4 -- ENERGY BALANCE - non-filled data
figure (4)
ind_eb = find(~isnan(LE) & ~isnan(Hs) & ~isnan(G0) & ~isnan(Jt) & ~isnan(Rn));
disp (['number of points used ' num2str(length(ind_eb))]);
x_ax = (Rn(ind_eb)- Jt(ind_eb)-G0(ind_eb));
y_ax = (LE(ind_eb) + Hs(ind_eb));

one_one = [-200 0 200 400 600 800 1000]';


plot(x_ax,y_ax,'bx')
hold on
plot(one_one,one_one,'k--');
title('cleaned (but not filled) energy balance')
ylabel('Hs + LE');
xlabel('Rn - Jt - G_0')
axis([-200 1000 -200 1000]);

%%%%%%%%%%%%% FIGURE 5 -- ENERGY BALANCE - filled data
figure(5)
plot(energy_in2, energy_out2,'rx')
hold on;
plot(one_one,one_one,'k--');
title ('cleaned and filled energy balance');
ylabel('Hs + LE');
xlabel('Rn - Jt - G_0')
axis([-200 1000 -200 1000]);
print('-dill',[fig_path 'Filled_EB']);
print('-dtiff',[fig_path 'Filled_EB']);

