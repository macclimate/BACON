function [] = OPEC_sort(filename, year, site) 
%% OPEC_sort.m
%%% Loads raw OPEC data files, sorts them by time into a 10-minute master
%%% file for the entire year.
%%% If the filename is inputted in '
%% 

loadstart = addpath_loadstart;

if nargin == 2;
    site = year;
    year = filename; 
    filename = [];
end

if ischar(year)==1;
    yr_str = year;
    year = str2num(year);
else
    yr_str = num2str(year);
end



%% Make timevector for the year
interval = 10;
TV1 = make_tv(year,interval);
%%% Round timevector 
TV1 = (floor(TV1.*100000))./100000;
%% Declare paths
load_dir = [loadstart 'Matlab/Data/Flux/OPEC/Raw1/' site '/DAT/' yr_str '/'];
output_path = [loadstart 'Matlab/Data/Flux/OPEC/Organized2/' site '/Master/' site '_10min_Master_' yr_str '.dat'];

%% Load Template File
template = jjb_hdr_read([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Docs/OPEC_header.csv'],',',2);

%% Check if master file already exists - If so, load it.  If not - create

if exist(output_path);                           % Check if the output master file already exists
    disp ('File exists --- Opening for appending')
    master = load(output_path);

else

    [yr JD HHMM] =jjb_makedate(year,10);
    
    %%% Create Master file
    master(1:length(TV1),1:100) = NaN;
    
    %%% Make first columns of master file
    master(:,1) = TV1;
    master(:,2) = yr;
    master(:,3) = JD;
    master(:,4) = HHMM;
end



%% Load raw data and sort it into the correct spot in master file

if isempty(filename)
    D = dir(load_dir);
    
    for i = 3:length(D)
        names(i-2,:) = D(i).name;
    end
else
    names = filename;
end
    
[rows_names cols_names]= size(names);
%% *********************   Load data file using OPEC_load

for j = 1:1:rows_names
    disp(['opening file: ' names(j,:)]);
   [data, hdr] = OPEC_load([load_dir names(j,:)]);
%%% determine size of loaded data
[num_rows num_cols] = size(data);   
   
%%% Finds if the variable 'RECORD' is recorded in the loaded file   
   find_record = find(strcmp(hdr(:,1),'"RECORD"') == 1);
if ~isempty(find_record)
    data(:,find_record:num_cols-1) = data(:,find_record+1:num_cols);
    data(:,num_cols) = NaN;
num_cols = num_cols - 1;
end
   

%%% Round timevector 
dataTV = (floor(data(:,1).*100000))./100000;

%%% Find where timevectors intersect
[c,iTV1,idata] = intersect(TV1,dataTV);

%%% Fill the master file in 
master(iTV1,5:5+num_cols-2) = data(idata,2:num_cols);

clear data num_cols num_rows data_TV iTV1 idata c;
end


%% Save the master file
disp('Saving the master file....');
save(output_path,'master','-ASCII');

disp('Done!');
%% ************************ To be commented
% year = 2005;
% site = 2;
% 
% aa = 'C:/HOME/MATLAB/Data/Data Docking Bay/TP Files/OPEC Excel files/opec_m2/2006/2006data/';
% load_path = [aa 'flux050105_050131m2.dat'];
% load_path = [aa 'flux050404_050430m2.dat'];
% load_path = [aa 'flux050806_050902m2.DAT'];
% load_path = [aa 'flux051111_051129m2.dat'];
% load_path = [aa 'flux051029_051111m2.dat'];
% load_path = [aa 'flux050526_050602m2.dat'];

%% *****************************************

