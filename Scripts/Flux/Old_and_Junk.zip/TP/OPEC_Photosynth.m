function [] = OPEC_Photosynth(year, site, flux_source, met_source)
%% Photosynthesis.m
%%%% Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option
%%%
%%%
%%%
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths and Load Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%

flux_filled_path = (['C:\Home\Matlab\Data\Flux\OPEC\Filled4\Met' site '\Met' site '_' year '_']);

%%% Output path
flux_calc_path = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated5\Met' site '\Met' site '_' year '_']);

%%% Calculated met files
met_calc_path = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);

%%% Log & Fig Path
log_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Logs\Met' site '\Met' site '_' year '_PhotosynthLog.txt']);
fig_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Figs\Met' site '\Met' site '_' year '_']);

%% Load Variables
%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);

vars = jjb_flux_load('Photosynth', year, site, flux_source, met_source);
T_air = vars(:,1);
PAR = vars(:,2);
SM5a = vars(:,3);
SM5b = vars(:,4);
SM10a = vars(:,5);
SM10b = vars(:,6);
SM20a = vars(:,7);
SM20b = vars(:,8);
ustar = vars(:,9);
clear vars;

%%% Soil temperature
Ts = load ([met_calc_path 'Ts.dat']);

%%% NEE (calculated in OPEC_Resp.m)
NEE = load([flux_calc_path 'NEE_raw.dat']);

%%% Respiration Coefficients
R_coeff = load([flux_calc_path 'NEE_Ts_cx.dat']);

%%% Air Pressure
% Pres = load([clean_path 'pres_cl.dat']);

%% Convert FC to (umolCO2 m^-2 s^-1), and Calculate preliminary NEE [FC + dcdt]
% % % % Convert FC from mg to umol
% % % FC = CO2_convert(FC_mg, T_air, Pres, 2);
% % % 
% % % % Add FC and dcdt to get prelim NEE
% % % NEE = FC + dcdt;
% 
% % Clean NEE data
% 
% NEE(NEE < 25 | NEE > 30, 1) = NaN;
% NEE(PAR <= 0 & NEE <= 0, 1) = NaN;     % no photosynthesis at dark
% NEE(Ts <= 0 & NEE <= 0, 1) = NaN;    % no photosynthesis when soil is frozen
% NEE(PAR <= 0 & Ts <= 5 & NEE >= 0, 1) = NaN;    % nighttime & low-temp respiration cap
% NEE(PAR <= 0 & NEE >= 15, 1) = NaN;    % nighttime respiration cap
% NEE(PAR <= 0 & Ts > 9 & Ts < 17 & NEE > 10, 1) = NaN;    % night resp cap
% 
% %%% Extra thresholds (for dusk/dawn)--- needed/correct?
% NEE(PAR <= 20 & Ts > 10 & NEE < 2, 1) = NaN;    % dusk/dawn resp min
% NEE(PAR <= 20 & Ts > 15 & NEE < 5, 1) = NaN;    % dusk/dawn resp min
% NEE(PAR <= 20 & Ts < 7 & NEE > 7, 1) = NaN;    % dusk/dawn resp cap
% NEE(PAR <= 20 & NEE > 15, 1) = NaN;    % dusk/dawn resp cap

%% Load Parameters

param = params(year, site, 'Photosynth');

Qthresh = param(:,1); Awa = param(:,2); ka = param(:,3);
kh = param(:,4); alpha = param(:,5); gsstart = param(:,6); 
gsend = param(:,7); 

%% Calculate Respiration
R = R_coeff(1)./(1+exp(R_coeff(2).*(R_coeff(3)-Ts))); %respiration

%%% Model Qa(PAR) (if needed) - or just use PAR
% Qa = Q0.*(1-exp(-ka*ALa)+exp(-ka*(ALa+Awa)).*(1-exp(-kh*ALh)))*(1-alpha);
% PAR = Qa
%%%

%% Calculate GEP
GEP = R - NEE;
GEP(GEP < 0) = 0; %% Remove GEP below 0 (not physically possible)

%% Save raw GEP
GEP_raw = GEP;
save([flux_calc_path 'GEP_raw.dat'],'GEP_raw','-ASCII');

%% Clean GEP w.r.t. PAR for Photosynthesis Model
if site == '4' && strcmp(year,'2005')==1;
GEP(PAR >= 1400 & PAR < 2200 & GEP < 6) = NaN;
GEP(PAR >= 1200 & PAR < 1400 & GEP < 5) = NaN;
GEP(PAR >= 1000 & PAR < 1200 & GEP < 4) = NaN;
GEP(PAR >= 500 & PAR < 1000 & GEP < 3) = NaN;
GEP(PAR >= 400 & PAR < 500 & GEP < 2) = NaN;
GEP(PAR >= 300 & PAR < 400 & GEP < 2) = NaN;
GEP(PAR >= 250 & PAR < 300 & GEP < 1) = NaN;
GEP(PAR >= 100 & PAR < 250 & GEP < 0) = NaN;

else  
%% *********************PUT BACK INTO MODEL****************************
GEP(PAR >= 1400 & PAR < 2200 & GEP < 10) = NaN;
GEP(PAR >= 1200 & PAR < 1400 & GEP < 8) = NaN;
GEP(PAR >= 1000 & PAR < 1200 & GEP < 6) = NaN;
GEP(PAR >= 500 & PAR < 1000 & GEP < 5) = NaN;
GEP(PAR >= 400 & PAR < 500 & GEP < 4) = NaN;
GEP(PAR >= 300 & PAR < 400 & GEP < 3) = NaN;
GEP(PAR >= 250 & PAR < 300 & GEP < 2) = NaN;
GEP(PAR >= 100 & PAR < 250 & GEP < 1) = NaN;
%% *************************************************
end

%% Filter GEP data for times when Photosynth is happening
good_GEP = find(dt > gsstart & dt < gsend & PAR > Qthresh & PAR < 2200);

%% Block Average GEP w.r.t. PAR
b_avg = blockavg(PAR(good_GEP),GEP(good_GEP),50,100,0);
PAR_bl = b_avg(:,1);
GEP_bl = b_avg(:,2);

%% Clean Data after averaging
%%% Remove block averages when PAR is less than 50
PAR_bl(PAR_bl < 50) = NaN;

%%% Use only data from when both block avg PAR and GEP are not NaN
PAR_bl_ok = PAR_bl(~isnan(PAR_bl) & ~isnan(GEP_bl));
GEP_bl_ok = GEP_bl(~isnan(PAR_bl) & ~isnan(GEP_bl));

PAR_bl = PAR_bl_ok;
GEP_bl = GEP_bl_ok;

bl_avgs = [PAR_bl GEP_bl];
%% Use hyperbolic function to model GEP response to PAR
[coeff y r2 sigma] = hypmain1([0.01 10 0.1], 'fit_hyp1', PAR_bl, GEP_bl);

%%% Make X values for PAR between 50 and 1900
x_PAR = (50:20:1900)';
%%% Predict GEP using derived coefficients 
GEP_pred = coeff(1)*coeff(2)*x_PAR./(coeff(1)*x_PAR + coeff(2));

avg_coeffs = [x_PAR GEP_pred];
%% Display results
disp ('The coefficients are ');
disp(coeff);
disp ('R squared value is ');
disp(r2);
%% Save data to log file
fid = fopen(log_path,'a');
fprintf(fid,'%s\n', datestr(now));
fprintf(fid,'%s\n', ['Calculated Photosynth coefficients: ' num2str(coeff)]);
fprintf(fid,'%s\n', ['Sample size for regression: ' num2str(length(good_GEP))]);
fprintf(fid,'%s\n', ['R-squared value: ' num2str(r2)]);
comment = input('add comment.. hit enter for no comment','s');
if ~isempty(comment)
fprintf(fid,'%s\n', comment);
end
fprintf(fid,'%s\n', '----------------------------------------' );
fclose(fid);
%% Save calculated variables
save ([flux_calc_path 'GEP_PAR_cx_Avg.dat'],'avg_coeffs','-ASCII');
save ([flux_calc_path 'GEP_PAR_cx.dat'],'coeff','-ASCII');
save ([flux_calc_path 'GEP_PAR_BlAvg.dat'],'bl_avgs','-ASCII');
save ([flux_calc_path 'GEP.dat'],'GEP','-ASCII');

%% Plot GEP, R and NEP (-'ve NEE)
figure (1)
subplot (3,1,1)
plot(dt,GEP, 'g')
legend('GEP')
axis([0 365 min(GEP) max(GEP)])

subplot (3,1,2)
plot(dt,R, 'r')
ylabel('\mumol m^-^2 s^-^1')
legend('Respiration')
axis([0 365 min(R) max(R)])

subplot(3,1,3)
plot(dt,NEE, 'b');
xlabel('Day of Year');
legend('NEE')
axis([0 365 min(NEE) max(NEE)])
print('-dill',[fig_path 'Photo_GEP_R_NEE']);
print('-dtiff',[fig_path 'Photo_GEP_R_NEE']);

%% Plot PAR vs good GEP data for inspection
figure (2)
plot(PAR(good_GEP), GEP(good_GEP),'.')
xlabel('PPFD (\mumol m^-^2 s^-^1)','FontSize',18)
ylabel('GEP (\mumol m^-^2 s^-^1)','FontSize',18)
axis([0 2000 0 50])
title('PAR vs Ungrouped GEP')
print('-dill',[fig_path 'PAR_GEP_Raw']);
print('-dtiff',[fig_path 'PAR_GEP_Raw']);

%% Plot block averaged PAR and GEP vs modeled GEP 
figure (3)
clf
hold on
plot(PAR_bl, GEP_bl, 'ko',...
   				'MarkerEdgeColor','k',...
                'MarkerFaceColor','k',...
                'MarkerSize',8);


plot(x_PAR,GEP_pred,'k')
h = legend('Measured','Fitted',4);
set(h,'visible','off')
axis([0 2000 0 50])
xlabel('PPFD (\mumol m^-^2 s^-^1)','FontSize',18)
ylabel('GEP (\mumol m^-^2 s^-^1)','FontSize',18)
box
hold off
title('Measured and Fitted PAR vs GEP')
print('-dill',[fig_path 'PAR_GEP']);
print('-dtiff',[fig_path 'PAR_GEP']);
