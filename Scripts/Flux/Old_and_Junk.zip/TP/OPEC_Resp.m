 function [] = OPEC_Resp(year, site, flux_source, met_source)
%% OPEC_Resp.m
%%%% Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option
%%%
%%%
%%%
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths and Load Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%

flux_filled_path = (['C:\Home\Matlab\Data\Flux\OPEC\Filled4\Met' site '\Met' site '_' year '_']);

%%% Output path
flux_calc_path = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated5\Met' site '\Met' site '_' year '_']);

%%% Calculated met files
met_calc_path = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);

%%% Log path & Fig Path
log_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Logs\Met' site '\Met' site '_' year '_RespLog.txt']);
fig_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Figs\Met' site '\Met' site '_' year '_']);


%% Load Variables
%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);

%%%Cleaned 2-height dcdt in umol/mol * (m^-2s^-2)
dcdt = load ([flux_calc_path 'dcdt_2h_cleaned.dat']);

%%% Soil temperature
Ts = load ([met_calc_path 'Ts.dat']);

%%% Cleaned Air Pressure

if isequal(flux_source,'processed')==1 && isequal(site,'1')==0;
   Pres = load([flux_filled_path 'P_filled.dat']); 
elseif isequal(flux_source,'processed')==1 && isequal(site,'1')==1;
   Pres = load(['C:\HOME\MATLAB\Data\Flux\CPEC\Met1\HH_fluxes\Met1_' year '_pres_cl.dat']);    
else
Pres = load([flux_filled_path 'pres_cl.dat']);
end



vars = jjb_flux_load('Resp', year, site, flux_source, met_source);
T_air = vars(:,1);
PAR = vars(:,2);
FC = vars(:,3);
ustar = vars(:,4);

clear vars;


%% Convert FC to (umolCO2 m^-2 s^-1), and Calculate preliminary NEE [FC + dcdt]
%%% Convert FC from mg to umol on years when it has been recorded as mgm-3
if (site=='2' || site == '3' || site == '4') && (strcmp(year,'2006')==1) 
FC = CO2_convert(FC, T_air, Pres, 2);
end

% FC = CO2_convert(FC, T_air, Pres, 2);
%%% Temporarily make NaNs in dcdt file = 0 -- will want to model this later
dcdt(isnan(dcdt) & ~isnan(FC),1) = 0;
%%% Add FC and dcdt to get prelim NEE
NEE_uncut = FC + dcdt;
NEE_raw = NEE_uncut;

%% Clean NEE for obvious outliers
NEE_raw(NEE_raw < -35 | NEE_raw > 30, 1) = NaN;
NEE_raw(PAR <= 20 & NEE_raw <= 0, 1) = NaN;     % no photosynthesis at dark
NEE_raw(Ts <= 0 & NEE_raw <= 0, 1) = NaN;    % no photosynthesis when soil is frozen
NEE_raw(PAR <= 20 & Ts <= 5 & NEE_raw >= 5, 1) = NaN;    % nighttime & low-temp respiration cap
NEE_raw(PAR <= 20 & NEE_raw >= 15, 1) = NaN;    % nighttime respiration cap

NEE = NEE_raw;
%% Figure 5 - Plot NEE for inspection
figure(5)
hold on
plot(dt,FC,'g')
plot(dt,NEE_raw,'r')
plot(dt,dcdt,'k')

%% ****************PUT BACK INTO MODEL****************************
%% Clean NEE data further to clean for use with Respiration model:
% NEE(PAR <= 20 & Ts > 10 & NEE < 2, 1) = NaN;    % dusk/dawn resp min
% NEE(PAR <= 20 & Ts > 15 & NEE < 3, 1) = NaN;    % dusk/dawn resp min
% NEE(PAR <= 20 & Ts < 7 & NEE > 5, 1) = NaN;    % dusk/dawn resp min
%% ********************************************

% % % % % % NEE(PAR <= 20 & Ts < 15 & NEE > 10, 1) = NaN;    % dusk/dawn resp min
% % % % % % NEE(PAR <= 20 & Ts < 7 & NEE > 2, 1) = NaN;    % dusk/dawn resp min
% % % % % % NEE(PAR <= 20 & Ts < 9 & NEE > 3, 1) = NaN;    % dusk/dawn resp min
% % % % % % %%% Extra thresholds (for dusk/dawn)--- needed/correct?
% % % % % %
% % % % % % NEE(PAR <= 0 & Ts > 9 & Ts < 17 & NEE > 10, 1) = NaN;    % night resp cap
% % % % % % NEE(PAR <= 20 & Ts < 7 & NEE > 7, 1) = NaN;    % dusk/dawn resp cap
% % % % % % NEE(PAR <= 20 & NEE > 15, 1) = NaN;    % dusk/dawn resp cap

%% Define Start and End of Growing Season
%%% This should eventually be put into a separate parameters file

param = params(year, site, 'Resp');
        gsstart = param(:,1);   gsend = param(:,2);
        NEE_cap = param(:,3);   ustar_crit = param(:,4);

%% Establish day and night respiration times
%%% All periods when uptake should be 0 (At night)
%% ************** removed
% ind_night = find((PAR <= 20 | dt < gsstart | dt > gsend) & ustar > ustar_crit & ~isnan(Ts.*NEE));
%******************

ind_night = find(PAR <= 20 & ustar > ustar_crit & ~isnan(Ts.*NEE));

%%% All periods when uptake should be 0 (During day)

% ind_day = find((PAR >= 20 | dt < gsstart | dt > gsend) & ustar > ustar_crit & ~isnan(Ts.*NEE));
% Modified by JJB on Sept 24, 2007 
%  - changed ind_day criteria
ind_day = find((PAR >= 20 & (dt < gsstart | dt > gsend)) & ustar > ustar_crit & ~isnan(Ts.*NEE));

%%  Find relationship between Ts2 and NEE by block averaging
b_avg = blockavg(Ts(ind_night), NEE(ind_night), 0.5, 15, -25);

%% Clean data (remove any NaNs)
b_avg = b_avg(~isnan(b_avg(:,1)) & ~isnan(b_avg(:,2)),1:4);
% %%% select NEE when Ts is very high and very low
% lowTs_NEE = b_avg(b_avg(:,1) <= -2,2); %%% NEE when TS <= -2
% highTs_NEE = b_avg(b_avg(:,1) >= 20,2);  %%% NEE when TS >= 20
% %%% If there is no NEE data when Ts is high, use a cap (=7)
% if (isnan(highTs_NEE))
%     highTs_NEE = NEE_cap  ;
% end
%% Add data points for NEE during times of very low Ts values
b_avg = [[-15 -0.2 b_avg(1,3:4)];
    [-10 0 b_avg(1,3:4)];
    [-5 0 b_avg(1,3:4)];
    b_avg];

%% clean block averaged data to avoid times when sigma is 0
b_avg_cl = b_avg(b_avg(:,3) ~= 0,:);

%% Use 'fitmain' function to develop coefficients
[coeff,y,r2,sigma] = fitmain([5 .1 .1], 'fitlogi5', b_avg_cl(:,1), b_avg_cl(:,2));

%% Turn coeffs into stepwise average values for temperature increments
temp_steps = (-7:1:30)';  %% temperature steps

%%% calculate model output at temp increments for fitlogi5
coeff_step=(coeff(1))./(1 + exp(coeff(2).*(coeff(3)-temp_steps)));

% %%% calculate model output at temp increments for fitlogi1
% coeff_step = (coeff(1)-coeff(4))./(1 + exp(coeff(2).*(coeff(3)-temp_steps))) + coeff(4); %% What eqn???

avg_coeffs = [temp_steps coeff_step];

%% Display results
disp ('The calculated coefficients are ');
disp (coeff);
disp ('The original input sample size is ' );
disp (length(ind_night));
disp ('R-squared value is ');
disp(r2)
%% Save data to log file
fid = fopen(log_path,'a');
fprintf(fid,'%s\n', datestr(now));
fprintf(fid,'%s\n', ['Calculated Resp coefficients: ' num2str(coeff)]);
fprintf(fid,'%s\n', ['Sample size for regression: ' num2str(length(ind_night))]);
fprintf(fid,'%s\n', ['R-squared value: ' num2str(r2)]);
comment = input('add comment.. hit enter for no comment','s');
if ~isempty(comment)
fprintf(fid,'%s\n', comment);
end
fprintf(fid,'%s\n', '----------------------------------------' );
fclose(fid);

%% Save data
save ([flux_calc_path 'NEE_Ts_cx_Avg.dat'],'avg_coeffs','-ASCII');
save ([flux_calc_path 'NEE_Ts_cx.dat'],'coeff','-ASCII');
save ([flux_calc_path 'NEE_Ts_BlAvg.dat'],'b_avg','-ASCII');
save ([flux_calc_path 'NEE_resp.dat'],'NEE','-ASCII');
save ([flux_calc_path 'NEE_raw.dat'],'NEE_raw','-ASCII');
save ([flux_calc_path 'NEE_uncut.dat'],'NEE_uncut','-ASCII');

%% Plot results for visual inspection
%%%%%%%%%%%%%%%%%%%%%%%%%%%% FIGURE 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Block-Avg Respiration (Ts vs NEE) during no Photosynth %%%
figure(1)
hold on
box
plot(b_avg(:,1),b_avg(:,2),'ko',...
   				'MarkerEdgeColor','k',...
                'MarkerFaceColor','k',...
                'MarkerSize',7);
 plot(temp_steps,coeff_step,'k-')
set(gca,'box','on','xlim',[-10 30],'FontSize',12);
set(gca,'box','on','ylim',[-2 10],'FontSize',12);
xlabel('\itT_{soil}\rm (^oC) at 2 cm','FontSize',18)
ylabel('Respiration (\mumol m^-^2 s^-^1)','FontSize',18)
title('Block-averaged Respiration based on Ts vs NEE');
print('-dill',[fig_path 'Ts_Resp']);
print('-dtiff',[fig_path 'Ts_Resp']);

%%% *********** Unused ****** 
%plot(avgg,(coeff(1)-coeff(4))./(1 + exp(coeff(2).*(coeff(3)-avgg))) +
%coeff(4),'k-')
%p = polyfit(avg1(:,1),avg1(:,2),2)
%f = polyval(p,avg1(:,1));
%plot(avg1(:,1),f,'-')
%axis([-5 18 -1 10])
%%% *************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%% FIGURE 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Raw Ts vs NEE %%%%%%%%%%%%

figure(2)
subplot(3,1,1)
hold on
box
plot(Ts,NEE,'b.')
set(gca,'box','on','xlim',[-20 40],'FontSize',12);
set(gca,'box','on','ylim',[-40 30],'FontSize',12);
% xlabel('\itT_{soil}\rm (^oC) at 2 cm','FontSize',14)
% ylabel('Respiration (\mumol m^-^2 s^-^1)','FontSize',14)
title('All Ts vs NEE (no block avg)');
axis tight
%%%%% Nighttime Ts vs NEE (no block avg) %%%%%%%%%%%%


subplot(3,1,2)
hold on
plot(Ts(ind_night),NEE(ind_night),'b.')
set(gca,'box','on','xlim',[-10 40],'FontSize',12);
set(gca,'box','on','ylim',[-40 30],'FontSize',12);
% xlabel('\itT_{soil}\rm (^oC) at 2 cm','FontSize',14)
ylabel('Respiration (\mumol m^-^2 s^-^1)','FontSize',14)
title('Nighttime Ts vs NEE (no block avg)');
axis tight
%%%%% Daytime PAR vs NEE (no block avg) %%%%%%%%%%%%


subplot(3,1,3)
hold on
box
plot(PAR(ind_day),NEE(ind_day),'b.')
set(gca,'box','on','xlim',[-100 2400],'FontSize',12);
set(gca,'box','on','ylim',[-40 30],'FontSize',12);
xlabel('\itPPFD_{26m} (\mumol m^-^2 s^-^1)','FontSize',14)
% ylabel('NEE  (\mumol m^-^2 s^-^1)','FontSize',14)
title('Daytime Ts vs NEE (no block avg)');
axis tight
print('-dill',[fig_path 'Ts_Resp_Raw']);
print('-dtiff',[fig_path 'Ts_Resp_Raw']);

%% Figure 5 - Plot NEE for inspection
figure(5)
hold on

plot(dt,NEE,'b')

legend ('FC','raw NEE','dcdt', 'Cleaned NEE');
xlabel('Day of Year')
ylabel('\mumol m^-^2 s^-^1; \mumol m^-^3)')
title('CO_2-related variables')
axis tight
print('-dill',[fig_path 'FC_dcdt_NEE']);
print('-dtiff',[fig_path 'FC_dcdt_NEE']);

%% 
figure(6)
plot(Ts(ind_night),NEE(ind_night),'.')
hold on
plot(temp_steps,coeff_step,'k-')

