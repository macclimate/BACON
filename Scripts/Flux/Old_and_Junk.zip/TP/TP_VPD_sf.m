function [GEP_adj2 VPD_sf] = TP_VPD_sf(VPD, GEP, tracker, block_avg, curve_type)
VPD_sf(1:length(VPD),1) = 1;
VPD_1c_sf(1:length(VPD),1) = 1;
VPD_2c_sf(1:length(VPD),1) = 1;

if isempty(block_avg)
    block_avg = 'off'
end

VPD_test = (0:0.1:3)';
ind_ok = find(~isnan(VPD) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50);

%% block average to get idea of where data is going trend-wise:
%%%%%%%%%%%%%%%%%%%%%%
bavg = blockavg(VPD(ind_ok),GEP(ind_ok),0.1,60,-20);
ind_ok_bavg = find(~isnan(bavg(:,1).*bavg(:,2)) & bavg(:,4) > 10 & bavg(:,1) > 0);
bavg2 = bavg(ind_ok_bavg,:);
clear bavg; bavg = bavg2; clear bavg2;

%% Moving average:
mov_avg = jjb_mov_avg(bavg(:,2),5, 'on','off');
% mov_avg = mov_avg./peak_y;

figure(7); clf
plot(bavg(:,1),bavg(:,2),'rx-'); hold on;
plot(bavg(:,1),mov_avg,'go')

%% Try to find where the curve begins to trend downwards (at end);
if length(bavg) > 40
    incr = 5;
    addt = 2;
elseif length(bavg) > 20 && length(bavg) <=40
    incr = 3;
    addt = 0;
else
    incr = 2;
    addt = 0;
end

for j = 1:1:length(bavg)-incr;
    slope(j,1) = (mov_avg(j+incr) - mov_avg(j))./(bavg(j+incr,1) - bavg(j,1));
end

figure(42); clf;
plot(VPD(ind_ok),GEP(ind_ok),'b.');hold on;
plot(bavg(:,1),bavg(:,2),'ro');

slope_x = (1:1:length(slope))';

figure(52);clf
plot(bavg(slope_x,1),slope,'.-');

%% location of curve peak

peak_loc = find(slope_x <(length(bavg)./2) & slope < 0,1,'first') + addt;
if isempty(peak_loc)
    peak_loc = 1;
    curve_type = 'single';
end

%% x and y values at curve peak
peak_x = bavg(peak_loc,1);
peak_y = mov_avg(peak_loc,1);
%%%%

%%% fashion data points at the low end if there are some missing:
% if peak_x > 0.1


% ind_reg = find(~isnan(VPD) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50 & VPD > peak_x);


% switch block_avg
%     case 'on'
% %         x = [peak_x.*ones(5,1) ; bavg(peak_loc:length(bavg),1); ] ; y = [bavg(1:peak_loc,2) peak_y.*ones(5,1)];
% %         %%% Normalize values (to make factor from 0 to 1)
% %         y = y./ peak_y;
%     case 'off'
%         x = VPD(ind_reg); y = GEP(ind_reg);
% %         low_end = find(bavg(peak_loc:length(bavg),2)== min(bavg(peak_loc:length(bavg),2)));
%         y = y - bavg(low_end+peak_loc-1,2);
%         %%% Normalize values (to make factor from 0 to 1)
%
%         y = y./(peak_y-y);
% end
%%%%%%%%%%%%%%%%%%%%%%%%

%% Fit model in 2 parts? Upslope and Downslope?
%%% Separate data into less than peak and greater than peak on x:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Low side (upcurve):
try
    ind1 = find(~isnan(VPD) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50 & VPD < peak_x);
    x1 = VPD(ind1); y1 = GEP(ind1);
    % Normalize y1:
    y1 = y1./peak_y;
    [b1,y_pred1,stats1,sigma1] = fitmain([1 1 1], 'fitlogi5', x1, y1);
    figure(10); clf
    plot(x1,y1,'.')
    hold on;
    plot(x1,y_pred1,'r.')

catch
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% High Side (downcurve):
ind2 = find(~isnan(VPD) & ~isnan(GEP) & tracker == 1 & GEP > -10 & GEP <= 50 & VPD >= peak_x);
x2 = VPD(ind2); y2 = GEP(ind2);

%%% Need to reduce y by the minimum bavg value for log to work (usually)
hside = find(bavg(:,1) > peak_x);
miny = min(mov_avg(hside,2));
y2 = y2-miny;
peak_y2 = peak_y-miny;

% Normalize y1:

y2 = y2./peak_y2;
[b2,y_pred2,stats2,sigma2] = fitmain([1 1 1], 'fitlogi5', x2, y2);

%%% Convert y_pred back to proper spot:
y_pred2 = ((y_pred2.*peak_y2) + miny)./peak_y;

figure(10)
plot(x2,y2,'.')
hold on;
plot(x2,y_pred2,'r.')

%%% Make these functions fit each other:
pred_norm_low = b1(1)./(1+exp(b1(2).*(b1(3)-VPD_test)));
pred_norm_high = b2(1)./(1+exp(b2(2).*(b2(3)-VPD_test))); %pred_norm_high = (pred_norm_high + miny)./peak_y;
pred_norm_high = ((pred_norm_high.*peak_y2) + miny)./peak_y;
figure(20); clf; plot(VPD_test,pred_norm_low,'r.-'); hold on; plot(VPD_test,pred_norm_high,'b.-');

%%% Single-curve approach (use down-curve only):
VPD_1c_sf(:,1) = b2(1)./(1+exp(b2(2).*(b2(3)-VPD)));
VPD_1c_sf(:,1) = ((VPD_1c_sf(:,1).*peak_y2) + miny)./peak_y;

VPD_1c_sf(VPD_1c_sf <0,1) = 0; VPD_1c_sf(VPD_1c_sf > 1,1) = 1;
%%% Double (Gamma) Curve approach:
try
    off_low = max(y_pred1); off_high = max(y_pred2);
    VPD_2c_sf(ind1) = (b1(1)./(1+exp(b1(2).*(b1(3)-VPD(ind1)))))./off_low;
    VPD_2c_sf(ind2) = (b2(1)./(1+exp(b2(2).*(b2(3)-VPD(ind2)))))./off_high;
    VPD_2c_sf(VPD_2c_sf <0,1) = 0; VPD_2c_sf(VPD_2c_sf > 1,1) = 1;
catch
    curve_type = 'single';
end

if strcmp(curve_type,'single')==1
        VPD_sf(:,1) = VPD_1c_sf(:,1);
else
        VPD_sf(:,1) = VPD_2c_sf(:,1);
end

GEP_adj2 = GEP./VPD_sf;

figure(62)
plot(VPD_sf)


