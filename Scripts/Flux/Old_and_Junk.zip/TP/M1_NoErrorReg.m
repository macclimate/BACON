%% Inspecting relationships between R and environmental variables
%%% Nov, 7, 2007 - Matthias and Jay
clear all
close all
site = '1';
model_type = 1;  
% 1 specifies models for each separate year, 
% 2 specifies average resp model and yearly GEP, and 
% 3 specifies average models for both
% 4 specifies each seperate year, using Ta > 8
% 5 specifies avg resp eqn, using Ta > 8
if ispc == 1
path = 'C:\HOME\MATLAB\Data\Data_Analysis\M1_allyears\';
else
    path = '/home/jayb/MATLAB/Data/Data_Analysis/M1_allyears/';
%     path = '/home/jayb/MATLAB/work/TP/';
end
%% Load variables for 2003-2007


    all_vars = load([path 'M1_all_yrs_data.dat']);
T_air1 = all_vars(:,1);
PAR1 = all_vars(:,2);
Ts1_2 = all_vars(:,3);
SM1 = all_vars(:,4);
NEE1 = all_vars(:,5); %NEE1(NEE1 > 35 | NEE1 < -35) = NaN;
ustar1 = all_vars(:,6);
dt1 = all_vars(:,7);
year1 = all_vars(:,8);
WS1 = all_vars(:,9);
Wdir1 = all_vars(:,10);
VPD1 = all_vars(:,11);
Ts1_5 = all_vars(:,12);



%% Load 5cm soil temperatures and replace Ts1 with that data:
% 
% Ts2a(1:17568,1:5) = NaN;
% Ts2b(1:17568,1:5) = NaN;
% Ts5a(1:17568,1:5) = NaN;
% Ts5b(1:17568,1:5) = NaN;
% 
% for t = 2003:1:2006
% vars = jjb_flux_load('SHF', num2str(t), '1', 'master', 'master');
% Ts2a(1:length(vars),t-2002) = vars(:,1);
% Ts2b(1:length(vars),t-2002) = vars(:,2);
% Ts5a(1:length(vars),t-2002) = vars(:,3);
% Ts5b(1:length(vars),t-2002) = vars(:,4);
% end
% for t2 = 2007;
%     vars = jjb_flux_load('SHF', num2str(t2), '1', 'processed', 'processed');
% Ts2a(1:length(vars),t2-2002) = vars(:,1);
% Ts2b(1:length(vars),t2-2002) = vars(:,2);
% Ts5a(1:length(vars),t2-2002) = vars(:,3);
% Ts5b(1:length(vars),t2-2002) = vars(:,4);
% end
% 
% Ts2a1 = reshape(Ts2a,[],1);
% Ts2b1 = reshape(Ts2b,[],1);
% Ts5a1 = reshape(Ts5a,[],1);
% Ts5b1 = reshape(Ts5b,[],1);
% 
% Ts5a1(Ts5b1 > 40 | Ts5a1 < -20) = NaN;
% Ts5b1(Ts5b1 > 40 | Ts5b1 < -20) = NaN;
% 
% Ts1_5 = (Ts5a1 + Ts5b1)./2;
% Ts1_5(isnan(Ts1_5)) = Ts5a1(isnan(Ts1_5));
% Ts1_5(isnan(Ts1_5)) = Ts5b1(isnan(Ts1_5));
% 
% all_vars(:,12) = Ts1_5;
% save([path 'M1_all_yrs_data.dat'],'all_vars','-ASCII')


clear all_vars;



clear Ts1 Ts2a Ts2b Ts5a Ts5b Ts2a1 Ts2b1 Ts5a1 Ts5b1 t t2;
Ts1 = Ts1_5;
clear Ts1_5;
% % %% Estimate standard deviation for all data using both (growing season +
% % %% daytime), and (non-growing season/ nighttime)  model:
% % stdev1(1:length(dt1),1) = NaN;
% % %%% Load coefficients for Respiration Error:
% % coeffs_R_error = load('C:\HOME\MATLAB\Data\Data_Analysis\M1_allyears\errorcoeffs_resp.dat');
% % [row_c col_c] = size(coeffs_R_error);
% % 
% % %%% Non Growing Season OR Nighttime (Times with no GEP input to NEE):
% % for jk = 1:1:row_c
% %         
% %     ind_r = find(ustar1 > coeffs_R_error(jk,1) & ustar1 <= coeffs_R_error(jk,2) ...
% %                 & ~isnan(Ts1));%
% %         
% %     stdev1(ind_r) = ((coeffs_R_error(jk,3)*coeffs_R_error(jk,7)) ./(1+exp(coeffs_R_error(jk,4).*(coeffs_R_error(jk,5)-Ts1(ind_r)))))+ coeffs_R_error(jk,6);
% %     clear ind_r 
% % end
% % 
% % clear row_c col_c;


%% Evaluate the total estimated respiration for the year as a result of
%% using different schemes for estimating the Respiration equation:

Ts_test = (-4:2:26)';
plot_color = [1 0 0 0.5 0 0; 0 1 0 0.8 0.5 0.7 ; 0 0 1 0.2 0.1 0.1; 1 1 0 0.4 0.5 0.1; 1 0 1 0.9 0.9 0.4; 0 1 1 0.4 0.8 0.1];
figure(1)
clf;

for jj = 2003:1:2007
    counter = jj-2002;
    
    %%% Select needed data for ustar-delimited and non-ustar delimited:
    ind_regress = find(Ts1 > 0 & PAR1 < 10 & ~isnan(Ts1) & ~isnan(NEE1) & year1 == jj & ustar1 > 0.25);%
    ind_regress_noustar = find(Ts1 > 0 & PAR1 < 10 & ~isnan(Ts1) & ~isnan(NEE1) & year1 == jj);%

%%% Regress respiration with Ts for un bin-avg data with and without ustar
%%% threshold
    [Resp(counter).coeff,Resp(counter).y,Resp(counter).r2,Resp(counter).sigma] = fitmain([1 1 1], 'fitlogi5', Ts1(ind_regress), NEE1(ind_regress));%
    [Resp(counter).coeffnu,Resp(counter).ynu,Resp(counter).r2nu,Resp(counter).sigmanu] = fitmain([1 1 1], 'fitlogi5', Ts1(ind_regress_noustar), NEE1(ind_regress_noustar));%
    %%% Bin-average ustar thresholded Resp by Ts:
Resp(counter).bavg = blockavg(Ts1(ind_regress), NEE1(ind_regress), 0.5,60, -25);  
    %%% Bin-average ustar thresholded Resp by Ts:
Resp(counter).bavgnu = blockavg(Ts1(ind_regress_noustar), NEE1(ind_regress_noustar), 0.5,60, -25);  
 %%% Regress respiration with Ts for bin-avged data
ind_okdata = find(~isnan(Resp(counter).bavg(:,1).*Resp(counter).bavg(:,2)));
    [Resp(counter).coeff2,Resp(counter).y2,Resp(counter).r22,Resp(counter).sigma2] = fitmain([5 .1 .1], 'fitlogi5', Resp(counter).bavg(ind_okdata,1), Resp(counter).bavg(ind_okdata,2));
ind_okdata_nu = find(~isnan(Resp(counter).bavgnu(:,1).*Resp(counter).bavgnu(:,2)));
    [Resp(counter).coeff2nu,Resp(counter).y2nu,Resp(counter).r22nu,Resp(counter).sigma2nu] = fitmain([5 .1 .1], 'fitlogi5', Resp(counter).bavgnu(ind_okdata_nu,1), Resp(counter).bavgnu(ind_okdata_nu,2));
         
%%%% Estimate regression equation:
est_R(counter).regustar = Resp(counter).coeff(1) ./(1 + exp(Resp(counter).coeff(2).*(Resp(counter).coeff(3)-Ts_test)));
est_R(counter).regnu = Resp(counter).coeffnu(1) ./(1 + exp(Resp(counter).coeffnu(2).*(Resp(counter).coeffnu(3)-Ts_test)));
est_R(counter).regbavg = Resp(counter).coeff2(1) ./(1 + exp(Resp(counter).coeff2(2).*(Resp(counter).coeff2(3)-Ts_test)));
est_R(counter).regnubavg = Resp(counter).coeff2nu(1) ./(1 + exp(Resp(counter).coeff2nu(2).*(Resp(counter).coeff2nu(3)-Ts_test)));    
est_R(counter).Tstest = Ts_test;


    figure(32)
    subplot(3,2,counter);
    plot (Ts1(ind_regress),NEE1(ind_regress),'k.');
    hold on;
    plot(Ts_test, est_R(counter).regustar,'k-');
    plot(Ts_test, est_R(counter).regbavg,'g-');  

  legend('all data + u*','bavg + u*' ,2); %'all data, no u*','bavg, no u*'
  
  figure(1)
plot(Ts_test, est_R(counter).regustar,'Color',plot_color(counter,1:3));
hold on;
  plot(Ts_test, est_R(counter).regbavg,'Color',plot_color(counter,4:6));
  hold on;
  
  clear  est_Rnu est_Rbavg est_Rnubavg ind_okdata ind_okdata_nu;
    
    ind_yr = find(year1==jj);
    used_data = length(find(~isnan(Ts1(ind_yr))==1));
    
    %%% Estimate respiration using non-bin-avg data:
        % with ustar > 0.3;
    Resp(counter).resp = Resp(counter).coeff(1)./(1+exp(Resp(counter).coeff(2)*(Resp(counter).coeff(3)-Ts1(ind_yr))));
        % with no ustar;
    Resp(counter).respnu = Resp(counter).coeffnu(1)./(1+exp(Resp(counter).coeffnu(2)*(Resp(counter).coeffnu(3)-Ts1(ind_yr))));
        % bin avg, u* > 0.3;
    Resp(counter).resp2 = Resp(counter).coeff2(1)./(1+exp(Resp(counter).coeff2(2)*(Resp(counter).coeff2(3)-Ts1(ind_yr))));
        % bin avg, no u*
    Resp(counter).resp2nu = Resp(counter).coeff2nu(1)./(1+exp(Resp(counter).coeff2nu(2)*(Resp(counter).coeff2nu(3)-Ts1(ind_yr))));    
        
    disp(['year: ' num2str(jj)]);
    disp(['used data: ' num2str(used_data)]);
    Resp(counter).sum = nansum(Resp(counter).resp).*0.0216;
    Resp(counter).sumnu = nansum(Resp(counter).respnu).*0.0216;
    Resp(counter).sumbavg = nansum(Resp(counter).resp2).*0.0216;
    Resp(counter).sumnubavg = nansum(Resp(counter).resp2nu).*0.0216;
    
    %%% Estimate respiration using bin-avg data:

    Resp_results(counter,1:4) = [Resp(counter).sum Resp(counter).sumnu Resp(counter).sumbavg Resp(counter).sumnubavg];
        Resp_length(counter,1:2) = [length(ind_regress) length(ind_regress_noustar)]; 
        
    clear  ind_regress ind_regress_noustar ind_yr used_data;
end

%% All years respiration curve:

ind_all_resp = find(Ts1 > 0 & PAR1 < 10 & ~isnan(Ts1) & ~isnan(NEE1) & ustar1 > 0.25);%
    [R_all_coeff,R_all_y,R_all_r2,R_all_sigma] = fitmain([1 1 1], 'fitlogi5', Ts1(ind_all_resp), NEE1(ind_all_resp));%
est_R_all = R_all_coeff(1) ./(1 + exp(R_all_coeff(2).*(R_all_coeff(3)-Ts_test)));
    
    
R_allbavg = blockavg(Ts1(ind_all_resp), NEE1(ind_all_resp), 0.5,40, -5); 
ind_okdata_all = find(~isnan(R_allbavg(:,1).*R_allbavg(:,2)));   
[R_allbavg_coeff,R_allbavg_y,R_allbavg_r2,R_allbavg_sigma] = fitmain([1 1 1], 'fitlogi5', R_allbavg(ind_okdata_all,1), R_allbavg(ind_okdata_all,2));%
est_R_allbavg = R_allbavg_coeff(1) ./(1 + exp(R_allbavg_coeff(2).*(R_allbavg_coeff(3)-Ts_test)));    

Resp_allyrs = R_allbavg_coeff(1) ./(1 + exp(R_allbavg_coeff(2).*(R_allbavg_coeff(3)-Ts1))); 

figure(32)
subplot(3,2,6)
plot(Ts_test,est_R_all,'k');
hold on;
plot(Ts_test, est_R_allbavg,'g')

figure(1)
  plot(Ts_test, est_R_all,'Color',plot_color(counter+1,1:3), 'LineWidth', 2);
  hold on;
  plot(Ts_test, est_R_allbavg,'Color',plot_color(counter+1,4:6), 'LineWidth', 2);
legend('2003', '2003 bin avg', '2004', '2004 bin avg', '2005', '2005 bin avg', '2006', '2006 bin avg', '2007', '2007 bin avg', 'All years', 'All years bin avg',2);

%% Estimate 
for jj = 2003:1:2007
est_R(jj-2002).all = R_all_coeff(1) ./(1 + exp(R_all_coeff(2).*(R_all_coeff(3)-Ts1(year1==jj))));

est_R(jj-2002).bavg = R_allbavg_coeff(1) ./(1 + exp(R_allbavg_coeff(2).*(R_allbavg_coeff(3)-Ts1(year1==jj))));    

est_Rs(jj-2002,1:2) = [nansum(est_R(jj-2002).all).*0.0216 nansum(est_R(jj-2002).bavg).*0.0216 ];
end



%Resp.sum
%Resp.sum2
%% Work with GEP now:******************************************************
% Respiration modeled using non-bin averaged, weighted data
% Resp1 = [Resp(1).resp ;NaN*ones(48,1); Resp(2).resp ; Resp(3).resp;NaN*ones(48,1) ; Resp(4).resp;NaN*ones(48,1) ; Resp(5).resp;NaN*ones(48,1)];
% GEP1 = Resp1 - NEE1;

% Respiration modeled using bin averaged data
% Option 1 -- with u* threshold:
if model_type == 2 || model_type == 3 || model_type == 5;
Resp1 = Resp_allyrs;
else
Resp1 = [Resp(1).resp2 ;NaN*ones(48,1); Resp(2).resp2 ; Resp(3).resp2 ;NaN*ones(48,1) ; Resp(4).resp2; NaN*ones(48,1) ; Resp(5).resp2 ;NaN*ones(48,1)];
end

clear Resp_allyrs;
% Resp1 = [Resp(1).resp2 ;NaN*ones(48,1); Resp(2).resp2 ; Resp(3).resp2 ;NaN*ones(48,1) ; Resp(4).resp2; NaN*ones(48,1) ; Resp(5).resp2 ;NaN*ones(48,1)];
% Option 2 -- without u* threshold:
% Resp1 = [Resp(1).respnu ;NaN*ones(48,1); Resp(2).respnu ; Resp(3).respnu ;NaN*ones(48,1) ; Resp(4).respnu; NaN*ones(48,1) ; Resp(5).respnu ;NaN*ones(48,1)];
GEP1 = Resp1 - NEE1;

%% Plot GEP vs. PAR relationship for each year (using all available data):
PAR_test = (0:200:2200);

for jk = 2003:1:2007
  counter_3 = jk-2002;
    
ind_ok_GEP = find(Ts1 > 0 & T_air1 > -5 & PAR1 > 20 & ~isnan(Ts1) ...
    & ~isnan(GEP1) & dt1 > 95 & dt1 < 330 & year1 == jk);

GEP_PAR(counter_3).GEP = GEP1(ind_ok_GEP);
GEP_PAR(counter_3).PAR = PAR1(ind_ok_GEP);

GEP_PAR(counter_3).bavg = blockavg(GEP_PAR(counter_3).PAR, GEP_PAR(counter_3).GEP, 100, 70, -25);
ok_compare = find(~isnan(GEP_PAR(counter_3).bavg(:,1) .* GEP_PAR(counter_3).bavg(:,2)));

[GEP_PAR(counter_3).coeff GEP_PAR(counter_3).y GEP_PAR(counter_3).r2 GEP_PAR(counter_3).sigma] = hypmain1([0.01 10 0.1], 'fit_hyp1', GEP_PAR(counter_3).bavg(ok_compare,1), GEP_PAR(counter_3).bavg(ok_compare,2));

GEP_PAR(counter_3).pred = GEP_PAR(counter_3).coeff(1).*PAR_test.*GEP_PAR(counter_3).coeff(2)./(GEP_PAR(counter_3).coeff(1).*PAR_test + GEP_PAR(counter_3).coeff(2));
GEP_PAR(counter_3).PAR_test = PAR_test;

clear ok_compare;
end


%% Establish relationships between env. variables and GEP (richardson)
% Plot some figures to look at relationships:

ind_good_GEP = find(Ts1 > -8 & T_air1 > -5 & PAR1 > 20 & ~isnan(Ts1) ...
    & ~isnan(T_air1) & ~isnan(GEP1) & ~isnan(SM1) & dt1 > 70 & dt1 < 345 ...
    ); %& stdev1 ~=0 & ~isnan(stdev1));

figure(31)
clf;
subplot(3,2,1); plot(Ts1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('Ts vs. GEP'); hold on;
subplot(3,2,2); plot(T_air1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('T_{air} vs. GEP'); hold on;
subplot(3,2,3); plot(PAR1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('PAR vs. GEP'); hold on;
subplot(3,2,4); plot(Wdir1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('Wind dir. vs. GEP'); hold on;
subplot(3,2,5); plot(VPD1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('VPD. vs. GEP'); hold on;
subplot(3,2,6); plot(SM1(ind_good_GEP), GEP1(ind_good_GEP), 'b.'); title('SM. vs. GEP'); hold on;

% Block average data to see average trends
b_avg_Ts = blockavg(Ts1(ind_good_GEP), GEP1(ind_good_GEP),      0.50, 80, -30);
b_avg_T_air = blockavg(T_air1(ind_good_GEP), GEP1(ind_good_GEP),0.50, 80, -30);
b_avg_PAR = blockavg(PAR1(ind_good_GEP), GEP1(ind_good_GEP),    100, 80, -30);
b_avg_Wdir = blockavg(Wdir1(ind_good_GEP), GEP1(ind_good_GEP),  10, 80, -30);
b_avg_VPD = blockavg(VPD1(ind_good_GEP), GEP1(ind_good_GEP),    0.1, 80, -30);
b_avg_SM = blockavg(SM1(ind_good_GEP), GEP1(ind_good_GEP),      0.0025, 80, -30);

figure(31)
subplot(3,2,1); plot(b_avg_Ts(:,1), b_avg_Ts(:,2), 'ro');
subplot(3,2,2); plot(b_avg_T_air(:,1), b_avg_T_air(:,2), 'ro');
subplot(3,2,3); plot(b_avg_PAR(:,1), b_avg_PAR(:,2), 'ro');
subplot(3,2,4); plot(b_avg_Wdir(:,1), b_avg_Wdir(:,2), 'ro');
subplot(3,2,5); plot(b_avg_VPD(:,1), b_avg_VPD(:,2), 'ro');
subplot(3,2,6); plot(b_avg_SM(:,1), b_avg_SM(:,2), 'ro');
% 
% % Block averaged by weighted error value
% b_avg_Ts2 = blockavg(Ts1(ind_good_GEP), GEP1(ind_good_GEP),      0.50, 80, -30, 1./stdev1(ind_good_GEP));
% b_avg_T_air2 = blockavg(T_air1(ind_good_GEP), GEP1(ind_good_GEP),0.50 ,80, -30, 1./stdev1(ind_good_GEP));
% b_avg_PAR2 = blockavg(PAR1(ind_good_GEP), GEP1(ind_good_GEP),    100, 80, -30, 1./stdev1(ind_good_GEP));
% b_avg_Wdir2 = blockavg(Wdir1(ind_good_GEP), GEP1(ind_good_GEP),  10, 80, -30, 1./stdev1(ind_good_GEP));
% b_avg_VPD2 = blockavg(VPD1(ind_good_GEP), GEP1(ind_good_GEP),    0.1, 80, -30, 1./stdev1(ind_good_GEP));
% b_avg_SM2 = blockavg(SM1(ind_good_GEP), GEP1(ind_good_GEP),      0.002, 80, -30, 1./stdev1(ind_good_GEP));
% 
% figure(31)
% subplot(3,2,1); plot(b_avg_Ts2(:,1), b_avg_Ts2(:,2), 'gx');
% subplot(3,2,2); plot(b_avg_T_air2(:,1), b_avg_T_air2(:,2), 'gx');
% subplot(3,2,3); plot(b_avg_PAR2(:,1), b_avg_PAR2(:,2), 'gx');
% subplot(3,2,4); plot(b_avg_Wdir2(:,1), b_avg_Wdir2(:,2), 'gx');
% subplot(3,2,5); plot(b_avg_VPD2(:,1), b_avg_VPD2(:,2), 'gx');
% subplot(3,2,6); plot(b_avg_SM2(:,1), b_avg_SM2(:,2), 'gx');





%% Create Logistic functions to scale GEP with met variables: SM, VPD & Ts

%% STEP 1a: Air Temperature Logistic Function:
T_air_test = (-5:1:34);

max_T_airy = 14.8;
T_air_x = [-9; -8; -7,; -6,; -5;-4.5; -4; b_avg_T_air(4:67,1); 29; 30 ];
T_air_y = [ -2;  -2;  -2; -2; -2;-2; -2;b_avg_T_air(4:67,2); max_T_airy; max_T_airy];

%%% Normalize values (to make function from 0 to 1)
T_air_y = T_air_y./max_T_airy;

%%% Fit these data with the logistic model:
[b_T_air,y_T_air,stats_T_air,sigma_T_air] = fitmain([1 1 1], 'fitlogi5', T_air_x, T_air_y);
    p_T_air = (b_T_air(1).*max_T_airy)./(1+exp(b_T_air(2).*(b_T_air(3)-T_air_x)));
    p_n_T_air = b_T_air(1)./(1+exp(b_T_air(2).*(b_T_air(3)-T_air_x)));

    figure(15)
    clf;
    plot(T_air_x, T_air_y,'bx-');
    hold on;
    plot(T_air_x, p_n_T_air, 'rv-');
    
%%% Create GEP scaling factor from the developed logistic equation:    
GEP_T_air_sf = b_T_air(1)./(1+exp(b_T_air(2).*(b_T_air(3)-T_air1)));
GEP_T_air_sf(GEP_T_air_sf > 1) = 1;
GEP_T_air_sf(T_air1 < 0) = 0;

% GEP_T_air_sf(1:length(GEP_T_air_sf)) = 1;
%%% Reduce the modeled MAX GEP by the T_air scaling factor
% GEP_T_air_red = GEP_max .* GEP_T_air_sf;

%%% Remove the influence of T_air on measured GEP by dividing GEP by the
%%% scaling factor:
GEP_T_air_adj = GEP1 ./ GEP_T_air_sf;

%%% See if a relationship between Ts and GEP is still existent:

b_Ts_avg2 = blockavg(Ts1(ind_good_GEP), GEP_T_air_adj(ind_good_GEP),      0.50, 80, -30);

figure(87); clf
plot(Ts1,GEP_T_air_adj,'b.')
hold on
plot(b_Ts_avg2(:,1),b_Ts_avg2(:,2),'ro')


%% STEP 1. Soil Temperature Logistic Function:
%%% Look at the variable - b_avg_Ts to assess the Max value of Ts
Ts_test = (-2:1:28)';
% Value for using non bin avged, u* threshold data
% max_Tsy = 13.5;
% Value for using non bin avged, NON - u* threshold data
if model_type == 2 || model_type ==3;
max_Tsy = 12.5;
Ts_x = [-5; -3; -2; b_avg_Ts(2:49,1); 24.5; 25.5;  26.5 ];
Ts_y = [ 0;  0;  0; b_avg_Ts(2:49,2); max_Tsy; max_Tsy; max_Tsy];
elseif model_type == 4
max_Tsy = 12.5;
Ts_x = [-5; -3; -2; b_avg_Ts(2:49,1); 24.5; 25.5;  26.5 ];
Ts_y = [ 0;  0;  0; b_avg_Ts(2:49,2); max_Tsy; max_Tsy; max_Tsy];
elseif model_type == 5
max_Tsy = 13;
Ts_x = [-5; -3; -2; b_avg_Ts(2:49,1); 24.5; 25.5;  26.5 ];
Ts_y = [ 0;  0;  0; b_avg_Ts(2:49,2); max_Tsy; max_Tsy; max_Tsy];
else
max_Tsy = 11.5;
Ts_x = [-5; -3; -2; b_avg_Ts(2:49,1); 24.5; 25.5;  26.5 ];
Ts_y = [ 0;  0;  0; b_avg_Ts(2:49,2); max_Tsy; max_Tsy; max_Tsy];

end 



%%% Normalize values 
Ts_y = Ts_y./max_Tsy;


%%% Fit these data with the logistic model:
[b_Ts,y_Ts,stats_Ts,sigma_Ts] = fitmain([1 1 1], 'fitlogi5', Ts_x, Ts_y);
    p_Ts = (b_Ts(1).*max_Tsy)./(1+exp(b_Ts(2).*(b_Ts(3)-Ts_x)));
    p_n_Ts = b_Ts(1)./(1+exp(b_Ts(2).*(b_Ts(3)-Ts_x)));

    figure(3)
    clf;
    plot(Ts_x, Ts_y,'bx-');
    hold on;
    plot(Ts_x, p_n_Ts, 'rv-');
    
    
% Create GEP scaling factor     
    
GEP_Ts_sf = b_Ts(1)./(1+exp(b_Ts(2).*(b_Ts(3)-Ts1)));
GEP_Ts_sf(GEP_Ts_sf > 1) = 1;
GEP_Ts_sf(Ts1 < 0) = 0;

% GEP_T_air_red = GEP_max .* GEP_T_air_sf;
GEP_T_air_sf(GEP_T_air_sf > 1) = 1;
GEP_T_air_sf(T_air1 < -5) = 0;
%  GEP_Ts_sf=GEP_T_air_sf;

%% STEP 2. Establish max GEP equation -- for each season:
PAR_test = (0:200:2200);
GEP_max(1:length(GEP1),1) = NaN;
% coeff_ideal2(1:20,1:20) = NaN;
% y_ideal2(1:20,1:20) = NaN ;
% r2_ideal2(1:20,1:20) = NaN;% sigma_ideal2(1:20,1:20) = NaN;
colorlist = ['r';'g';'b';'k';'c'];
figure(50)
clf;

figure(4)
clf;
for mm = 2003:1:2007
     ctr_year = mm-2002;

ideal_GEP = find(Ts1 > 14 & T_air1 > 20  & year1 == mm... %% & VPD1 < 1.3& Ts1 < 20 & T_air1 < 26& PAR1 < 1700 
    & ~isnan(GEP1) & dt1 > 150 & dt1 < 270 ...
    & VPD1 < 0.8 & VPD1 > 0 & SM1 > 0.085  & GEP1 > -5 & PAR1 > 30 & ustar1 > 0.3); % & (year1 == 2003 | year1 == 2006) ); % 

figure(4)
hold on;
subplot(3,2,ctr_year)
plot(PAR1(ideal_GEP),GEP1(ideal_GEP),'k.')

% Blockaverage GEP data into PAR bins:
if mm == 2007
b_avg(ctr_year).ideal = blockavg(PAR1(ideal_GEP), GEP1(ideal_GEP), 150, 70, -25);
% b_avg_ideal = blockavg(PAR1(ideal_GEP), GEP1(ideal_GEP), 200, 70, -25);
else
b_avg(ctr_year).ideal = blockavg(PAR1(ideal_GEP), GEP1(ideal_GEP), 100, 70, -25);    
% b_avg_ideal = blockavg(PAR1(ideal_GEP), GEP1(ideal_GEP), 100, 70, -25);
end
figure(4)
subplot(3,2,ctr_year); hold on;
plot(b_avg(ctr_year).ideal(:,1), b_avg(ctr_year).ideal(:,2),'ro');

% Use hyperbolic function to fit the bin-averaged data:
% if mm == 2007;
% ideal_x = [0; b_avg_ideal(1,1);b_avg_ideal(4:6,1);b_avg_ideal(8:16,1) ];
% ideal_y = [0; b_avg_ideal(1,2);b_avg_ideal(4:6,2);b_avg_ideal(8:16,2) ];
% [coeff_ideal2 y_ideal2 r2_ideal2 sigma_ideal2] = ... 
%     hypmain1([0.01 10 0.1], 'fit_hyp1', ideal_x, ideal_y);
% else
% 
% ideal_x = [0; b_avg_ideal(1:17,1)];
% ideal_y = [0; b_avg_ideal(1:17,2)];
% [coeff_ideal2 y_ideal2 r2_ideal2 sigma_ideal2] = ... 
%     hypmain1([0.01 10 0.1], 'fit_hyp1', ideal_x, ideal_y);
% end;
% ideal_x = [0; b_avg_ideal(1:19,1); 1929; 2060; 2200; 2300];
% ideal_y = [0; b_avg_ideal(1:19,2); 25; 25; 25; 25];

switch mm
    case 2003
ideal_x = [0; b_avg(ctr_year).ideal(1:20,1)];
ideal_y = [0; b_avg(ctr_year).ideal(1:20,2) ];
    case 2004
ideal_x = [0; b_avg(ctr_year).ideal(1:14,1); b_avg(ctr_year).ideal(15:19,1)];
ideal_y = [0; b_avg(ctr_year).ideal(1:14,2); b_avg(ctr_year).ideal(15:19,2)];       
    case 2005
ideal_x = [0; b_avg(ctr_year).ideal(1:17,1)];
ideal_y = [0; b_avg(ctr_year).ideal(1:17,2)];             
    case 2006
ideal_x = [0; b_avg(ctr_year).ideal(1:19,1); b_avg(ctr_year).ideal(21,1)];
ideal_y = [0; b_avg(ctr_year).ideal(1:19,2); b_avg(ctr_year).ideal(21,2)];      
    case 2007
ideal_x = [0; b_avg(ctr_year).ideal(1:11,1); b_avg(ctr_year).ideal(13:14,1)];
ideal_y = [0; b_avg(ctr_year).ideal(1:11,2); b_avg(ctr_year).ideal(13:14,2)];   
end

[coeff_ideal2 y_ideal2 r2_ideal2 sigma_ideal2] = hypmain1([0.01 10 0.1], 'fit_hyp1', ideal_x, ideal_y);

P_ideal2 = coeff_ideal2(1).*PAR_test.*coeff_ideal2(2)./(coeff_ideal2(1).*PAR_test + coeff_ideal2(2));
figure(4)
subplot(3,2,ctr_year)
plot(PAR_test,P_ideal2,'r','LineWidth',2);


figure(50)
plot(PAR_test,P_ideal2,'Color', colorlist(ctr_year),'LineWidth',2); hold on;



GEP_max(year1==mm,1) = coeff_ideal2(1).*PAR1(year1==mm).*coeff_ideal2(2)./(coeff_ideal2(1).*PAR1(year1==mm) + coeff_ideal2(2));

clear ideal_x ideal_y P_ideal2 ideal_GEP coeff_ideal2 y_ideal2 r2_ideal2 sigma_ideal2  ;

end
clear mm ctr_year
figure(50)
legend('2003','2004','2005','2006','2007',4)



%% STEP 3. VPD logistic function:

% First, remove influence of Ts on GEP:
% GEP_max = coeff_ideal2(1).*PAR1.*coeff_ideal2(2)./(coeff_ideal2(1).*PAR1 + coeff_ideal2(2)); % modeled max GEP

GEP_Ts_red = GEP_max .* GEP_Ts_sf; % modeled GEP with soil temperature influence included

% Block average PAR vs GEP by bins of 
% GEP_Ts_adj = GEP_max ./ GEP_Ts_sf;

GEP_Ts_adj = GEP1 ./ GEP_Ts_sf;


clear kk ss vpd;

PAR_bottoms = [0 500  1200]';   %(0:100:2000)';
PAR_tops =  [500 1200 2200]';    %   PAR_bottoms + 100;

figure(40)
clf;
for kk = 1:1:length(PAR_bottoms)
   
    vpd_ind = find(Ts1 > 4  & T_air1 > 4 & PAR1 > 20 & ~isnan(VPD1) ...
    & ~isnan(GEP1) & dt1 > 90 & dt1 < 330  ...
    & PAR1 > PAR_bottoms(kk) & PAR1 <= PAR_tops(kk) & SM1 > 0.08);
    
    figure(40)
    subplot(2,2,kk)
    plot(VPD1(vpd_ind,1),GEP_Ts_adj(vpd_ind,1),'b.')
    title([num2str(PAR_tops(kk)) ' > PAR > ' num2str(PAR_bottoms(kk))]);
    
    % Bin-average data:
    vpd(kk).bavg = blockavg(VPD1(vpd_ind,1),GEP_Ts_adj(vpd_ind,1), 0.2, 40, 0);
    
    figure(40)
    subplot(2,2,kk)
    hold on;
    plot(vpd(kk).bavg(:,1), vpd(kk).bavg(:,2), 'ro')
    axis([0 3 0 30])
    clear vpd_ind;
end
vpd_bavg = vpd(3).bavg;
VPD_test = (0:0.25:3);

if model_type == 2 || model_type == 3;
max_VPD = 21;
min_VPD = 12.5;
VPD_x = [-0.15; 0; 0.15; vpd(3).bavg(6:19,1); 3.2; 3.5;  3.9 ];
VPD_y = [max_VPD; max_VPD; max_VPD;  vpd(3).bavg(6:19,2); min_VPD; min_VPD; min_VPD];
elseif model_type == 4;
max_VPD = 21;
min_VPD = 12.5;
VPD_x = [-0.15; 0; 0.15; vpd(3).bavg(6:19,1); 3.2; 3.5;  3.9 ];
VPD_y = [max_VPD; max_VPD; max_VPD;  vpd(3).bavg(6:19,2); min_VPD; min_VPD; min_VPD];
elseif model_type == 5;
max_VPD = 21;
min_VPD = 12;
VPD_x = [-0.15; 0; 0.15; vpd(3).bavg(6:19,1); 3.2; 3.5;  3.9 ];
VPD_y = [max_VPD; max_VPD; max_VPD;  vpd(3).bavg(6:19,2); min_VPD; min_VPD; min_VPD];
    
else 
max_VPD = 19;
min_VPD = 12.5;
VPD_x = [-0.15; 0; 0.15; vpd(3).bavg(6:19,1); 3.2; 3.5;  3.9 ];
VPD_y = [max_VPD; max_VPD; max_VPD;  vpd(3).bavg(6:19,2); min_VPD; min_VPD; min_VPD];
end  

% Normalize values:
VPD_y = (VPD_y - min_VPD)./(max_VPD-min_VPD);

%%% Fit these data with the logistic model:

[b_VPD,y_VPD,stats_VPD,sigma_VPD] = fitmain([1 1 1], 'fitlogi5', VPD_x, VPD_y);
        p_VPD = (b_VPD(1).*(max_VPD-min_VPD))./(1+exp(b_VPD(2).*(b_VPD(3)-VPD_x))) + min_VPD;
    p_n_VPD = b_VPD(1)./(1+exp(b_VPD(2).*(b_VPD(3)-VPD_x)));

figure(41)
clf;
plot(VPD_x, VPD_y, 'b.')
hold on;
plot(VPD_x, p_n_VPD,'r')

% Create GEP scaling factor for VPD     

GEP_VPD_sf = ((b_VPD(1).*(max_VPD-min_VPD))./(1+exp(b_VPD(2).*(b_VPD(3)-VPD1))) + min_VPD)./max_VPD;
GEP_VPD_sf(GEP_VPD_sf > 1) = 1;
GEP_TsVPD_red = GEP_Ts_red .* GEP_VPD_sf; % modeled GEP with soil temperature influence included
  
    

%% Step 4. Hyperbolic (or logistic) SM function to control GEP at low soil
%% moistures

% New adjusted GEP (removing effects of soil temperature and VPD)

GEP_TsVPD_adj = GEP_Ts_adj ./ GEP_VPD_sf;

    SM_ind = find(Ts1 > 4 & T_air1 > 4 & PAR1 > 20 & PAR1 < 2200 & ~isnan(SM1) ...
    & ~isnan(GEP1) & dt1 > 90 & dt1 < 330  ...
    & SM1 > 0.04 & SM1 <= 0.1 ); %& VPD1 < 1.0

figure(43)
clf;
plot(SM1(SM_ind),GEP_TsVPD_adj(SM_ind),'b.'); %GEP_TsVPD_adj
hold on;

% Block average values

SM_bavg = blockavg(SM1(SM_ind,1),GEP_TsVPD_adj(SM_ind,1), 0.0025, 40, 0);

figure(43)
plot(SM_bavg(:,1),SM_bavg(:,2),'ro');

clear SM_ind




if model_type == 2 || model_type == 3;
min_SM = 10.239;
max_SM = 14.77;
SM_x = [SM_bavg(1:21,1); (0.10:0.01:0.25)' ]-0.05;
SM_y = [SM_bavg(1:21,2); max_SM.*ones(16,1) ];
elseif model_type == 4;
min_SM = 10.239;
max_SM = 14.77;
SM_x = [SM_bavg(1:21,1); (0.10:0.01:0.25)' ]-0.05;
SM_y = [SM_bavg(1:21,2); max_SM.*ones(16,1) ];
elseif model_type == 5;
min_SM = 11.6;
max_SM = 15;
SM_x = [SM_bavg(1:21,1); (0.10:0.01:0.25)' ]-0.05;
SM_y = [SM_bavg(1:21,2); max_SM.*ones(16,1) ];
else
min_SM = 10.239;
max_SM = 14.77;
SM_x = [SM_bavg(1:21,1); (0.10:0.01:0.25)' ]-0.05;
SM_y = [SM_bavg(1:21,2); max_SM.*ones(16,1) ];
end

% Normalize 
SM_y = (SM_y )./(max_SM );

%%% Fit hyperbolic function to data:
[coeff_SM y_SM r2_SM sigma_SM] = hypmain1([1 1 1], 'fit_hyp1', SM_x, SM_y);


P_SM = coeff_SM(1).*(SM_x).*coeff_SM(2)./(coeff_SM(1).*(SM_x) + coeff_SM(2));


figure(44)
clf;
plot(SM_x, SM_y,'b.')
hold on;
plot(SM_x, P_SM, 'kx-', 'LineWidth', 2);

%%% Scaling Factor for SM
if model_type == 2 || model_type == 3;
GEP_SM_sf = coeff_SM(1).*(SM1-0.04475).*coeff_SM(2)./(coeff_SM(1).*(SM1-0.04475) + coeff_SM(2));
GEP_SM_sf(GEP_SM_sf > 1) = 1;
GEP_SM_sf(isnan(GEP_SM_sf)) = 1;
GEP_SM_sf(GEP_SM_sf < 0.69) = 0.69;

elseif model_type == 4
GEP_SM_sf = coeff_SM(1).*(SM1-0.04475).*coeff_SM(2)./(coeff_SM(1).*(SM1-0.04475) + coeff_SM(2));
GEP_SM_sf(GEP_SM_sf > 1) = 1;
GEP_SM_sf(isnan(GEP_SM_sf)) = 1;
GEP_SM_sf(GEP_SM_sf < 0.69) = 0.69;

elseif model_type == 5
GEP_SM_sf = coeff_SM(1).*(SM1-0.0425).*coeff_SM(2)./(coeff_SM(1).*(SM1-0.0425) + coeff_SM(2));
GEP_SM_sf(GEP_SM_sf > 1) = 1;
GEP_SM_sf(isnan(GEP_SM_sf)) = 1;
GEP_SM_sf(GEP_SM_sf < 0.7733) = 0.7733;

else
GEP_SM_sf = coeff_SM(1).*(SM1-0.04475).*coeff_SM(2)./(coeff_SM(1).*(SM1-0.04475) + coeff_SM(2));
GEP_SM_sf(GEP_SM_sf > 1) = 1;
GEP_SM_sf(isnan(GEP_SM_sf)) = 1;
GEP_SM_sf(GEP_SM_sf < 0.69) = 0.69;

end

figure(5)
clf;
plot(GEP_SM_sf)

GEP_all_red = GEP_TsVPD_red .* GEP_SM_sf;
% GEP_all_red = GEP_Ts_red; % REMOVE!

figure(45)
plot(GEP1,'b');
hold on;
plot(GEP_max,'g')
plot(GEP_all_red,'r')

%% Calculate annual GEP:

% - calculate totals for NEE, GEP & modeled GEP.


%% Clean NEE
NEE1(NEE1 < -35 | NEE1 > 20, 1) = NaN;
NEE1(PAR1 <= 20 & NEE1 <= 0, 1) = NaN;     % no photosynthesis at dark
NEE1(Ts1 <= 0 & NEE1 <= 0, 1) = NaN;    % no photosynthesis when soil is frozen
NEE1(PAR1 <= 20 & Ts1 <= 5 & NEE1 >= 5, 1) = NaN;    % nighttime & low-temp respiration cap
NEE1(PAR1 <= 20 & NEE1 >= 15, 1) = NaN;    % nighttime respiration cap

if model_type == 4 || model_type == 5;
NEE1(T_air1 < 8) = NaN;  
end

%% Clean GEP

clear GEP1;
GEP1 = Resp1 - NEE1;


GEP_all_red(dt1< 85 | dt1 > 335) = 0;

GEP1(GEP1 < 0) = NaN;
GEP1(dt1 < 85 | dt1 > 335) = 0;
GEP1(PAR1 < 10) = 0;
% GEP_raw = GEP1;

%% Plot Measured vs. modeled GEP:
% Model seems to overestimate measured GEP for most years -- investigate

% Block average data
GEPa_bavg = blockavg(GEP1(:,1),GEP_all_red(:,1), 1, 50, 0);
GEP2003_bavg = blockavg(GEP1(year1==2003,1),GEP_all_red(year1==2003,1), 1, 50, 0);
GEP2004_bavg = blockavg(GEP1(year1==2004,1),GEP_all_red(year1==2004,1), 1, 50, 0);
GEP2005_bavg = blockavg(GEP1(year1==2005,1),GEP_all_red(year1==2005,1), 1, 50, 0);
GEP2006_bavg = blockavg(GEP1(year1==2006,1),GEP_all_red(year1==2006,1), 1, 50, 0);
GEP2007_bavg = blockavg(GEP1(year1==2007,1),GEP_all_red(year1==2007,1), 1, 50, 0);
figure(46)
clf;

subplot(2,2,1); plot(GEP1,GEP_all_red,'b.');title('all years'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,1); plot(GEPa_bavg(:,1),GEPa_bavg(:,2),'ro');
subplot(2,2,2); plot(GEP1(year1==2003),GEP_all_red(year1==2003),'b.'); title('2003'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,2); plot(GEP2003_bavg(:,1),GEP2003_bavg(:,2),'ro');
subplot(2,2,3); plot(GEP1(year1==2004),GEP_all_red(year1==2004),'b.'); title('2004'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,3); plot(GEP2004_bavg(:,1),GEP2004_bavg(:,2),'ro');
subplot(2,2,4); plot(GEP1(year1==2005),GEP_all_red(year1==2005),'b.'); title('2005'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,4); plot(GEP2005_bavg(:,1),GEP2005_bavg(:,2),'ro');
ylabel('modeled GEP'); xlabel('real GEP')

figure(47)
clf;
subplot(2,2,1); plot(GEP1(year1==2006),GEP_all_red(year1==2006),'b.'); title('2006'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,1); plot(GEP2006_bavg(:,1),GEP2006_bavg(:,2),'ro');
subplot(2,2,2); plot(GEP1(year1==2007),GEP_all_red(year1==2007),'b.'); title('2007'); line([0 30],[0 30],'Color',[1 0 0],'LineWidth',3);
hold on; subplot(2,2,2); plot(GEP2007_bavg(:,1),GEP2007_bavg(:,2),'ro');
ylabel('modeled'); xlabel('real GEP')



%% Fill empty GEPs with modeled GEP
GEP1(isnan(GEP1)) = GEP_all_red(isnan(GEP1));

%% Clean Respiration and fill in values from the night that are good:
Resp_filled(1:length(dt1),1) = NaN;
%%% Nighttime value filled by model
Resp_filled(PAR1 < 10) = Resp1(PAR1 < 10);

%%% Nighttime with ustar > critical overwritten with measured NEE
Resp_filled(PAR1 < 10 & ustar1 >= 0.3 & ~isnan(NEE1)) = NEE1(PAR1 < 10 & ustar1 >= 0.3 & ~isnan(NEE1));

%%% Daytime Growing Season R with Model
Resp_filled(PAR1 >= 10 & dt1 >= 85 & dt1 <= 335) = Resp1(PAR1 >= 10 & dt1 >= 85 & dt1 <= 335);
% Resp(PAR > 10 & dt >= gsstart & dt <= gsend) = 25;
%%% All other times filled with model
%%% Daytime Non - Growing Season R with Model
Resp_filled(PAR1 >= 10 & (dt1 < 85 | dt1 > 335) & ~isnan(NEE1)) = NEE1(PAR1 >= 10 & (dt1 < 85 | dt1 > 335) & ~isnan(NEE1));


%%% Transpose and remove where Resp < 0
% Resp = Resp';
Resp_filled(Resp_filled < 0 | isnan(Resp_filled)) = Resp1(Resp_filled < 0 | isnan(Resp_filled));



%% Fill NEE
 ind_bn_NEE = find(PAR1 < 10 & (isnan(NEE1) | ustar1 < 0.3));
 NEE1(ind_bn_NEE) = Resp1(ind_bn_NEE);

 %%% Fill in data for outside of G.S. during the day
ind_nongs_NEE = find(PAR1 >= 10 & (isnan(NEE1) | ustar1 < 0.3) & (dt1 < 85 | dt1 > 335));
 NEE1(ind_nongs_NEE) = Resp1(ind_nongs_NEE);
 
 %%% Replace for day when values are missing
ind_gs_NEE = find(PAR1 >= 10 & (isnan(NEE1) | ustar1 < 0.3) & dt1 >= 85 & dt1 <= 335);
NEE1(ind_gs_NEE) = Resp1(ind_gs_NEE) - GEP_all_red(ind_gs_NEE);

%% Calculate final numbers:
Results(1:5,1:11) = NaN;
for mm = 2003:1:2007
    ctr_year = mm-2002;
    
NEE_yr = NEE1(year1==mm);
Resp_filled_yr = Resp_filled(year1==mm);
Resp_modeled_yr = Resp1(year1==mm);
GEP_filled_yr = GEP1(year1==mm);
GEP_modeled_yr = GEP_all_red(year1==mm);

output = [dt1(year1 == mm) -1*NEE_yr Resp_filled_yr GEP_filled_yr T_air1(year1 == mm) Ts1(year1 == mm) SM1(year1 == mm) PAR1(year1 == mm)];

save([path 'M' site 'output_model1_' num2str(mm) '.dat'],'output','-ASCII');
clear output;


sum_NEE = nansum(NEE_yr).*0.0216;
sum_Resp_filled = nansum(Resp_filled_yr).*0.0216;
sum_Resp_modeled = nansum(Resp_modeled_yr).*0.0216;
sum_GEP_filled = nansum(GEP_filled_yr).*0.0216;
sum_GEP_modeled = nansum(GEP_modeled_yr).*0.0216;

   used_NEE = length(find(isnan(NEE_yr)==0));
   used_Resp_filled = length(find(isnan(Resp_filled_yr)==0));
   used_Resp_modeled = length(find(isnan(Resp_modeled_yr)==0));
   used_GEP_filled = length(find(isnan(GEP_filled_yr)==0));
   used_GEP_modeled = length(find(isnan(GEP_modeled_yr)==0));
      
Results(ctr_year,:) = [mm sum_NEE          used_NEE           sum_Resp_filled   used_Resp_filled ...
                       sum_Resp_modeled used_Resp_modeled  sum_GEP_filled    used_GEP_filled ...
                       sum_GEP_modeled  used_GEP_modeled];      
   
   
   
    clear NEE_yr Resp_filled_yr Resp_modeled_yr GEP_filled_yr GEP_modeled_yr;
    clear used_NEE used_Resp_filled used_Resp_modeled used_GEP_filled used_GEP_modeled;
    clear sum_NEE sum_Resp_filled sum_Resp_modeled sum_GEP_filled sum_GEP_modeled

end

save([path 'M' site 'flux_results.dat'],'Results','-ASCII');

%% Prepare Output file to use in plotting variables and doing further
%% analysis

M1_output.GEP = GEP1; M1_output.R = Resp_filled; M1_output.NEE = NEE1; 
M1_output.GEP_PAR = GEP_PAR; M1_output.est_R = est_R; 
save ([path 'M' site '_output.mat'], 'M1_output');

% clear all 
