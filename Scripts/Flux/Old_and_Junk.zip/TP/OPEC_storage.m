function [] = OPEC_storage(year,site, flux_source, met_source)
%% CO2_storage.m
% This program calculates the changes in the amount of CO2 and heat stored beneath
% the OPEC sensor, using CO2 concentration and temperature measured at the top of the
% canopy, or measured at different points in the profile
% Created July 31, 2007 by JJB
% Inputs are year, site and input_loc
% input_loc is simply 'met' or 'flux' and specifies if raw files are coming
% from the met data or the flux data
% Dr. Arain -- Please use the 'flux' option
% Modified Feb 25, 2008 by JJB 
%       - included raw NEE calculation into function, so that only Met_SHF
%       and OPEC_storage have to be used before going to flux calculation
%       scripts.
%% Make Sure site and year are in string format
if ischar(site) == false
    site = num2str(site);
end
if ischar(year) == false
    year = num2str(year);
end

%% Declare Data Paths and Load Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%

flux_filled_path = (['C:\Home\Matlab\Data\Flux\OPEC\Filled4\Met' site '\Met' site '_' year '_']);

met_calc_path = (['C:\Home\Matlab\Data\Met\Calculated4\Met' site '\Met' site '_' year '_']);

%%% Output path
flux_calc_path = (['C:\Home\Matlab\Data\Flux\OPEC\Calculated5\Met' site '\Met' site '_' year '_']);

%%% Figure Path
fig_path = (['C:\HOME\MATLAB\Data\Flux\OPEC\Figs\Met' site '\Met' site '_' year '_']);

%% Load Variables

%%% Soil temperature
Ts = load ([met_calc_path 'Ts.dat']);

%%% dt
[junk(:,1) junk(:,2) junk(:,3) dt]  = jjb_makedate(str2double(year),30);

vars = jjb_flux_load('Storage', year, site, flux_source, met_source);
T_air = vars(:,1);
CO2_top = vars(:,2);
CO2_cpy = vars(:,3);

clear vars

if isequal(flux_source,'processed')==1 && isequal(site,'1')==0;
   Pres = load([flux_filled_path 'P_filled.dat']); 
elseif isequal(flux_source,'processed')==1 && isequal(site,'1')==1;
   Pres = load(['C:\HOME\MATLAB\Data\Flux\CPEC\Met1\HH_fluxes\Met1_' year '_pres_cl.dat']);    
else
Pres = load([flux_filled_path 'pres_cl.dat']);
end

%% Condition Data
%%% CO2 Conc. - Convert from ppm to mole fraction of dry air (mg/m^3)

%%% At met 2 for years 2002-2004 the top concentration is already reported
%%% in mgm-3
if isequal(flux_source,'master')==1 && (site=='2' || site == '3' || site == '4') && (strcmp(year,'2002')==1 || strcmp(year,'2003')==1 || strcmp(year,'2004')==1)
    CO2_top_mg = CO2_top;
else
CO2_top_mg = CO2_convert(CO2_top, T_air, Pres,1);
end
CO2_cpy_mg = CO2_convert(CO2_cpy, T_air, Pres,1);

% %%% CO2 Conc. - Convert from ppm to umol/mol
% CO2_top_mg = CO2_convert(CO2_top, T_air, Pres,1);
% CO2_cpy_mg = CO2_convert(CO2_cpy, T_air, Pres,1);

%% Clean CO2 mole fraction values
CO2_top_mg(CO2_top_mg < 580 | CO2_top_mg > 1200, 1) = NaN; 
CO2_cpy_mg(CO2_top_mg < 580 | CO2_top_mg > 1200, 1) = NaN; 

%%% Shift CO2_top data by one point and take difference to get dc/dt
%%% Also cuts off the extra data point that is created by adding NaN
c1top = [NaN; CO2_top_mg(1:length(CO2_top_mg)-1)];
c2top = [CO2_top_mg(1:length(CO2_top_mg)-1) ; NaN];
c1cpy = [NaN; CO2_cpy_mg(1:length(CO2_cpy_mg)-1)];
c2cpy = [CO2_cpy_mg(1:length(CO2_cpy_mg)-1) ; NaN];

%%% Shift Temperature data by one point and take difference to get dT/dt
%%% Also cuts off the extra data point that is created by adding NaN
T1top = [NaN; T_air(1:length(T_air)-1)];
T2top = [T_air(1:length(T_air)-1) ; NaN];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Set Value of z, ztop and zcpy 
%%%(ztop is distance btw cpy (Li-800) sensor and top (Li-7500) intakes)
%%%(zcpy is dist btw ground and cpy sensor)
param = params(year, site, 'CO2_storage');
z = param(:,1);     ztop = param(:,2);   zcpy = param(:,3);
col_flag = param(:,4);

%% Calculate CO2 storage in column below OPEC system: One-Height approach
%%%*** Note the output of this is in umol/mol NOT IN mg/m^3 ***********
dcdt = (c2top-c1top).*(z/1800).*(1000/44);  %% 1000/44 converts to umol/mol

%% Clean data (remove outliers (greater than +/- 10))
dcdt(dcdt < -10 | dcdt > 10 , 1) = NaN;

%%%Criteria consistent or make %them adjustable depending on site??

%% *********************************************************************

%%  2-Height CO2 approach
%%% **** SEE ABOVE FOR NOTE ON OUTPUT AS umol/mol m^-2s^-1
if col_flag == 2 % Calculate for the top and bottom halves
%%% top
    dcdt_top = (c2top-c1top).*(ztop/1800).*(1000/44);  %% 
%%% bottom
    dcdt_cpy = (c2cpy-c1cpy).*(zcpy/1800).*(1000/44);  %% 
elseif col_flag == 1;
    dcdt_top(1:length(dcdt),1) = NaN;
    dcdt_cpy(1:length(dcdt),1) = NaN;
end
%%% Add top and bottom storages
dcdt_2h = dcdt_top + dcdt_cpy;  %% 2-height storage in umol/mol m^-2s^-1

%% Clean and fill data (remove outliers (greater than +/- 10))
dcdt_2h(dcdt_2h < -10 | dcdt_2h > 10,1) = NaN;

%%% Replace NaN data from 2-height with 1-height data
ind_2h_nan = find(isnan(dcdt_2h)); 
ind_1h_nan = find(isnan(dcdt)); 

dcdt_2h(ind_2h_nan,1) = dcdt(ind_2h_nan,1);



%% Fill small gaps by linear interpolation

[dcdt_2h_fill] = jjb_interp_gap(dcdt_2h,dt, 3);
[dcdt_fill] = jjb_interp_gap(dcdt,dt, 3);

%% ******************** Add dcdt to FC to get raw NEE numbers:
%%% Load FC
vars = jjb_flux_load('Resp', year, site, flux_source, met_source);
T_air = vars(:,1);
PAR = vars(:,2);
FC = vars(:,3);

clear vars;

%% Convert FC to (umolCO2 m^-2 s^-1), and Calculate preliminary NEE [FC + dcdt]
%%% Convert FC from mg to umol on years when it has been recorded as mgm-3
if (site=='2' || site == '3' || site == '4') && ((strcmp(year,'2006')==1) ||  (strcmp(year,'2007')==1))
FC = CO2_convert(FC, T_air, Pres, 2);
end

% FC = CO2_convert(FC, T_air, Pres, 2);
%%% Temporarily make NaNs in dcdt file = 0 -- will want to model this later
dcdt_2h_fill(isnan(dcdt_2h_fill) & ~isnan(FC),1) = 0;
%%% Add FC and dcdt to get prelim NEE
NEE_uncut = FC + dcdt_2h_fill;
NEE_raw = NEE_uncut;

%% Clean NEE for obvious outliers
NEE_raw(NEE_raw < -35 | NEE_raw > 30, 1) = NaN;
NEE_raw(PAR <= 20 & NEE_raw <= 0, 1) = NaN;     % no photosynthesis at dark
NEE_raw(Ts <= 0 & NEE_raw <= 0, 1) = NaN;    % no photosynthesis when soil is frozen
% NEE_raw(PAR <= 20 & Ts <= 5 & NEE_raw >= 5, 1) = NaN;    % nighttime & low-temp respiration cap
NEE_raw(PAR <= 20 & NEE_raw >= 25, 1) = NaN;    % nighttime respiration cap

%% ****************************************************************
%% Heat Storage
dTdt = T1top-T2top;
Jt = 22.25.*0.6.*dTdt +1.66;    %% Blanken et al. (1997) 
%% ****************************************************************
%% SAVE Variables

%%% Raw dcdt in umol/mol m^-2s^-1
save ([flux_calc_path 'dcdt_raw.dat'],'dcdt','-ASCII');
%%% Filled dcdt in umol/mol m^-2s^-1
save ([flux_calc_path 'dcdt_cleaned.dat'],'dcdt_fill','-ASCII');

%%% Raw 2-height dcdt in umol/mol m^-2s^-1
save ([flux_calc_path 'dcdt_2h_raw.dat'],'dcdt_2h','-ASCII');
%%% Filled 2-height dcdt in umol/mol m^-2s^-1
save ([flux_calc_path 'dcdt_2h_cleaned.dat'],'dcdt_2h_fill','-ASCII');

%%% Filled CO2 concentrations
save ([flux_filled_path 'CO2mg_top_filled.dat'],'CO2_top_mg','-ASCII');
save ([flux_filled_path 'CO2mg_cpy_filled.dat'],'CO2_cpy_mg','-ASCII');

%%% Save NEEs 
save ([flux_calc_path 'NEE_raw.dat'],'NEE_raw','-ASCII');
save ([flux_calc_path 'NEE_uncut.dat'],'NEE_uncut','-ASCII');

%%% Heat Storage term
save ([flux_calc_path 'Jt.dat'],'Jt','-ASCII');

%% Plot Variables for inspection

%%% Figure 1 - CO2 concentrations 
figure (1)
plot(dt,CO2_top_mg, 'b');
hold on;
plot(dt,CO2_cpy_mg, 'r');
legend ('CO2 top', 'CO2 cpy');
title ('CO2 concentrations');
ylabel ('CO2 Conc (mg m^-^3)')
xlabel ('Day of Year');
axis([0 365 min(CO2_cpy_mg) max(CO2_top_mg)]);
print('-dill',[fig_path 'CO2_Conc']);
print('-dtiff',[fig_path 'CO2_Conc']);

%%% Figure 2 - Storage Comparisons

figure (2)
subplot(2,1,1)
hold on;
plot (dt,dcdt_2h_fill,'b')
plot (dt,dcdt_2h,'r')
legend ('Filled', 'Raw');
title ('CO2 storage (raw vs filled) 2-height');
ylabel ('CO2 Storage (mg m^-^2 s^-^1)')
axis([0 365 min(dcdt_2h_fill) max(dcdt_2h_fill)]);

subplot(2,1,2)
hold on;
plot (dt,dcdt_fill,'g')
plot (dt,dcdt_2h_fill,'b')
legend ('1-height', '2-height');
title ('CO2 storage (filled) 1-height vs 2-height');
ylabel ('CO2 Storage (mg m^-^2 s^-^1)');
xlabel ('Day of Year');
axis([0 365 min(dcdt_2h_fill) max(dcdt_2h_fill)]);
print('-dill',[fig_path 'CO2_Storage']);
print('-dtiff',[fig_path 'CO2_Storage']);
% subplot(3,1,2)
% hold on;
% plot (dcdtmg_fill,'r')
% plot (dcdtmg,'b')
% legend ('Filled', 'Raw');
% title ('CO2 storage (raw vs filled) 1-height');
% ylabel ('CO2 Storage (mg/m3/ms)');


figure(3)
plot(dt,NEE_uncut); hold on;
plot(dt,NEE_raw,'r');
title('raw NEE')
legend('uncut','cleaned');
axis([0 366 -30 30]); 