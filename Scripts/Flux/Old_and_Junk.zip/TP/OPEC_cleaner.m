function [] = OPEC_cleaner (year, site)
%% OPEC_cleaner.m
%%% Loads 10-minute sorted files (using OPEC_sort), cleans the data, and
%%% aggregates each variable into 30 minute averages.

%% *** delete
% year = 2008;
% site = 2;
changeflag = 0;
loadstart = addpath_loadstart;
%% Load master 10-min file for the year

load_dir = [loadstart 'Matlab/Data/Flux/OPEC/Organized2/' site '/Master/'];
master = load([load_dir  site '_10min_Master_' num2str(year) '.dat']);

col_out_path = [loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/' site '/Column/'];
filled_path = [loadstart 'Matlab/Data/Flux/OPEC/Filled4/' site '/' site '_' num2str(year) '_'];
master_out_path = [loadstart 'Matlab/Data/Flux/OPEC/Cleaned3/' site '/Master/'];

%%% Path for threshold file
thresh_path = [loadstart 'Matlab/Data/Flux/OPEC/Organized2/Docs/' site '_' num2str(year) '_thresh.dat'];

%% Load Header File
header = jjb_hdr_read([loadstart 'Matlab/Data/Flux/OPEC/Organized2/Docs/OPEC_header.csv'],',',2);

if exist(thresh_path);
    thresh = load(thresh_path);
    disp('loading threshold file');
else
    thresh(1:100,1:2) = NaN;
    disp('threshold file not found, using default')
    changeflag = 1;


%% ********************** REMOVING OBVIOUS OUTLIERS *****************
%% Establish default thresholds for visual removal of obvious outliers
thresh(1:4,1:2) = NaN;
thresh(5,1:2) =     [-3   3];     % FC_WPL
thresh(6,1:2) =     [-400  800];
thresh(7,1:2) =     [-600  1000];
thresh(8,1:2) =     [-400  800];
thresh(9,1:2) =    [0    7];
thresh(10,1:2) =    [0    4];
thresh (11:28,1) = -8 ;
thresh (11:28,2) = 10 ;
thresh(29,1:2) =    [-50   200];
thresh(30,1:2) =    [-20   20];
thresh(31:32,1) =    -5;
thresh(31:32,2) =     5;
thresh(33:34,1) =    -10;
thresh(33:34,2) =    10;
thresh(35,1:2) =    [-1   1];
thresh(36,1:2) =    [500   1200];
thresh(37,1:2) =    [0  60];

thresh(38:39,1) =    -50;
thresh(38:39,2) =    50;

thresh(40,1:2) =    [0.8   1.6];
thresh(41,1:2) =    [95   105];
thresh(42,1:2) =    [-30   60];
thresh(43,1:2) =    [0   360];
thresh(44,1:2) =    [-180   180];

thresh(45:46,1) =    0;
thresh(45:46,2) =    15;

thresh(47,1:2) =    [0   20];
thresh(48,1:2) =    [0   100];
thresh(49:60,1:2) =    NaN;
thresh(61,1:2) =    [-15   15];
thresh(62,1:2) =    [-400   800];
thresh(63:66,1:2) =    NaN;
thresh(67,1:2) =    [0   60];
thresh(68,1:2) =    [-50   50];
thresh(69:85,1:2) =    NaN;
thresh(86,1:2) =    [300  550];
thresh(87:100,1:2) =   NaN;
end
%% Clean outliers from data using thresholds

for loop = 1:1:100
    accept = 1;


    if ~isnan(thresh(loop,1))
        var_title = char(header(loop,2));
        figure (1)
        clf;
        plot(master(:,loop))
        hold on
        line([1 length(master)],[thresh(loop,1) thresh(loop,1)],'Color',[1 0 0], 'LineStyle','--')
        %plot([1 length(master)],[thresh(loop,1) thresh(loop,1)],'r-')
        line([1 length(master)],[thresh(loop,2) thresh(loop,2)],'Color',[1 0 0], 'LineStyle','--')
        axis([1 length(master) thresh(loop,1)-(2*abs(thresh(loop,1))) thresh(loop,2)+(2*abs(thresh(loop,2)))]);
        title([var_title ', column' num2str(loop)]);
        response = input('Press enter to accept, "1" to enter new thresholds, or any other key to reject: ', 's');
        %%% If user wants to change thresholds..
        if isequal(str2double(response),1)==1;
            accept = 0;
            while accept == 0;
                low_lim = input('enter new lower limit: ','s');
                thresh(loop,1) = str2double(low_lim);
                up_lim = input('enter new upper limit: ','s');
                thresh(loop,2) = str2double(up_lim);
                %%% plot again
                figure (1)
                clf;
                plot(master(:,loop))
                hold on
                line([1 length(master)],[thresh(loop,1) thresh(loop,1)],'Color',[1 0 0], 'LineStyle','--')
                line([1 length(master)],[thresh(loop,2) thresh(loop,2)],'Color',[1 0 0], 'LineStyle','--')
                axis([1 length(master) thresh(loop,1)-(2*abs(thresh(loop,1))) thresh(loop,2)+(2*abs(thresh(loop,2)))]);
                 title(var_title);
                accept_resp = input('hit enter to accept, 1 to change again: ','s');
                    if isempty(accept_resp)
                    accept = 1;
                    else
                    accept = 0;
                    end
            end

            changeflag = 1;
        end
        master(master(:,loop) > thresh(loop,2) | master(:,loop) < thresh(loop,1) ,loop) = NaN;
    end
end

%% Save threshold file (if it has been changed)
if changeflag ==1;
    save(thresh_path,'thresh','-ASCII');
else
end

%% ************************ Calculate 1/2 hourly averages for data

TV30 = make_tv(year,30);
[Yr JD HHMM dt]  = jjb_makedate(year,30);

master_30(1:length(TV30),1:100) = NaN;

master_30(1:length(TV30),1) = TV30;
master_30(1:length(TV30),2) = Yr;
master_30(1:length(TV30),3) = JD;
master_30(1:length(TV30),4) = HHMM;
master_30(1:length(TV30),5) = dt;

clear Yr JD HHMM;

for loop2 = 5:1:99
    %%% Reshape given column to group in 1/2hr segments
    rs_var = reshape(master(:,loop2),3,[]);
    HH_mean(1,1:length(rs_var)) = NaN;

    %%% Take NaNmean of each 1//2 hour segment
    for pq = 1:1:length(rs_var)
        HH_mean(1,pq) = nanmean(rs_var(:,pq));
    end

    %%% Put into column
    HH_mean = HH_mean';

    %%% Place into final 30-minute master file
    master_30(:,loop2+1) = HH_mean;

    clear rs_var HH_mean;
end

clear master;

%% *************** Perform additional necessary cleaning operations *******
%%% Fill pressure data, save a cleaned file
pressure = jjb_interp_gap(master_30(:,42), dt, 3);
save ([filled_path 'pres_cl.dat'],'pressure','-ASCII');
%%% Fill rest of periods with 99:
pressure(isnan(pressure)) = 99;
%%% Save pressure and temperature files to Filled directory
save ([filled_path 'P_filled.dat'],'pressure','-ASCII');

%%% Retreive best possible temperature measurement
T_best = master_30(:,39);
T_best(isnan(T_best),1) = master_30(isnan(T_best),40);

%% Calibrate CO2 concentrations before saving it to file
%%% Convert top CO2 measurement to ppm
CO2_top_ppm = CO2_convert(master_30(:,37),T_best,pressure,4);

%%% run calibration for top CO2 concentration
CO2_top_calib = OPEC_CO2_calibration(CO2_top_ppm, year, site,'top');
%%% run calibration for in-canopy CO2 concentration
CO2_cpy_calib = OPEC_CO2_calibration(master_30(:,87), year, site,'cpy');

%%% put calibrated data into master file
master_30(:,37) = CO2_top_calib;
master_30(:,87) = CO2_cpy_calib;

%% Save master 30-min file
save([master_out_path site '_30min_Master_' num2str(year) '.dat'],'master_30','-ASCII');



%% ****************  Export to Column Vectors

ext = create_label((1:1:100)',3);

%%% Save timevector file
save([col_out_path site '_HHdata_' num2str(year) '.' ext(1,:)],'TV30', '-ASCII','-DOUBLE');

for out_loop = 2:1:100
    var_out = master_30(:,out_loop);
    save([col_out_path site '_HHdata_' num2str(year) '.' ext(out_loop,:)],'var_out','-ASCII');

    clear var_out
end



