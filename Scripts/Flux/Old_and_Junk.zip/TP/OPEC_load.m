function [out, hdr] = OPEC_load(load_path)

% clear all
% close all



fid = fopen(load_path);

for i = 1:4
  tline = fgets(fid);
  star_junk = find(tline == ','); 
  cols = length(star_junk);
  %%% This loop writes a header file into cell format from the original
  %%% data file
  if i == 2
     hdr = cellstr(tline(1:star_junk(1)-1));
      for ctr = 2:1:cols
          hdr(ctr,1) = cellstr(tline(star_junk(ctr-1)+1:star_junk(ctr)-1));
      end
      hdr(cols+1,1) = cellstr(tline(star_junk(cols):length(tline))); 
  end
end

j = 1;
eofstat = 0;

while eofstat == 0;
    %%% Read line of data from file
    tline = fgets(fid);
    %%% Find commas
    star = find(tline == ',');
    %%% Write first column
    TS(j,:) = tline(1:star(1)-1);
    %%% Write middle columns
    out(j,1) = NaN;
    for ctr = 2:1:cols
    out(j,ctr) = str2double(tline(star(ctr-1)+1:star(ctr)-1));
    end
    %%% Write final column
    out(j,cols+1) = str2double(tline(star(cols):length(tline)));

    j = j+1;
    eofstat = feof(fid);

end
    
for k = 1:length(out)
    
year(k,1) = str2double(TS(k,2:5));  
month(k,1) = str2double(TS(k,7:8));
day(k,1) = str2double(TS(k,10:11));
HH(k,1) = str2double(TS(k,13:14));
MM(k,1) = str2double(TS(k,16:17));
end

%% Create TimeVector
Timevec(:,1) = JJB_DL2Datenum(year, month, day, HH, MM, 0);
out(:,1) = Timevec;



