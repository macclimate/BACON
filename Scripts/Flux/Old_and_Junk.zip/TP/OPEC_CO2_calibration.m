function [CO2_out] = OPEC_CO2_calibration(CO2_in, year, site, height)

%% Record the start and end dates of measurements, and the corresponding
%% calibration offsets:
%%% Make timevector
TV30 = make_tv(year,30);
%%% Round timevector
TV30 = (floor(TV30.*100000))./100000;
CO2_out = CO2_in;

switch site
    case 'TP39'
        switch year
            case 2002
            case 2003
            case 2004
            case 2005
            case 2006
            case 2007
        end
    case 'TP74'
        switch year
            case 2002
            case 2003
            case 2004
            case 2005
calibs_top = [JJB_DL2Datenum(2005,9,1100) JJB_DL2Datenum(2005,31,630) -0.8 ;...
          JJB_DL2Datenum(2005,94,1600) JJB_DL2Datenum(2005,120,830) 3.5 ;...
          JJB_DL2Datenum(2005,219,1000) JJB_DL2Datenum(2005,245,830) -3.2 ;...
          JJB_DL2Datenum(2005,302,1500) JJB_DL2Datenum(2005,333,930) -6.4];
calibs_cpy =    [JJB_DL2Datenum(2005,4,1800) JJB_DL2Datenum(2005,31,1030) -8.7 ;...
          JJB_DL2Datenum(2005,94,1600) JJB_DL2Datenum(2005,120,830) 0.1 ;...
          JJB_DL2Datenum(2005,219,1000) JJB_DL2Datenum(2005,245,830) 11.3 ;...
          JJB_DL2Datenum(2005,302,1500) JJB_DL2Datenum(2005,322,1300) 0];   
      
            case 2006
            case 2007
calibs_top = [JJB_DL2Datenum(2007,93,1120) JJB_DL2Datenum(2007,120,750) (359.7-359.94) ;...
          JJB_DL2Datenum(2007,207,800) JJB_DL2Datenum(2007,236,730) (366.3-367.75) ;...
          JJB_DL2Datenum(2007,302,1520) JJB_DL2Datenum(2007,365,2400) 1.71]; %% pro-rated from calibration done on Jan 13, 2008
      
calibs_cpy = [JJB_DL2Datenum(2007,93,1120) JJB_DL2Datenum(2007,120,750) (359.2-359.94) ;...
          JJB_DL2Datenum(2007,207,800) JJB_DL2Datenum(2007,236,730) (365.9-367.75) ;...
          JJB_DL2Datenum(2007,302,1520) JJB_DL2Datenum(2007,353,2400) 0];                
                
                
                
                
                
            %% NOTE: submit proper calibration numbers to 2008 data:
            case 2008   
                calibs_top = [JJB_DL2Datenum(2008,1,1) JJB_DL2Datenum(2008,13,1700) (369.8-367.75)] ;
%         JJB_DL2Datenum(2008,13,1730) JJB_DL2Datenum(2005,16,2300) 0];
        
                calibs_cpy = [JJB_DL2Datenum(2008,1,1) JJB_DL2Datenum(2008,13,1700) 0] ;
%         JJB_DL2Datenum(2008,13,1730) JJB_DL2Datenum(2005,16,2300) 0];
        end
    case 'TP89'
        switch year
            case 2002
            case 2003
            case 2004
            case 2005
            case 2006
            case 2007
calibs_top = [JJB_DL2Datenum(2007,120,1410) JJB_DL2Datenum(2007,152,800) (379.71-367.75) ;...
          JJB_DL2Datenum(2007,187,1130) JJB_DL2Datenum(2007,207,750) (368.2-367.75) ;...
          JJB_DL2Datenum(2007,274,1150) JJB_DL2Datenum(2007,302,1040) (365.6-367.75)]; %% pro-rated from calibration done on Jan 13, 2008
      
calibs_cpy = [JJB_DL2Datenum(2007,120,1410) JJB_DL2Datenum(2007,152,800) (356.4-367.75) ;...
          JJB_DL2Datenum(2007,187,1130) JJB_DL2Datenum(2007,207,750) (370.2-367.75) ;...
          JJB_DL2Datenum(2007,274,1150) JJB_DL2Datenum(2007,302,1040) 0];                
                
                           
                
                
                
        end
    case 'TP02'
        switch year
            case 2002
            case 2003
            case 2004
            case 2005
            case 2006
            case 2007
calibs_top = [JJB_DL2Datenum(2007,1,10) JJB_DL2Datenum(2007,90,1200) (363.52-359.94) ;...
          JJB_DL2Datenum(2007,152,1520) JJB_DL2Datenum(2007,185,750) (360.4-367.75) ;...
          JJB_DL2Datenum(2007,236,1410) JJB_DL2Datenum(2007,274,700) (368.7-367.75)]; %% pro-rated from calibration done on Jan 13, 2008
      
calibs_cpy = [JJB_DL2Datenum(2007,1,10) JJB_DL2Datenum(2007,90,1200) 0 ;...
          JJB_DL2Datenum(2007,152,1520) JJB_DL2Datenum(2007,185,750) (367.1-367.75) ;...
          JJB_DL2Datenum(2007,236,1410) JJB_DL2Datenum(2007,274,700) (372.9-367.75)];                     
                
            case 2008
                
calibs_top = [JJB_DL2Datenum(2008,1,1) JJB_DL2Datenum(2008,366,2330) (0) ]; %temporary set to 0 until real numbers put in.
      
calibs_cpy = [JJB_DL2Datenum(2008,1,1) JJB_DL2Datenum(2008,366,2330) (0) ]; %temporary set to 0 until real numbers put in.

                
        end
end

if strcmp(height, 'top') == 1;
    calibs = calibs_top;
elseif strcmp(height, 'cpy') == 1;
    calibs = calibs_cpy;
end

[rows_calibs cols_calibs] = size(calibs);

calibs(:,1) = (floor(calibs(:,1).*100000))./100000;
calibs(:,2) = (floor(calibs(:,2).*100000))./100000;

for i = 1:1:rows_calibs
   
    %%% Find intersection points
    start_TV = find(TV30 == calibs(i,1));
    end_TV = find(TV30 == calibs(i,2));
    
    len_calib = end_TV-start_TV+1;
    calib_incr = ((calibs(i,3)/len_calib):(calibs(i,3)/len_calib):calibs(i,3))';
    if isempty(calib_incr)
        calib_incr = 0;
    end
    CO2_in(start_TV:end_TV,1) = CO2_in(start_TV:end_TV,1)+calib_incr;
    
    
clear start_TV end_TV len_calib calib_incr;
end

CO2_out(~isnan(CO2_out),1) = CO2_in(~isnan(CO2_out),1);
