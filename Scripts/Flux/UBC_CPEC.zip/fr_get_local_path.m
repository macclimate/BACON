function [dataPth,hhourPth,databasePth] = FR_get_current_siteid
% Kai's universal fr_get_local_path returns path based on fr_current_siteid

dataPth  = 'c:\met-data\data\';
hhourPth  = 'c:\met-data\hhour\';
databasePth = 'c:\met-data\data\';
