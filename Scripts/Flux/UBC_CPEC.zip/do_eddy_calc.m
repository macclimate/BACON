function Stats_single = do_eddy_calc(EngUnits,miscVariables,configIN,SystemNum,currentDate)

%Revisions: 

            Stats_single = [];

            % STEP - Get misc. variables for calculations
            BarometricP = fr_get_BarometricP(miscVariables);
            Tair        = fr_get_mean_Tair(miscVariables);
            Krypton     = fr_get_Krypton_chan(configIN);
            
            % STEP - Get HF data
%            Eddy_HF_data = EngUnits(:,configIN.System(SystemNum).CovVector);           Replaced this line with
            Eddy_HF_data = EngUnits;                                                   % this one on Oct 24, 2002

            Eddy_HF_delay = configIN.System(SystemNum).Delays.Samples;
            
            
            % STEP - Calculate spikes, despike if selected
            [Spikes, Eddy_HF_data]  = fr_calc_spikes(Eddy_HF_data,configIN);    
            
            % STEP - Calculate Delay times
            % Delay time calc here (for co2, h2o, kh2o using w or T as the reference)
            %
            if length(Eddy_HF_data) > max(configIN.System(SystemNum).Delays.ArrayLengths)
                DelTimes = zeros(size(configIN.System(SystemNum).Delays.Channels));
                for Del_i = 1:length(configIN.System(SystemNum).Delays.Channels)
                    DelTimes(Del_i) = fr_delay( Eddy_HF_data(1:configIN.System(SystemNum).Delays.ArrayLengths(1),...
                        configIN.System(SystemNum).Delays.RefChan), ...
                        Eddy_HF_data(1:configIN.System(SystemNum).Delays.ArrayLengths(2),...
                        configIN.System(SystemNum).Delays.Channels(Del_i)),...
                        configIN.System(SystemNum).Delays.Span);
                    
               end
            end 
            
            % STEP - Overide delays to those just calculated
            if isfield(configIN.System(SystemNum).Delays, 'Overide') & configIN.System(SystemNum).Delays.Overide == 1;
               Eddy_HF_delay(configIN.System(SystemNum).Delays.Channels) = DelTimes;
            end
            
            
            % STEP - Do basic statistics and covariances
            EddyStats   = fr_calc_eddy(Eddy_HF_data, Eddy_HF_delay,...
                configIN.System(SystemNum).Rotation, BarometricP, Krypton,Tair);  
            
            % Add all fields to Stats_single
            fNames = fieldnames(EddyStats);
            for ifields = 1:length(fNames);
                Stats_single = setfield(Stats_single,{1},char(fNames(ifields)),getfield(EddyStats,char(fNames(ifields))));
            end
            %Stats_single = setfield(Stats_single,{1},'EddyStats',EddyStats);
            
            % STEP - Add spikes, delays field to Eddy_results
            Stats_single = setfield(Stats_single,{1},'Spikes',Spikes);
            Stats_single(1).Delays.Calculated = DelTimes;
            Stats_single(1).Delays.Implemented = configIN.System(SystemNum).Delays.Samples(configIN.System(SystemNum).Delays.Channels);
            
            %Stats_single = setfield(Stats_single,{1},['Delays.Calculated'],DelTimes);
            %Stats_single = setfield(Stats_single,{1},['Delays.Implemented'],...
            %    getfield(configIN.System(SystemNum).Delays.Samples(configIN.System(SystemNum).Delays.Channels)));
                        
            % STEP - Delay and Rotate the high frequency data before calculation of spectra and stationarity
            if configIN.Spectra.ON == 1 
                [Eddy_HF_data] = fr_rotatn_hf(Eddy_HF_data,[Stats_single.Three_Rotations.Angles.Eta ...
                        Stats_single.Three_Rotations.Angles.Theta Stats_single.Three_Rotations.Angles.Beta]);      
            end
            
            
            % STEP - Calculate stationarity
            if configIN.Stationarity.ON == 1 
                Stationarity_single   = fr_calc_stationarity(Eddy_HF_data, Eddy_HF_delay, configIN); 
                Stats_single = setfield(Stats_single,{1},'Stationarity',Stationarity_single);
            end
            
            % STEP - Calculate spectra
            if configIN.Spectra.ON == 1 
               configIN.Spectra.Fs = configIN.System(SystemNum).Fs; %set spectra calc frequency to that of system
                Spectra_single  = fr_calc_spectra(Eddy_HF_data, Eddy_HF_delay,configIN,[]); 
                Stats_single = setfield(Stats_single,{1},'Spectra',Spectra_single);
            end
   

                       
            %STEP - Add selected setup info to Eddy_results
            Stats_single = setfield(Stats_single,{1},'SourceInstrumentNumber',...
                getfield(configIN.System(SystemNum),'Instrument'));
            
            Stats_single = setfield(Stats_single,{1},'SourceInstrumentChannel',...
                getfield(configIN.System(SystemNum),'CovVector'));                                
            return
            
              
  

            % STEP - Calculate correction factors
            %Cfdeg_single   = fr_calc_cfdeg(Eddy_HF_data, Stats_all, c, currentDate);    
   
            % STEP - Store results
            %Stats_all = fr_cfdeg_add(currentDate,Cfdeg_single,c,Stats_all,c);   


%-----------------------------------------------------------------
function Stats_Out = eddy_calc_reorder_stats(Stats_In);     
    Stats_Out.MiscVariables.NumOfSamples = Stats_In.DataLen;
    Stats_Out.Zero_Rotations.Angles = Stats_In.Angles;
    Stats_Out.Zero_Rotations.Avg = Stats_In.BeforeRot.AvgMinMax(1,:);
    Stats_Out.Zero_Rotations.Min = Stats_In.BeforeRot.AvgMinMax(2,:);
    Stats_Out.Zero_Rotations.Max = Stats_In.BeforeRot.AvgMinMax(3,:);
    Stats_Out.Zero_Rotations.Std = Stats_In.BeforeRot.AvgMinMax(4,:);


%-----------------------------------------------------------------
function BarometricP = fr_get_BarometricP(miscVariables);
    if isfield(miscVariables,'BarometricP')
       BarometricP = miscVariables.BarometricP;
       if isnan(BarometricP) | abs(BarometricP) > 110 | abs(BarometricP) < 80;
          BarometricP = [];
       end
    else
        BarometricP = [];
    end

%-----------------------------------------------------------------
function Tair        = fr_get_mean_Tair(miscVariables)
    if isfield(miscVariables,'Tair')
       Tair = miscVariables.Tair;
       if isnan(Tair) | abs(Tair) == 0 ;
          Tair = [];
       end
    else
        Tair = [];
    end

%-----------------------------------------------------------------
function Krypton     = fr_get_Krypton_chan(configIN)
Krypton = [];


