function save_flux_more_days(dateRange,SiteFlag)

% Extract, save and plot fluxes for whole year
% (script assumes that there is a structure Stats in the workspace)
%
%To join daily data to creat an annual time series file type:
%save_flux_more_days(datenum(2005,01,01):datenum(2005,12,31))


% Example: save_flux_more_days(datenum(2003,09,01):datenum(2003,09,30))
%
% Altaf Arain, Dec 15, 2002
%

%day      = [31 28  31  30  31  30  31  31  30  31  30  31];
month    = [0 31 59  90 120 151 181 212 243 273 304 334 365];

NN = 365*48;

Fc = NaN * zeros(NN,1);
LE = NaN * zeros(NN,1);
H  = NaN * zeros(NN,1);
DelaysX = NaN * zeros(NN,2);
Timev = NaN * zeros(NN,1);
%**************************************************************************
%Natalia added this fields... 
WUE  = NaN * zeros(NN,1);
Penergy  = NaN * zeros(NN,1);
Htc1  = NaN * zeros(NN,1);
Htc2  = NaN * zeros(NN,1);
BrLicor  = NaN * zeros(NN,1);
Ustr  = NaN * zeros(NN,1);
CO2  = NaN * zeros(NN,1);
H2O  = NaN * zeros(NN,1);
Uz  = NaN * zeros(NN,1);
Ux  = NaN * zeros(NN,1);
Uy  = NaN * zeros(NN,1);
StdUz = NaN * zeros(NN,1);
WindDir = NaN * zeros(NN,1);

if ~exist('SiteFlag') | isempty(SiteFlag)
    SiteFlag = fr_current_siteid;
end
configIn  = fr_get_init(SiteFlag,dateRange(1))  % get the ini file

for dateIn = floor(dateRange)
%    try
        t0 = now;
        [yearX,monthX,dayX ] = datevec(dateIn)

        %hhours = 48
        %currentDate = datenum(yearX,monthX,dayX,0,30:30:30*hhours,0)
        FileName_p      = FR_DateToFileName(dateIn+.2)
        FileName        = [configIn.hhour_path FileName_p(1:6) configIn.hhour_ext]    % File name for the full set of stats
       
        load(FileName)
       
FileNameLE      = ['c:\met-data\daily\LE' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameHs      = ['c:\met-data\daily\Hs' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameHtc1    = ['c:\met-data\daily\Htc1' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameHtc2    = ['c:\met-data\daily\Htc2' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameFc      = ['c:\met-data\daily\Fc' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameBrLicor = ['c:\met-data\daily\BrLicor' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameWUE     = ['c:\met-data\daily\WUE' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameUstr    = ['c:\met-data\daily\ustr' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNamePenergy = ['c:\met-data\daily\Penergy' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameHRcoef  = ['c:\met-data\daily\HRcoef' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameDelaysX = ['c:\met-data\daily\DelaysX' FileName_p(1:2) '.dat' ]    % File name for the full set of stats

FileNameCO2 = ['c:\met-data\daily\CO2' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameH2O = ['c:\met-data\daily\H2O' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameUx = ['c:\met-data\daily\Ux' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameUy = ['c:\met-data\daily\Uy' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameUz = ['c:\met-data\daily\Uz' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameStdUz = ['c:\met-data\daily\StdUz' FileName_p(1:2) '.dat' ]    % File name for the full set of stats
FileNameWindDir = ['c:\met-data\daily\WindDir' FileName_p(1:2) '.dat' ]    % File name for the full set of stats

N = length(Stats);
for i=1:N,
    try 
        Timev(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).TimeVector;
    end;
        end;
for i=1:N,
    try 
        LE(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.LE_L;
    end;
    end;
for i=1:N,
    try 
        H(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Hs;
    end;
    end;
for i=1:N,
    try 
        Htc1(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Htc1;
    end;
    end;
for i=1:N,
    try 
        Htc2(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Htc2;
    end;
    end;
for i=1:N,
    try 
        Fc(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Fc;
    end;
end;
for i=1:N,
    try 
        B_L(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.B_L;
    end;
end;
for i=1:N,
    try 
        B_K(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.B_K;
    end;
end; 
for i=1:N,
    try 
        WUE(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.WUE;
    end;
end;
for i=1:N,
    try 
        Ustr(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Ustar;
    end;
end;
for i=1:N,
    try 
        Penergy(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.Penergy;
    end;
end;
for i=1:N,
    try 
        HRcoef(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.HR_coeff;
    end;
end;
for i=1:N,
    try 
        BarometricP(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MiscVariables.BarometricP;
    end;
end;
for i=1:N,
    try 
        Tair(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).MiscVariables.Tair;
    end;
end;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:N,
    try 
        DelaysX(i+((dayX-1)*N)+(month(monthX)*N),:) = Stats(i).MainEddy.Delays.Calculated;
    end;
end;
%**************************************************************************
k=1;
for i=1:N,
    try 
        CO2(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).Instrument(1).Avg(1,k);
    end;
end;
k=2;
for i=1:N,
    try 
        H2O(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).Instrument(1).Avg(1,k);
    end;
end;
k=1;
for i=1:N,
    try 
        Ux(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).Instrument(2).Avg(1,k);
    end;
end;
k=2;
for i=1:N,
    try 
        Uy(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).Instrument(2).Avg(1,k);
    end;
end;
k=3;
for i=1:N,
    try 
        Uz(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).Instrument(2).Avg(1,k);
    end;
end;
k=3;
for i=1:N,
    try 
        StdUz(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).Instrument(2).Std(1,k);
    end;
end;
for i=1:N,
    try 
        WindDir(i+((dayX-1)*N)+(month(monthX)*N)) = Stats(i).Instrument(2).MiscVariables.WindDirection;
    end;
end;
end % of for dateIn loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%% Save data as time series %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save(FileName,'Stats');
save(FileNameLE, 'LE', '-ASCII')        
save(FileNameHs,  'H', '-ASCII')
save(FileNameHtc1, 'Htc1', '-ASCII')
save(FileNameHtc2, 'Htc2', '-ASCII')
save(FileNameFc, 'Fc', '-ASCII')
%save(FileNameBrLicor, 'B_L', '-ASCII')
save(FileNameWUE, 'WUE', '-ASCII')
save(FileNameUstr, 'Ustr', '-ASCII')
save(FileNamePenergy, 'Penergy', '-ASCII')
%save(FileNameHRcoef, 'HRcoef', '-ASCII')
save(FileNameDelaysX, 'DelaysX', '-ASCII')

save(FileNameCO2, 'CO2', '-ASCII')
save(FileNameH2O, 'H2O', '-ASCII')
save(FileNameUx, 'Ux', '-ASCII')
save(FileNameUy, 'Uy', '-ASCII')
save(FileNameUz, 'Uz', '-ASCII')
save(FileNameStdUz, 'StdUz', '-ASCII')
save(FileNameWindDir, 'WindDir', '-ASCII')

%%%%%%%%%%% Plot Files for Visula Inspection %%%%%%%%%%%%%%%%%%%%%%%
figure(1);plot([H LE],'-o');legend('H','LE');
figure(2);plot([Fc],'o-');legend('Fc');
figure(3);plot([DelaysX]);legend('DelaysX');
figure(4);plot([Htc1 Htc2],'-o');legend('Htc1','Htc2');
%figure(5);plot([B_L],'-o');legend('B_L');
figure(6);plot([WUE],'-o');legend('WUE');
figure(7);plot([Ustr],'-o');legend('Ustr');
figure(8);plot([Penergy],'-o');legend('Penergy');

figure(9);plot([H2O],'-o');legend('H2O');
figure(10);plot([CO2],'-o');legend('CO2');
figure(11);plot([Ux Uy],'-o');legend('Ux');
figure(12);plot([Uz],'-o');legend('Uy');
figure(13);plot([StdUz],'-o');legend('StdUy');
figure(14);plot([WindDir],'-o');legend('WindDir');