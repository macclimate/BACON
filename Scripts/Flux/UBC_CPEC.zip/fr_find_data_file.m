function [fullFileName,fileName] = fr_find_data_file(dateIn,configIn,instrumentNum)
% fr_find_data_file - returns a full file name if file exists, empty if not
% 
% This function is used to confirm existance and find the full path of a UBC
% data file. It returns an empty matrix if the file does not exist. It needs
% the standard UBC ini file.
%
% Inputs:
%   dateIn      - datenum (this is not a vector, only one file is read at the time)
%   configIn    - standard UBC ini file
%   systemNum   - system number (see the ini file)
%   instrumentNum - instrument number (see the ini file)
%
% Outputs:
%   fullFileName- file name with path if file exists, empty if file is missing
%   fileName    - file name without the path 
%
%
% (c) Zoran Nesic           File created:       Sep 26, 2001
%                           Last modification:  Oct  8, 2002

% Revisions
%  Oct 8, 2002 - allowed a database file to be found with this procedure


if strcmp(upper(configIn.Instrument(instrumentNum).FileType), 'DATABASE')
    pth = configIn.database_path;
    yr = datevec(dateIn);
    fileName = fullfile(num2str(yr(1)), configIn.site, ...
        configIn.Instrument(instrumentNum).FileID);
    fullFileName = fullfile(pth, fileName);    
    if exist(fullFileName)~= 2
        fullFileName = [];
    end
    
else
    pth = configIn.path;
    fileName = FR_DateToFileName(dateIn);
    FileID = configIn.Instrument(instrumentNum).FileID;
    fileName = [fileName configIn.ext FileID];
    fullFileName = fullfile(pth,fileName);
    if exist(fullFileName)~= 2
        pth = [pth fileName(1:6) '\'];
        fullFileName = fullfile(pth,fileName);
        if exist(fullFileName)~= 2
            fullFileName = [];
        end
    end
end

