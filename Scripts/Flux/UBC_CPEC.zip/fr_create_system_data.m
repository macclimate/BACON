function  [EngUnits,miscVariables,Instrument] = fr_create_system_data(configIn,systemNum,Instrument_data,miscVariables);
%
%
%
% (c) Zoran Nesic               File created:       Oct   , 2001
%                               Last modification:  Feb 10, 2004

% Revisions
% Feb 10, 2004
%   -   Added output structure Instrument to pass the alignment info to the
%   caller function
%
%  Jun 27, 2002 - removed the Instrument.ProcessData part from here to fr_read_and_convert.m
%  July 7, 2003 - fr_instrument_align now takes multiple instruments (no changes to this program)
%  Aug 29, 2003 - allow alignment info to pass into miscVariables structure

% Resample data if needed
Instrument_data = fr_instrument_resample(configIn,systemNum,Instrument_data);

% Align data
Instrument_data = fr_instrument_align(configIn,systemNum,Instrument_data);

% Run extra conversions (example: open path IRGA conversion to mixing ratios)
if isfield(configIn.System(systemNum),'ProcessData') ...
          & ~isempty(configIn.System(systemNum).ProcessData)
    for j=1:length(configIn.System(systemNum).ProcessData)
        eval(char(configIn.System(systemNum).ProcessData(j)));
    end
end

% Create a data matrix
EngUnits = [];
for currentInstrument = configIn.System(systemNum).Instrument              % cycle for each instrument in the system
    EngUnits = [EngUnits Instrument_data(currentInstrument).EngUnits];     % append each individual instrument
end

% Extract only channels needed for Eddy calculations
EngUnits = EngUnits(:,configIn.System(systemNum).CovVector);

% Zoran: Nov 7, 2003 -> added try/catch structure
% Zoran: Feb 10, 2004 -> created a stand alone Instrument() structure (used
% to go under miscVariables.Instrument()
for i = 1:length(Instrument_data);
    try
        Instrument(i).Alignment = Instrument_data(i).Alignment;
    catch
        Instrument(i).Alignment = []; 
    end
end;

