% extract and plot fluxes
% (script assumes that there is a structure Stats in the workspace)

N = length(Stats);

k=1;
LE = NaN * zeros(N,1);
for i=1:N,
    try 
        LE(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=2;
H = NaN * zeros(N,1);
for i=1:N,
    try 
        H(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=3;
Htc1 = NaN * zeros(N,1);
for i=1:N,
    try 
        Htc1(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=4;
Htc2 = NaN * zeros(N,1);
for i=1:N,
    try 
        Htc2(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=5;
Fc = NaN * zeros(N,1);
for i=1:N,
    try 
        Fc(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;


k=7;
BRlicor = NaN * zeros(N,1);
for i=1:N,
    try 
        BRlicor(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=8;
WUE= NaN * zeros(N,1);
for i=1:N,
    try 
        WUE(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=9;
ustr = NaN * zeros(N,1);
for i=1:N,
    try 
        ustr(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=10;
PE = NaN * zeros(N,1);
for i=1:N,
    try 
        PE(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=11;
HRcoef = NaN * zeros(N,1);
for i=1:N,
    try 
        HRcoef(i) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=2;
DelaysX = NaN * zeros(N,2);
for i=1:N,
    try 
        DelaysX(i,:) = Stats(i).MainEddy.Delays.Calculated;
    end;
end;


figure(1);plot([H LE]); legend('H','LE');
figure(2);plot([Htc1 Htc2]); legend('Htc1','Htc2');
figure(3);plot([Fc]); legend('Fc');
% figure(4);plot([B_L]); legend('B_L');
figure(5);plot([WUE]); legend('WUE');
figure(6);plot([ustr]); legend('ustr');
figure(7);plot([PE]); legend('PE');
figure(8);plot([HRcoef]); legend('HRcoef');
figure(9);plot([DelaysX]); legend('DelaysX');