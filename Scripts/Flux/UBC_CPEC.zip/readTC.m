function x = readTC(fileName)

% x = readTC(fileName) - function that reads Fine Wire Thermocouple ASCIII data (set to 2 clumns separated by a comma)
%
% Inputs:
%   fileName    -   full file name (path and everything)
% Outputs:
%   ttc         -   matrix of 2 column 
%                   Temperature is in deg C
%
%
% (c) Zoran Nesic           File created:   May 13, 2002
%                           Last revision:  May 16, 2002
%     Altaf Arain           Last revision:  May 26, 2002


%%% Note: FWTC data is being logged at 21.3 Hz


% Read data
[x1 x2]= textread(fileName,'%n%n%*[^\n]','delimiter',',');
%[x1 x2]= textread(fileName,'','delimiter',',');

% Correct if the first line is incomplete
if x2(1)==0
    offsetStart = 2;
else
    offsetStart = 1;
end
% Correct if the last line is incomplete
offsetEnd = length(x2);

x1 = x1(offsetStart:offsetEnd);
x2 = x2(offsetStart:offsetEnd);

x = [x1 x2];