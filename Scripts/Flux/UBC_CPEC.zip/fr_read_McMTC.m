function [x,dummy] = fr_read_McMreadTC(dateIn,configIn,instrumentNum)

% function that reads Fine Wire Thermocouple ASCIII data (set to 2 clumns separated by a comma)
%
% Inputs:
%
% Outputs:
%   ttc         -   matrix of 2 column 
%                   Temperature is in deg C
%
%
% (c) Zoran Nesic           File created:   May 13, 2002
%                           Last revision:  Oct 24, 2002


%     Altaf Arain           Last revision:  May 26, 2002


%%% Note: FWTC data is being logged at 21.3 Hz

pth = configIn.path;
dateStr = FR_DateToFileName(dateIn);
fileName = ['TC' dateStr(1:8) '.bin'];
fullFileName = fullfile(pth,fileName);
if exist(fullFileName)~= 2
     pth = [pth fileName(1:6) '\'];
     fullFileName = fullfile(pth,fileName);
     if exist(fullFileName)~= 2
         fullFileName = [];
     end
end
% Read data
[x1 x2]= textread(fullFileName,'%n%n%*[^\n]','delimiter',',');
%[x1 x2]= textread(fileName,'','delimiter',',');

% Correct if the first line is incomplete
if x2(1)==0
    offsetStart = 2;
else
    offsetStart = 1;
end
% Correct if the last line is incomplete
offsetEnd = length(x2);

x1 = x1(offsetStart:offsetEnd);
x2 = x2(offsetStart:offsetEnd);

dummy = [];
x = [x1 x2];