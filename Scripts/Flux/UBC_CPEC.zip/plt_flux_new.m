% extract and plot fluxes
% (script assumes that there is a structure Stats in the workspace)

N = length(Stats);

 Timev = NaN * zeros(N,1);
for i=1:N,
    try 
        Timev(i) = Stats(i).TimeVector;
    end;
        end;
        

LE = NaN * zeros(N,1);
for i=1:N,
    try 
        LE(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.LE_L;
    end;
    end;


H = NaN * zeros(N,1);
for i=1:N,
    try 
        H(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Hs;
    end;
    end;


Htc1 = NaN * zeros(N,1);
for i=1:N,
    try 
        Htc1(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Htc1;
    end;
    end;


Htc2 = NaN * zeros(N,1);
for i=1:N,
    try 
        Htc2(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Htc2;
    end;
    end;


Fc = NaN * zeros(N,1);
for i=1:N,
    try 
        Fc(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Fc;
    end;
    end;


B_L = NaN * zeros(N,1);
for i=1:N,
    try 
        B_L(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.B_L;
    end;
    end;

    B_K = NaN * zeros(N,1);
for i=1:N,
    try 
        B_K(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.B_K;
    end;
end; 

WUE= NaN * zeros(N,1);
for i=1:N,
    try 
        WUE(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.WUE;
    end;
    end;

ustr = NaN * zeros(N,1);
for i=1:N,
    try 
        ustr(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.Ustar;
    end;
    end;

PE = NaN * zeros(N,1);
for i=1:N,
    try 
        PE(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.Penergy;
    end;
    end;

HRcoef = NaN * zeros(N,1);
for i=1:N,
    try 
        HRcoef(i) = Stats(i).MainEddy.Three_Rotations.AvgDtr.Fluxes.MiscVariables.HR_coeff;
    end;
    end;
    
 BarometricP = NaN * zeros(N,1);
for i=1:N,
    try 
        BarometricP(i) = Stats(i).MiscVariables.BarometricP;
    end;
     end;
     
 Tair = NaN * zeros(N,1);
for i=1:N,
    try 
        Tair(i) = Stats(i).MiscVariables.Tair;
    end;
        end;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DelaysX = NaN * zeros(N,2);
for i=1:N,
    try 
        DelaysX(i,:) = Stats(i).MainEddy.Delays.Calculated;
    end;
    end;


figure(1);plot([H LE]); legend('H','LE');
figure(2);plot([Htc1 Htc2]); legend('Htc1','Htc2');
figure(3);plot([Fc]); legend('Fc');
figure(4);plot([B_L]); legend('B_L');
figure(5);plot([WUE]); legend('WUE');
figure(6);plot([ustr]); legend('ustr');
figure(7);plot([PE]); legend('PE');
figure(8);plot([HRcoef]); legend('HRcoef');
figure(9);plot([DelaysX]); legend('DelaysX');