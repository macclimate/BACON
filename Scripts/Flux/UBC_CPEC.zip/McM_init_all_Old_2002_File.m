%===============================================================
function c = McM_init_all(dateIn)
%===============================================================
%
% (c) Zoran Nesic           File created:       Oct 22, 2002
%                           Last modification:  Oct 22, 2002
%

%
%   Revisions:

%

Dates    = zeros(1,100);
% All times are GMT
Dates(1) = datenum(2002,4,1,0,30,0);                     % system set up

% The following line needs to be changed when dateIn becomes datenum (not a string yyyymmddQQ)
dateIn = datenum(str2num(dateIn(1:4)),str2num(dateIn(5:6)),str2num(dateIn(7:8)),str2num(dateIn(9:10))/96*24,0,0);

%-------------------------------
% Common 
%-------------------------------
c.PC_name       = fr_get_pc_name;
[c.path,c.hhour_path] = fr_get_local_path;
c.ext           = '.dMcM';
c.hhour_ext     = '.hMcM.mat';
c.site          = 'McM';


% Instrument numbers in the order of their dependency
% (independent first)

nIRGA = 1;      % LI-7000 IRGA
%nCR10 = 2;      % CR10 logger
%nTC   = 3;       % Thermocouple measurements
nCSAT = 2;      % Sonic CSAT (depends on IRGA)

%nPb   = 3;      % barometric pressure (from LI-7500)


% Variables listed within this section will become part of the
% output stats
c.MiscVariables(1).Name             = 'BarometricP';
c.MiscVariables(1).Execute          = {'miscVar = 101.3;'};                 % use constant barometric pressure of 101.3 kPa, correct fluxes 
                                                                            % when correct pressure available

%c.MiscVariables(1).Execute          = {['nPb = ' num2str(nPb) ';'],...
%                                       'miscVar = mean(Instrument_data(nPb).EngUnits);'};

%------------------------------------------------
% All instruments
%------------------------------------------------
%-----------------------
% IRGA #1 definitions:
%-----------------------
c.Instrument(nIRGA).Name      = 'EC IRGA';
c.Instrument(nIRGA).Type      = '7000';
c.Instrument(nIRGA).SerNum    = 0;
c.Instrument(nIRGA).FileID    = '4';
c.Instrument(nIRGA).FileType  = 'McMLI7000';            % 
c.Instrument(nIRGA).Fs         = 20;               % Frequency of sampling
c.Instrument(nIRGA).Oversample = 6;                     % 
%c.Instrument(nIRGA).Oversample = 61;                     % 
c.Instrument(nIRGA).ChanNumbers = [1:6];                % chans to read from the Instrument(nIRGA)
c.Instrument(nIRGA).NumOfChans = length(c.Instrument(nIRGA).ChanNumbers);
c.Instrument(nIRGA).ChanNames = {'co2'      ,'h2o'     ,'P_irga', 'T_irga','T_sonic','T_sonic_raw'};
c.Instrument(nIRGA).ChanUnits = {'umol/mol' ,'mmol/mol','kPa'   ,'degC'   ,'degC'   ,'mV'};
c.Instrument(nIRGA).CovChans  = [1 2];
c.Instrument(nIRGA).Delays.Samples = [5 5];
c.Instrument(nIRGA).Alignment.Type = 'Slave';               % this instrument (Slave) will be aligned with the Master
c.Instrument(nIRGA).Alignment.ChanNum = 5;                  % chanel used for the alignment

%-----------------------
% TC definitions:
%-----------------------
%c.Instrument(nTC).Name          = 'Thermocouples';
%c.Instrument(nTC).Type          = 'E';
%c.Instrument(nTC).SerNum        = 0;
%c.Instrument(nTC).FileID        = '6';
%c.Instrument(nTC).FileType      = 'McMTC';               % 
%c.Instrument(nTC).Fs            = 20;                    % Frequency of sampling
%c.Instrument(nTC).Oversample    = 6;                     % 
%c.Instrument(nTC).ChanNumbers   = [1:2];                 % chans to read from the Instrument(nIRGA)
%c.Instrument(nTC).NumOfChans    = length(c.Instrument(nTC).ChanNumbers);
% c.Instrument(nTC).ChanNames     = {'Tc1'      ,'Tc2' };
% c.Instrument(nTC).ChanUnits     = {'degC'     ,'degC'};
% c.Instrument(nTC).CovChans      = [];
% c.Instrument(nTC).Delays.Samples = [0 0];
% c.Instrument(nTC).Alignment.Type = 'Slave';               % this instrument (Slave) will be aligned with the Master
% c.Instrument(nTC).Alignment.ChanNum = 5;                  % chanel used for the alignment



%-----------------------
% Sonic #1 definitions:
%-----------------------
c.Instrument(nCSAT).Name       = 'EC Anemometer';
c.Instrument(nCSAT).Type       = 'CSAT3';
c.Instrument(nCSAT).SerNum     = 0;
c.Instrument(nCSAT).FileType   = 'McMCSAT3';        %
c.Instrument(nCSAT).FileID     = '5';               % String!
c.Instrument(nCSAT).Fs         = 20;                % Frequency of sampling
c.Instrument(nCSAT).Oversample = 6;                % 
%c.Instrument(nCSAT).Oversample = 60;                % 
c.Instrument(nCSAT).ChanNumbers = [1:5];            % chans to read from
c.Instrument(nCSAT).NumOfChans = length(c.Instrument(nCSAT).ChanNumbers);
c.Instrument(nCSAT).ChanNames  = {'u2','v2','w2','Ts2','diag'};
c.Instrument(nCSAT).ChanUnits  = {'m/s','m/s','m/s','degC','1'};
c.Instrument(nCSAT).Delays.Samples = [0 0 0 0];
c.Instrument(nCSAT).ProcessData = [];
c.Instrument(nCSAT).CovChans   = [1 2 3 4];
c.Instrument(nCSAT).Orientation= 0;                   % degrees from North 
c.Instrument(nCSAT).Alignment.Type = 'Master';        % all instruments get aligned to this instrument (Master)
c.Instrument(nCSAT).Alignment.ChanNum = 4;            % chanel used for the alignment




% Space to add hooks for the programs that can be called from the main calc program
c.ExtraCalculations.InstrumentLevel = {};               % add all the extra calculations (Matlab statements as cells)
                                                        % that one wants performed on the instrument data
c.ExtraCalculations.SystemLevel = {};                   % add all the extra calculations (Matlab statements as cells)
                                                        % that one wants performed on the System data

%------------------------------------------------
% Eddy system 1
%
%------------------------------------------------
nMainEddy = 1;
c.System(nMainEddy).ON 				= 1;                         % system #1 calculations are ON
c.System(nMainEddy).Type            = 'Eddy';                   % eddy correlation system
c.System(nMainEddy).Name            = 'Tower EC, McM site';     % long system name
c.System(nMainEddy).FieldName       = 'MainEddy';               % this is the output structure field name for all the system stats
c.System(nMainEddy).Rotation        = 'three';                  % do three rotations
c.System(nMainEddy).Fs              = 20;                       % sampling freq. for the system (data will be resampled to
                                                                % match this frequency if needed)
c.System(nMainEddy).Instrument      = [ nCSAT nIRGA ];          % select instruments (Anemometer + IRGA) for system 1
% removed, see below  c.System(1).MaxColumns      = 4+2;                      % Sonic + IRGA + TCs + (KH2O + Misc)
c.System(nMainEddy).MaxFluxes       = 15;
c.System(nMainEddy).MaxMisc         = 15;
c.System(nMainEddy).CovVector = [];                             % create CovVector and Delays vectore 
c.System(nMainEddy).Delays.Samples = [];                        % based on the intrument setup
c.System(nMainEddy).Delays.RefChan = 4;                         % Delays calculated against this channel (T sonic)
c.System(nMainEddy).Delays.ArrayLengths = [5000 5000];          % the num of points used [ RefChan  DelayedChan]
c.System(nMainEddy).Delays.Span = 100;                          % max LAG (see fr_delay.m)
c.System(nMainEddy).Delays.Channels = [5 6];                    % Delays calculated on channels 5 and 6 (CO2 and H2O) 
c.System(nMainEddy).ProcessData = {};
totalChans = 0;
for i=1:length(c.System(1).Instrument)
    nInstrument = c.System(1).Instrument(i);
    c.System(1).CovVector       = [ c.System(1).CovVector ...
                                            c.Instrument(nInstrument).CovChans + totalChans ];
    c.System(1).Delays.Samples  = [ c.System(1).Delays.Samples  c.Instrument(nInstrument).Delays.Samples];
    totalChans                  = totalChans + c.Instrument(nInstrument).NumOfChans;
end
c.System(1).MaxColumns = totalChans;



