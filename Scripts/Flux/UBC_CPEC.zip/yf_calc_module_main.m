function [Stats_New,HF_Data] = yf_calc_module_main(tv_calc,SiteFlag,ExportFlag);
%
% UBC's main NEE system calculation function
%
% ~isempty(ExportFlag) - the program should only do conversions to eng units. 
%                      This option is to be used when only HF data plotting is needed
%
%
%
% (c) Zoran Nesic           File created:             , 2001
%                           Last modification:  Feb 10, 2004
%

%Revisions
% Feb 10, 2004
%   - moved adding of MiscVariables to Stats_New into the loop to enable
%   the changes of MiscVariables that happen in the "ProcessData" stage to
%   get updated in the Stats_New.MiscVariables.

% March 26, 2003:  place the Configuration data only in Stats(1)
% April 15, 2003:  put date as a field in configIn
% April 23, 2003:  added if ~isempty(extraCalculations); end; lines in to avoid errors when extra calcs are 
%                    off in init file
% May 25, 2003: initiated different way to determine the number of extraCalculation entries to process

% make sure you call fr_set_site if needed!!
if ~exist('SiteFlag') | isempty(SiteFlag)
    SiteFlag        = fr_current_SiteID;                % Get current site ID
end

if ~exist('ExportFlag') 
    ExportFlag        = [];                           % No plotting is a default
end

hhours          = length(tv_calc);                  % calculate the number of hhours
tv_calc         = fr_round_hhour(tv_calc,2);        % Round to end of hhours
configIn        = fr_get_init(SiteFlag,tv_calc(1)); % Get the configuration file

%Initialize results' structure
%Stats = fr_stats_init_main(configIn,tv_calc);       % 
Stats_New = [];
HF_Data = [];

for i = 1:hhours
    try
    t0 = now;
    currentDate = tv_calc(i);                       % hhour to calculate
    Stats_New = setfield(Stats_New,{i},'TimeVector',currentDate);% 
    Stats_New = setfield(Stats_New,{i},'RecalcTime',now);% 
    configIn  = fr_get_init(SiteFlag,currentDate);  % get the ini file
    %Revision: place the Configuration data only in Stats(1) March 26, 2003
    if i == 1;
       Stats_New = setfield(Stats_New,{i},'Configuration',configIn);
    end
    
    
    nSystems        = length(configIn.System);      % the numer of systems to work on
    nInstruments    = length(configIn.Instrument);  % the numer of instruments to work on


    % STEP - Load and Convert all Instruments to Eng.Units 
    Instrument_data = fr_read_and_convert(currentDate, configIn);

    % STEP - Calculate Avg, Min, Max & Std for all instruments
    Instrument_stats = fr_calc_instrument_stats(Instrument_data, configIn);
    for j = 1:nInstruments
        Stats_New = setfield(Stats_New,{i},'Instrument',{j},Instrument_stats(j));
    end

    % STEP - Create misc. variables (see ini file)
    miscVariables = fr_create_miscVariables(configIn,Instrument_data);
    
    % Zoran, Feb 10, 2004 moved this into the j=1:nSystem loop (see below)
    % Stats_New = setfield(Stats_New,{i},'MiscVariables',miscVariables);   

    % STEP - Prepare high-freq. data for export if that option is selected 
    if ~isempty(ExportFlag)
        for j = 1:nInstruments
            HF_Data = setfield(HF_Data,{i},'Instrument',{j},'EngUnits',Instrument_data(j).EngUnits);
            HF_Data = setfield(HF_Data,{i},'Instrument',{j},'Stats',Instrument_stats(j));
        end
    end

    for j=1:nSystems   
        if configIn.System(j).ON == 1;

            nInstruments = length(configIn.System(j).Instrument);       % the number of instruments in the current system
            
            % STEP - Create an EngUnits matrix
            [EngUnits,miscVariables,Instrument] = fr_create_system_data(configIn,j,Instrument_data,miscVariables);                
Stats_New = setfield(Stats_New,{i},'MiscVariables',miscVariables);


            % STEP - Prepare System high-freq. data for export if that option is selected 
            if ~isempty(ExportFlag)
                HF_Data = setfield(HF_Data,{i},'System',{j},'EngUnits',EngUnits);
            else
                % or process the System calculations

                % STEP - Select a type of calculation (System.Type)
                switch upper(configIn.System(j).Type)
                    case 'EDDY',
                        tmp = do_eddy_calc(EngUnits,miscVariables,configIn,j,currentDate);
                        Stats_New = setfield(Stats_New,{i},[configIn.System(j).FieldName],tmp);    
Stats_New = setfield(Stats_New,{i},[configIn.System(j).FieldName],{1},'MiscVariables',{1},'Instrument',Instrument);
                        
                        % STEP - Perform extra calculations on System data
                        if isfield(configIn.ExtraCalculations,'SystemLevel');
                           extraCalculations = fr_calc_extraCalculations(configIn,j,'SystemLevel',...
                              Instrument_data, miscVariables, Stats_New);
                           if ~isempty(extraCalculations)
                           %for currentVariable = 1:length(getfield(configIn.ExtraCalculations,{1},'SystemLevel'))   % cycle for each calculation set
                           for currentVariable = 1:length(fieldnames(extraCalculations));
                              extraCalculationsfield = fieldnames(extraCalculations);
                                Stats_New = setfield(Stats_New,{i},...
                                   [configIn.System(j).FieldName],{1},char(extraCalculationsfield(currentVariable)),...
                                    getfield(extraCalculations,{1},char(extraCalculationsfield(currentVariable))));
                           end
                           end   
                        end
                    case 'PROFILE',
                    case 'SOILRESP',
                    case 'USERTYPE',
                    otherwise,
                        error 'Wrong system type!'
                end % switch   
            end
        end % if c.System(i).ON
   end % for i=1:nSystems
   catch
        disp('Error')
   end % Try
   disp(sprintf('%s (%s), (%d/%d), time = %4.2f (s)',datestr(currentDate),FR_DateToFileName(currentDate),i,hhours,(now-t0)*25*60*60));  
end


