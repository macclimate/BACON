function new_calc_and_save(dateRange,SiteFlag)
%mother function which runs eddy flux site computations and saves daily mat files with the results, 'Stats'
%eg. new_calc_and_save(datenum(2003,8,1):datenum(2003,8,1),'YF');

%Revisions:  
%Aug 20, 2003 - E. Humphreys:  added local function to process short files using configIn information
tic;
if ~exist('SiteFlag') | isempty(SiteFlag)
    SiteFlag = fr_current_siteid;
end

configIn  = fr_get_init(SiteFlag,dateRange(1));  % get the ini file

for dateIn = floor(dateRange)
    try
        t0 = now;
        [yearX,monthX,dayX ] = datevec(dateIn);

        hhours = 48;
        currentDate = datenum(yearX,monthX,dayX,0,30:30:30*hhours,0);
        Stats  = yf_calc_module_main(currentDate,SiteFlag);
        
        FileName_p      = FR_DateToFileName(dateIn+.2);
        FileName        = [configIn.hhour_path FileName_p(1:6) configIn.hhour_ext];    % File name for the full set of stats
        save(FileName,'Stats');
        
        %use ini file settings to select fields for short mat files
        [Stats] = make_short_files(configIn,Stats);
        %[Stats(:).Configuration] = deal([]);
        
        FileName        = [configIn.hhour_path FileName_p(1:6) 's' configIn.hhour_ext];    % File name for the full set of stats
        save(FileName,'Stats');
        disp(sprintf('Day: %s. Calc time = %d seconds',datestr(dateIn),(now-t0)*24*60*60));
        
     end  % of Try
 end % of for dateIn = 
 
 
 %-----------------------------------------------------------------------------------------------------
 %function to create short files
 function [st] = make_short_files(configIn,st);
 
 for i = 1:length(configIn.Shortfiles.Remove)
    for j = 1:length(configIn.Shortfiles.Remove(i).Fields)
       for k = 1:length(st); 
          try; 
             for m = 1:length(getfield(st(k),char(configIn.Shortfiles.Remove(i).System)));
                st(k) = setfield(st(k),char(configIn.Shortfiles.Remove(i).System),{m},...
                   char(configIn.Shortfiles.Remove(i).Fields(j)),[]); 
             end
          end
       end;
    end
    
    try; if isfield(configIn.Shortfiles.Remove(i),'ProcessData') ...
          & ~isempty(configIn.Shortfiles.Remove(i).ProcessData)
       for l=1:length(configIn.Shortfiles.Remove(i).ProcessData)
          eval(char(configIn.Shortfiles.Remove(i).ProcessData(l)));
       end
    end; end
 end
 toc