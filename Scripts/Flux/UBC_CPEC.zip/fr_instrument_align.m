function Instrument_data = fr_instrument_align(configIn,systemNum,Instrument_data)

%Revisions:  
%May 24, 2003 - Allow slaveChan to equal 1
%July 7, 2003 - Allow more than two instruments to be aligned and output alignment info with 
%                Instrument_data structure
%Aug 5, 2003  - Allow System level to determine instrument channels to use to align traces (priority) otherwise use Instrument level info

nInstruments = length(configIn.System(systemNum).Instrument);               % number of instruments in the system

chanNum = [];

% Get settings for instruments 
for i = 1:nInstruments
   currentInstrument = configIn.System(systemNum).Instrument(i);                      % cycle for each instrument in the system
   try,  
      chanNum(currentInstrument) = configIn.System(systemNum).Alignment.ChanNum(i); 
      Inst2align(currentInstrument) = currentInstrument;
   catch
      try,
         chanNum(currentInstrument) = configIn.Instrument(currentInstrument).Alignment.ChanNum; 
         Inst2align(currentInstrument) = currentInstrument;
      end      
   end;
end

if isempty(chanNum); return; end; %leave function if there are no instruments to align

cut             = find(chanNum == 0);
chanNum(cut)    = [];
Inst2align(cut) = [];

% Align instruments 
for i = 1:length(Inst2align);
   data_in(i).EngUnits = Instrument_data(Inst2align(i)).EngUnits;
end

[data_out, N, del_1, del_2] = fr_align(data_in, chanNum, 5000, [-60 60]);

for i = 1:length(Inst2align);
   Instrument_data(Inst2align(i)).EngUnits = data_out(i).EngUnits;
   Instrument_data(Inst2align(i)).Alignment(systemNum).del1 = del_1(i);
   Instrument_data(Inst2align(i)).Alignment(systemNum).del2 = del_2(i);   
   Instrument_data(Inst2align(i)).Alignment(systemNum).master = configIn.Instrument(Inst2align(1)).Name;      
   Instrument_data(Inst2align(i)).Alignment(systemNum).masterChan = ...
      configIn.Instrument(Inst2align(1)).ChanNames(configIn.Instrument(Inst2align(1)).Alignment.ChanNum);      
end

