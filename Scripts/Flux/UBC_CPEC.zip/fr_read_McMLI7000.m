function [x,dummy] = fr_read_McMLI7000(dateIn,configIn,instrumentNum)
% x = readLI7000(fileName) - function that reads LI7000 data (set to 6 columns)
%
% Inputs:
%   fileName    -   full file name (path and everything)
% Outputs:
%   x           -   a matrix of 6 columns 
%
%
% (c) Zoran Nesic           File created:   May 25, 2002
%                           Last revision:  Oct 22, 2002

% Revisions
%
% Oct 22, 2002
%   - made the original file (readLI700.m) compatible with UBC new_eddy (file name needed
%     to be modified).

% Constants
Rd = 287.04;  % J/K/kg
gamad = 1.4;

pth = configIn.path;
dateStr = FR_DateToFileName(dateIn);
fileName = ['LI' dateStr(1:8) '.bin'];
fullFileName = fullfile(pth,fileName);
if exist(fullFileName)~= 2
     pth = [pth fileName(1:6) '\'];
     fullFileName = fullfile(pth,fileName);
     if exist(fullFileName)~= 2
         fullFileName = [];
     end
 end

% Read data
[junk x1 x2 x3 x4 x5 x6]= textread(fullFileName,'%s %f %f %f %f %f %f \n');
% Correct if the first line is incomplete
if x6(1)==0
    offsetStart = 2;
else
    offsetStart = 1;
end
% Correct if the last line is incomplete
offsetEnd = length(x6);

x1 = x1(offsetStart:offsetEnd);
x2 = x2(offsetStart:offsetEnd);
x3 = x3(offsetStart:offsetEnd);
x4 = x4(offsetStart:offsetEnd);
x5 = x5(offsetStart:offsetEnd);
x6 = x6(offsetStart:offsetEnd);

% Sonic Virtual Temperature (deg C)
x5 = ((x5.^2)/(gamad*Rd)) - 273.15;


x = [x1 x2 x3 x4 x5 x6];

x = resample(x,36000,36620);

dummy = [];
