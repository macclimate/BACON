function [spikes,data] = fr_calc_spikes(data,c)
% fr_calc_spikes.m Program which tallies number of spikes for all data
%
%    data = input matrix
%    c    = configuration file
%
%    spikes = no. of spikes within each data trace
%    data   = output matrix of despiked data (if selected)

%    E.Humphreys  23.03.01
%    Revisions:   Jun 20, 2001 - config_info change
%    Oct - Kai added removal of spikes to data output in this function
%    Oct 12, 2002 - Elyn added ini file requirement to output despiked data (if c.Spikes.despike.ON does
%           not exist, output variable data is the despiked data)            

%fig = 0;

N = size(data);
N = min(N);
t = [1:1:length(data(:,1))];
data_out = data;

for i = 1:N;
   [spike_inds] = fr_pick_spikes(data(:,i),c.Spikes.spike_av,...
      c.Spikes.bp_vect,c.Spikes.spike_limit,c.Spikes.spike_thold(i));
   spikes(i)    = length(spike_inds);
   
   %   try,
   %      fig = fig+1;figure(fig);clf;
   %      plot(t,data(:,i),t(spike_inds),data(spike_inds,i),'o')
   %   end
   if ~isempty(spike_inds)
      ind = find(spike_inds > 1 & spike_inds < length(data));
      data_out(spike_inds(ind),i) = (data(spike_inds(ind)-1,i) + data(spike_inds(ind)+1,i))./2;
      if spike_inds(1) == 1 
         data_out(1,i) = data(2,i);
      end
      if spike_inds(end) == length(data)
         data_out(end,i) = data(end-1,i);
      end
   end
   
   clear spike_inds;
end

%output despiked data if ini file selects it
if isfield(c.Spikes.despike, 'ON')
    if c.Spikes.despike.ON == 1
        data = data_out;
    end
else
    data = data_out; %allow despiked data to pass through if ini file does not mention it (historical reasons)
end

