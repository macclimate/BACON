function InstrumentStats = fr_calc_instrument_stats(Instrument_data, configIn)
%
%
%
%
% (c) Zoran Nesic           File created:       Jun 27, 2002
%                           Last modification:  Jun 27, 2002

% Revisions
% Mar 31,2003 - deals with halfhours where sensor info is missing


    nInstrument = length(configIn.Instrument);
    InstrumentStats(nInstrument).Name = [];
    InstrumentStats(nInstrument).Type = [];
    InstrumentStats(nInstrument).SerNum = [];
    InstrumentStats(nInstrument).ChanNames = [];
    InstrumentStats(nInstrument).ChanUnits = [];
    InstrumentStats(nInstrument).Avg = [];
    InstrumentStats(nInstrument).Min = [];
    InstrumentStats(nInstrument).Max = [];
    InstrumentStats(nInstrument).Std = [];
    InstrumentStats(nInstrument).MiscVariables.NumOfSamples = [];
    for i=1:nInstrument
        InstrumentStats(i).Name = configIn.Instrument(i).Name;
        InstrumentStats(i).Type = configIn.Instrument(i).Type;
        InstrumentStats(i).SerNum = configIn.Instrument(i).SerNum;
        InstrumentStats(i).ChanNames = configIn.Instrument(i).ChanNames;
        InstrumentStats(i).ChanUnits = configIn.Instrument(i).ChanUnits;
        InstrumentStats(i).Avg = mean(Instrument_data(i).EngUnits);
        InstrumentStats(i).Min = min(Instrument_data(i).EngUnits);
        InstrumentStats(i).Max = max(Instrument_data(i).EngUnits);
        InstrumentStats(i).Std = std(Instrument_data(i).EngUnits);
        InstrumentStats(i).MiscVariables.NumOfSamples = length(Instrument_data(i).EngUnits);
        if ismember(upper(InstrumentStats(i).Type),[{'CSAT3','GILLR2','GILLR3'}])
			 try %added this Mar 31,2003 - deals with halfhours where sensor info is missing
           InstrumentStats(i).MiscVariables.CupWindSpeed3D = sqrt(sum(InstrumentStats(i).Avg(1:3).^2));
           InstrumentStats(i).MiscVariables.CupWindSpeed = sqrt(sum(InstrumentStats(i).Avg(1:2).^2));
           InstrumentStats(i).MiscVariables.WindDirection = fr_sonic_wind_direction(InstrumentStats(i).Avg(1:2)',InstrumentStats(i).Type);
           end
        end
    end % for 
    
