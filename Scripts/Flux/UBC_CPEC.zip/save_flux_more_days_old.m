function save_flux_more_days(dateRange,SiteFlag)

% Extract, save and plot fluxes for whole year
% (script assumes that there is a structure Stats in the workspace)

% Example: save_flux_more_days(datenum(2002,09,01):datenum(2002,09,30),'mcm')
%
% Altaf Arain, Dec 15, 2002
%

%day      = [31 28  31  30  31  30  31  31  30  31  30  31];
month    = [0 31 59  90 120 151 181 212 243 273 304 334 365];


NN = 365*48;

Fc = NaN * zeros(NN,1);
LE = NaN * zeros(NN,1);
H  = NaN * zeros(NN,1);
DelaysX = NaN * zeros(NN,2);

if ~exist('SiteFlag') | isempty(SiteFlag)
    SiteFlag = fr_current_siteid;
end
configIn  = fr_get_init(SiteFlag,dateRange(1))  % get the ini file

for dateIn = floor(dateRange)
%    try
        t0 = now;
        [yearX,monthX,dayX ] = datevec(dateIn)

        %hhours = 48
        %currentDate = datenum(yearX,monthX,dayX,0,30:30:30*hhours,0)
        FileName_p      = FR_DateToFileName(dateIn+.2)
        FileName        = [configIn.hhour_path FileName_p(1:6) configIn.hhour_ext]    % File name for the full set of stats
       
        load(FileName)
       
FileNameLE      = ['c:\met-data\daily\' FileName_p(1:2) 'LE.McM.mat' ]    % File name for the full set of stats
FileNameHs      = ['c:\met-data\daily\' FileName_p(1:2) 'Hs.McM.mat' ]    % File name for the full set of stats
FileNameHtc1    = ['c:\met-data\daily\' FileName_p(1:2) 'Htc1.McM.mat' ]    % File name for the full set of stats
FileNameHtc2    = ['c:\met-data\daily\' FileName_p(1:2) 'Htc2.McM.mat' ]    % File name for the full set of stats
FileNameFc      = ['c:\met-data\daily\' FileName_p(1:2) 'Fc.McM.mat' ]    % File name for the full set of stats
FileNameBrLicor = ['c:\met-data\daily\' FileName_p(1:2) 'BrLicor.McM.mat' ]    % File name for the full set of stats
FileNameWUE     = ['c:\met-data\daily\' FileName_p(1:2) 'WUE.McM.mat' ]    % File name for the full set of stats
FileNameUstr    = ['c:\met-data\daily\' FileName_p(1:2) 'ustr.McM.mat' ]    % File name for the full set of stats
FileNamePenergy = ['c:\met-data\daily\' FileName_p(1:2) 'Penergy.McM.mat' ]    % File name for the full set of stats
FileNameHRcoef  = ['c:\met-data\daily\' FileName_p(1:2) 'HRcoef.McM.mat' ]    % File name for the full set of stats
FileNameDelaysX = ['c:\met-data\daily\' FileName_p(1:2) 'DelaysX.McM.mat' ]    % File name for the full set of stats

N = length(Stats);

k=1;
for i=1:N,
    try 
        LE(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=2;
for i=1:N,
    try 
        H(i + ((dayX-1)*N) + (month(monthX)*N) )= Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=3;
for i=1:N,
    try 
        Htc1(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;



k=4;
for i=1:N,
    try 
        Htc2(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=5;
for i=1:N,
    try 
        Fc(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
        
    end;
end;

k=7;
for i=1:N,
    try 
        BrLicor(i + ((dayX-1)*N) + (month(monthX)*N) )= Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=8;
for i=1:N,
    try 
        WUE(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=9;
for i=1:N,
    try 
        Ustr(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=10;
for i=1:N,
    try 
        Penergy(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;

k=11;
for i=1:N,
    try 
        HRcoef(i + ((dayX-1)*N) + (month(monthX)*N) ) = Stats(i).MainEddy.Fluxes.AvgDtr.AfterRot(k);
    end;
end;
%%%%%%%%%%%%%%%%%%%%%
k=2;
for i=1:N,
    try 
        DelaysX((i + ((dayX-1)*N) + (month(monthX)*N)),:) = Stats(i).MainEddy.Delays.Calculated;
    end;
end;

end % of for dateIn loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 


%%%%%%%%%% Initial data cleaning %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ----- Fco2 in umol/m2/s --------
ind = find(abs(Fc) > 35);  
Fc(ind) 	= NaN * ones(size(ind));
Fc(ind)  = 0.5*(Fc(ind+1)+Fc(ind-1));
% Fc_mg = Fc*44/1000;%convert unit umol m-2 s-1 to mg m-2 s-1

%%%% H and LE in W/m2 %%%%%%%%%%%%%%%%
% --- pick out unreasonable value ---
ind 			= find(H > 800 | H < -200);  
H(ind) 	= NaN * ones(size(ind));
H(ind)  = 0.5*(H(ind+1) + H(ind-1));

 ind 			= find(Htc1 > 800 | Htc1 < -200);  
 Htc1(ind) 	= NaN * ones(size(ind));
 Htc1(ind)  = 0.5*(Htc1(ind+1) + Htc1(ind-1));
 
 ind 			= find(Htc1 > 800 | Htc1 < -200);  
 Htc1(ind) 	= NaN * ones(size(ind));
 Htc1(ind)  = 0.5*(Htc1(ind+1) + Htc1(ind-1));


% --- pick out unreasonable value ---

ind 			= find(LE > 800 | LE < -200);  
LE(ind) 	= NaN * ones(size(ind));
LE(ind)  = 0.5*(LE(ind+1)+LE(ind-1));

% --- despike by visula inspection ---

ind 			= [  ];
LE(ind) 	= NaN*ones(length(ind),1);
LE(ind)  = 0.5*(LE(ind+1)+LE(ind-1));

% ---- get rid of point according energy balance
ind = [ ]; 
LE(ind) = NaN*ones(length(ind),1);
LE(ind) 	= (LE(ind-1) + LE(ind+1))./2;

% ----- pick out unreasonable according to stdw
ind			= [ ];
LE(ind)  = NaN*ones(length(ind),1);
LE(ind) 	= (LE(ind-1) + LE(ind+1))./2;

%%%%%%% Save data as time series %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% save(FileName,'Stats');

%save(FileNameLE, 'LE')        
%save(FileNameHs,  'H')
%save(FileNameHtc1, 'Htc1')
%save(FileNameHtc2, 'Htc2')
%save(FileNameFc, 'Fc')
%save(FileNameBrLicor, 'BrLicor')
%save(FileNameWUE, 'WUE')
%save(FileNameUstr, 'Ustr')
%save(FileNamePenergy, 'Penergy')
%save(FileNameHRcoef, 'HRcoef')
%save(FileNameDelaysX, 'DelaysX')

%%%%%%%%%%% Plot Files for Visula Inspection %%%%%%%%%%%%%%%%%%%%%%%
figure(1);plot([H LE],'-o')
figure(2);plot([Fc],'o-')
figure(3);plot([DelaysX])
figure(4);plot([Htc1 Htc2],'-o')
figure(5);plot([BrLicor],'-o')
figure(6);plot([WUE],'-o')
figure(7);plot([Ustr],'-o')
figure(8);plot([Penergy],'-o')