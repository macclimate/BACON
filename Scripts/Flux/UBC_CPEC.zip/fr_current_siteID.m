function siteID = fr_current_siteID()
%
% (c) Zoran Nesic           File created:       Mar 13, 1998
%                           Last modification:  Mar 13, 1998
%

%
% Revisions:
%

siteID = 'McM';
