function [c_hat, y_hat, y_pred, stats, sigma, err, exitflag, num_iter] = ...
    fitresp(coeff_0, funName, Xin, Yin, X_eval, stdev_in, options)
%% fitresp.m
%%% This function is the master function for estimating parameters for a
%%% variety of different possible RE-partitioning algorithms. 
%%% usage: [c_hat, y_hat, y_pred, stats, sigma, err, exitflag, num_iter] =
%%% fitresp(coeff_0, funName, Xin, Yin, X_eval, stdev_in, options)
%%% OUTPUTS:
%%% c_hat = best estimates for coefficients
%%% y_hat = estimated values for Y (RE), evaluated from Xin, where only certain points have been included for parameterization 
%%% y_pred = estimated values for Y (RE), evaluated from X_eval, which is usually an annual or longer continuous timeseries
%%% stats = structure with statistics (RMSE, MAE, BE, R2, etc)
%%% err = final value of objective function at end of minimization
%%% exitflag = flag to indicate convergence (1), or non-convergence (0, -1)
%%% num_iter = number of iterations needed to reach convergence
%%% INPUTS:
%%% coeff_0 = starting estimates for coefficient values
%%% fun_Name = string name of function to be used (e.g.'fitresp2A' is logistic function with Ts only)
%%% Xin: input X data for parameterization (i.e. X data when you have
%%%    acceptable RE data).  Depending in the function you are using, Xin may
%%%    be a column vector (e.g. Xin = Ts;), or a matrix, with separate variables as
%%%    columns (e.g. Xin = [Ts SM];)
%%% Yin: input raw RE data for parameterization (good RE data)
%%% X_eval: annual or longer timeseries of continuous X values -- used to
%%%     make timeseries of predicted RE. Similar to Xin, X_eval may be a single
%%%     column or a matrix with as many columns as needed env. variables.
%%% stdev_in: standard deviation estimates (weights) corresponding with Yin
%%%     values (can use [] to indicate no use of stdev)
%%% options: allows the user to change the details of the minimization.
%%%%% options.costfun specifies the cost function to be used (e.g. Sum of
%%%%%   Squares ('OLS'), Weighted Sum of Squares ('WSS'), or 
%%%%%   Mean Absolute Weighted Error ('MAWE')
%%%%%   If nothing is specified, then the default is set as OLS.  ** Note
%%%%%   that to use WSS or MAWE, you must have non-zero standard deviations
%%%%%   applied for each measurement.
%%%%% options.min_method specifies the minimization method.  Default is
%%%%%   Nelder-Mead Simplex ('NM', fminsearch function).  Also available is
%%%%%   Levenberg-Marquardt ('LM'), and Simmulated Annealing ('SA').
%%%%% options.f_coeff lets you fix specified parameter values, while letting others be optimized.
%%%%%   Default is no fixed coefficients. 
%%% SAMPLE USAGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Example 1: Using the Nelder-Mead minimization approach (fminsearch), with
% Original Least Squares (same as Sum of Squares, 'OLS) cost function, and
% no fixed coefficients (normal use).
%%% options.costfun ='OLS'; options.min_method ='NM'; 
%%% [c_hat, y_hat, y_pred, stats, sigma, err, exitflag, num_iter] =
%%% fitresp(coeff_0, funName, Xin, Yin, X_eval, [], options)
%%% *** Note here that we don't have to specify options.f_coeff is we don't
%%% want to fix any coefficients (we're letting the function determine all
%%% the best fits).  Also, we can enter stdev as [], since we don't need it
%%% when using OLS.
% Example 2: Using the Nelder-Mead minimization approach (fminsearch), with
% Weighted Sum of Squares cost function, and 1 fixed coefficient.  We're
% using the Q10 + SM function for this example ('fitresp_3B'), which has 4
% parameters to be fit.  We want to fix the 3rd parameter at 8.
%%% options.costfun ='OLS'; options.min_method ='NM'; 
%%% options.f_coeff = [NaN NaN 8 NaN];
%%% [c_hat, y_hat, y_pred, stats, sigma, err, exitflag, num_iter] =
%%% fitresp(coeff_0, 'fitresp_3B', Xin, Yin, X_eval, stdev_in, options)
%%% *** Note here that we need to have stdev be actual numbers, since we're
%%% using WSS.  In options.f_coeff, we only give a number to the
%%% coefficient we want to fix, and leave the rest as NaNs.



if isfield(options, 'costfun')
costfun = options.costfun;
else
    costfun = 'OLS'
end

if isfield(options, 'min_method')
min_method = options.min_method;
else
    min_method = 'NM'
end

if isfield(options, 'f_coeff')==1;
    fixed_coeff_tmp = options.f_coeff;
    coeffs_to_fix_tmp = find(~isnan(fixed_coeff_tmp));
    coeff_0_tmp = [];
    for k = 1:1:length(coeff_0)
    if ~isempty(find(k == coeffs_to_fix_tmp))
    else
        coeff_0_tmp = [coeff_0_tmp coeff_0(k)];
    end
    end
    clear coeff_0;
    coeff_0 = coeff_0_tmp;
    clear coeff_0_tmp
else
    coeffs_to_fix_tmp = [];
    fixed_coeff_tmp = [];
end

if nargin < 7;
    min_method = 'NM';
    disp('found less than the 7 possible input arguments.');
    disp('Please check the function to make sure you have all arguments');
    disp('Assuming that all arguments are entered correctly except for options');
    disp('Using Nelder-Mead Approach and original least-squares');
        costfun = 'OLS'
    min_method = 'NM'

    %     disp('only found 5 input parameters -- assuming you included X_eval, but not stdev');
    %     disp('In future use, make sure you include X_eval, and set stdev = [].');
end

stats = struct;
global X Y stdev objfun fixed_coeff coeffs_to_fix;
X = Xin;
Y = Yin;
stdev = stdev_in;
objfun = costfun;
fixed_coeff = fixed_coeff_tmp;
coeffs_to_fix = coeffs_to_fix_tmp;
%% Run the minimization:
if strcmp(min_method,'LM')==1
    alg_in = {'levenberg-marquardt',.005};
    [c_hat err resid exitflag output] = lsqnonlin(funName,coeff_0, [],[], optimset('Algorithm', alg_in, 'MaxFunEvals', 10000,'MaxIter',10000, 'TolX',1e-10, 'TolFun', 1e-10));
elseif strcmp(min_method,'GN')==1
    %     alg_in = ['''LargeScale''',off, LevenbergMarquardt, off'];
    [c_hat err resid exitflag output] = lsqnonlin(funName,coeff_0,[],[], optimset('LargeScale','off','LevenBergMarquardt', 'off','MaxFunEvals', 10000,'MaxIter',10000, 'TolX',1e-10, 'TolFun', 1e-10));
elseif strcmp(min_method,'TRR')==1
    [c_hat err resid exitflag output] = lsqnonlin(funName,coeff_0,[],[],optimset('MaxFunEvals', 10000,'MaxIter',10000, 'TolX',1e-10, 'TolFun', 1e-10));
elseif strcmp(min_method,'SA')==1
    eval (['fun_to_use = @' funName ';']);
    [c_hat,err,exitflag,output] = simulannealbnd(fun_to_use,coeff_0);
else % Otherwise, we run the nelder-mead approach (min_method = 'NM'):
    [c_hat, err, exitflag,output] =fminsearch(funName, coeff_0, optimset('MaxFunEvals', 5000,'MaxIter',5000,'TolX',1e-10, 'TolFun', 1e-10));
end
% Record number of iterations needed:
try
    num_iter = output.iterations;
catch
    num_iter = NaN;
end
%% This part evaluates the function using the best-fit coefficients to
%%% get estimates for parameterization data (when Y_in is good), and for
%%% all periods covered by X_eval:

eval(['y_hat = feval(@' funName ',c_hat,X);']); % The predicted values for the selected data points
eval(['y_pred = feval(@' funName ',c_hat,X_eval);']); % The predicted values for all data points

%% Do Stats:
try
    [stats.RMSE stats.rRMSE stats.MAE stats.BE] = model_stats(y_hat, Y, 'off');
    
catch
    disp('calculating stats failed')
    stats.RMSE = NaN; stats.rRMSE = NaN;  stats.MAE = NaN;  stats.BE = NaN;
end

try
    res=sum((y_hat-Y).^2);
    total=sum((Y-mean(Y)).^2);
    stats.R2=1.0-res/total;
    sigma=sqrt(res);
    %     stats.R2 = rsquared(Y, y_out(ind_good_Y));
catch
    disp('calculating R-squared failed')
    stats.R2 = NaN;
end


%%% Put the fixed coefficients back in if necessary:
if ~isempty(coeffs_to_fix_tmp)
    ctr = 1;
  for i = 1:1:length(fixed_coeff)
        if isnan(fixed_coeff(i))
            c_hat_tmp(i) = c_hat(ctr);
            ctr = ctr+1;
        else
            c_hat_tmp(i) = fixed_coeff(i);
        end
        
  end
  c_hat = c_hat_tmp;
end
clear fixed_coeff coeffs_to_fix fixed_coeff_tmp coeffs_to_fix_tmp;
%
% switch funName
%     %%% Lloyd and Taylor (A - Ts only, B - Ts+SM)
%     case 'fitresp_1A'
%         y_hat = c_hat(1).*exp( (-1.*c_hat(2)) ./ ( X(:,1)+(273.15-c_hat(3)) ) );
%         y_pred = c_hat(1).*exp( (-1.*c_hat(2)) ./ ( X_eval(:,1)+(273.15-c_hat(3)) ) );
%     case 'fitresp_1B'
%         y_hat = c_hat(:,1).*exp( (-1.*c_hat(2)) ./ ( X(:,1)+(273.15-c_hat(3)) ) ) .* ...
%             1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2)));
%         y_pred = c_hat(:,1).*exp( (-1.*c_hat(2)) ./ ( X_eval(:,1)+(273.15-c_hat(3)) ) ) .* ...
%             1./(1 + exp(c_hat(4)-c_hat(5).*X_eval(:,2)));
%
%         %%% Barr logistic (A - Ts only, B - Ts+SM)
%     case 'fitresp_2A'
%         y_hat = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X(:,1))));
%         y_pred = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X_eval(:,1))));
%     case 'fitresp_2B'
%         y_hat = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X(:,1)))) .* ...
%             1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2)));
%         y_pred = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X_eval(:,1)))) .* ...
%             1./(1 + exp(c_hat(4)-c_hat(5).*X_eval(:,2)));
%
%     case 'fitresp_2C'
%         y_hat = c_hat(1).*(1./(1 + exp(c_hat(2)-c_hat(3).*X(:,1)))).* ...
%     (1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2))));
%         y_pred = c_hat(1).*(1./(1 + exp(c_hat(2)-c_hat(3).*X_eval(:,1)))).* ...
%     (1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2))));
%
%         %%% Q10 (A - Ts only, B - Ts+SM(logi), C - Ts+SM(Carlyle))
%     case 'fitresp_3A'
%         y_hat = c_hat(1).*c_hat(2).^((X(:,1) - 10)./10);
%         y_pred = c_hat(1).*c_hat(2).^((X_eval(:,1) - 10)./10);
%
%     case 'fitresp_3B'
%         y_hat = c_hat(1).*c_hat(2).^((X(:,1) - 10)./10) .* ...
%             1./(1 + exp(c_hat(3)-c_hat(4).*X(:,2)));
%         y_pred = c_hat(1).*c_hat(2).^((X_eval(:,1) - 10)./10) .* ...
%             1./(1 + exp(c_hat(3)-c_hat(4).*X_eval(:,2)));
%
%     case 'fitresp_3C'
%         y_hat = c_hat(1).*c_hat(2).^((X(:,1) - 10)./10) .* ...
%             (X(:,2)./(X(:,2)+c_hat(3))) .* (c_hat(4)./(X(:,2)+c_hat(4)));
%         y_pred = c_hat(1).*c_hat(2).^((X_eval(:,1) - 10)./10) .* ...
%             (X_eval(:,2)./(X_eval(:,2)+c_hat(3))) .* (c_hat(4)./(X_eval(:,2)+c_hat(4)));
%
%     case 'fitresp_3D'
%         y_hat = c_hat(1).*c_hat(2).^((X(:,1) - 10)./10).* (c_hat(3) + c_hat(4).*X(:,2) + c_hat(5)./X(:,2));
%         y_pred = c_hat(1).*c_hat(2).^((X_eval(:,1) - 10)./10).* (c_hat(3) + c_hat(4).*X_eval(:,2) + c_hat(5)./X_eval(:,2));
%
%         %%% Exponential (A - Ts only, B - Ts+SM)
%     case 'fitresp_4A'
%         y_hat = c_hat(1).*exp(c_hat(2)*X(:,1));
%         y_pred = c_hat(1).*exp(c_hat(2)*X_eval(:,1));
%
%     case 'fitresp_4B'
%         y_hat = c_hat(1).*exp(c_hat(2)*X(:,1)) .* ...
%             1./(1 + exp(c_hat(3)-c_hat(4).*X(:,2)));
%         y_pred = c_hat(1).*exp(c_hat(2)*X_eval(:,1)) .* ...
%             1./(1 + exp(c_hat(3)-c_hat(4).*X_eval(:,2)));
%
%         %%% Non-Rectangular Hyperbola:
%     case 'fitresp_6A'
%         y_hat = -1./(2.*c_hat(1)) .* (  c_hat(2).*X(:,3) + c_hat(3) ...
%             - sqrt( (c_hat(2).*X(:,3) + c_hat(3)).^2 - 4.*c_hat(2).*c_hat(3).*c_hat(1).*X(:,3))) +c_hat(4);
%         y_pred = -1./(2.*c_hat(1)) .* (  c_hat(2).*X_eval(:,3) + c_hat(3) ...
%             - sqrt( (c_hat(2).*X_eval(:,3) + c_hat(3)).^2 - 4.*c_hat(2).*c_hat(3).*c_hat(1).*X_eval(:,3))) +c_hat(4);
%
%         %%% Saiz Model:
%     case 'fitresp_7A'
%         y_hat = (c_hat(1).*exp(c_hat(2).*X(:,1))).*(c_hat(3).*X(:,2) + c_hat(4).*X(:,2).^2);
%         y_pred = (c_hat(1).*exp(c_hat(2).*X_eval(:,1))).*(c_hat(3).*X_eval(:,2) + c_hat(4).*X_eval(:,2).^2);
%
% end




% %% R2 (R_squared)
%
%   res=sum((y_hat-Y).^2);
%   total=sum((Y-mean(Y)).^2);
%   R2=1.0-res/total;
%   sigma=sqrt(res);
% end
% function err = fitresp_1A(c_hat,x)
% global X Y stdev;
% y_hat = c_hat(:,1).*exp( c_hat(:,2) ./ ( X(:,1)+(273.15-c_hat(:,3)) ) );
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_1B(c_hat,x)
% global X Y stdev;
% y_hat = c_hat(:,1).*exp( c_hat(:,2) ./ ( X(:,1)+(273.15-c_hat(:,3)) ) ) .* ...
%     1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2)));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_2A(c_hat,x)
% global X Y stdev;
%         y_hat = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X(:,1))));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_2B(c_hat,x)
% global X Y stdev;
%         y_hat = (c_hat(1))./(1 + exp(c_hat(2).*(c_hat(3)-X(:,1)))) .* ...
%              1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2)));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_3A(c_hat,x)
% global X Y stdev;
%          y_hat = c_hat(1).*c_hat(2).^((X(:,1) - c_hat(3))./10);
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_3B(c_hat,x)
% global X Y stdev;
%          y_hat = c_hat(1).*c_hat(2).^((X(:,1) - c_hat(3))./10) .* ...
%              1./(1 + exp(c_hat(4)-c_hat(5).*X(:,2)));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_3C(c_hat,x)
% global X Y stdev;
%          y_hat = c_hat(1).*c_hat(2).^((X(:,1) - c_hat(3))./10) .* ...
%              (X(:,2)./(X(:,2)+c_hat(4))) .* (c_hat(5)./(X(:,2)+c_hat(5)));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_4A(c_hat,x)
% global X Y stdev;
%         y_hat = c_hat(1).*exp(c_hat(2)*X(:,1));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_4B(c_hat,x)
% global X Y stdev;
%         y_hat = c_hat(1).*exp(c_hat(2)*X(:,1)) .* ...
%              1./(1 + exp(c_hat(3)-c_hat(4).*X(:,2)));
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_6A(c_hat,x)
% global X Y stdev;
%         y_hat = -1./(2.*c_hat(1)) .* (  c_hat(2).*X(:,3) + c_hat(3) ...
%             - sqrt( (c_hat(2).*X(:,3) + c_hat(3)).^2 - 4.*c_hat(2).*c_hat(3).*c_hat(1).*X(:,3))) +c_hat(4);
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
%
% function err = fitresp_7A(c_hat,x)
% global X Y stdev;
%          y_hat = (c_hat(1).*exp(c_hat(2).*X(:,1))).*(c_hat(3).*X(:,2) + c_hat(4).*X(:,2).^2);
% if isempty(stdev)==1; err = sum((y_hat - Y).^2); else err = (1./length(X)) .* ( sum(abs(y_hat - Y)./stdev)); end
% end
