function [Ustar_th f_out] = mcm_Ustar_th_JJB(data, plot_flag,window_mode)

if nargin == 1
    plot_flag = 1;
    window_mode = 'biweekly';
elseif nargin == 2
    window_mode = 'biweekly';    
end

if isempty(window_mode)==1
    window_mode = 'biweekly';
end

switch window_mode
    case 'seas' 
        win_size = 90*48;
        centres(:,1) = (45*48:win_size:17520);
        
%         seasons = [1 3; 4 6; 7 9; 10 12]; % Starting and ending months for seasons
    case 'monthly'
%         seasons = (1:1:12)';
        win_size = 30*48;
        centres(:,1) = (15*48:win_size:17520);

    case 'biweekly'
        win_size = 16*48;
        centres(:,1) = (10*48:win_size:17520);
        
end

if isfield(data,'year_start')==1
year_start = data.year_start;
year_end = data.year_end;
else
    year_start = min(data.Year);
    year_end = max(data.Year);
    disp('No field for year_start and year_end.');
    disp(['Using year_start = ' num2str(year_start) ', and year_end = ' num2str(year_end)]);
end
Ustar_th = NaN.*ones(length(data.Year),1);

%% Part 1: Establish the appropriate u* threshold:
%%% 1 Reichstein, 2005 approach, but calculated for different intervals:
ctr = 1;
data.recnum = NaN.*ones(length(data.PAR),1);
% win_size = 16*48;
% centres(:,1) = (10*48:16*48:17520);
for year = year_start:1:year_end
    data.recnum(data.Year == year) = 1:1:yr_length(year,30);
    dt_ctr = 1;
    for dt_centres = 1:1:length(centres)%:win_size:yr_length(year,30,0)%seas = 1:1:4
        
        ind_bot = max(1,centres(dt_centres)-win_size);
        ind_top = min(centres(dt_centres)+win_size,yr_length(year,30,0));
        ind = find(data.Year == year & data.recnum >= ind_bot & data.recnum <= ind_top);
        [u_th_est biweek_u_th(dt_ctr,ctr)] = Reichsten_uth(data.NEE(ind), data.Ts5(ind), data.Ustar(ind), data.RE_flag(ind));
        dt_ctr = dt_ctr+1;
    end
    ctr = ctr+1;
end

%%% Average for each data window over all years (using median or mean):
Ustar_th_all = nanmedian(biweek_u_th,2);
Ustar_th_all2 = nanmean(biweek_u_th,2);
ctr = 1;
L = '';
for year = year_start:1:year_end
%%% interpolate between points:
% step 1: interpolate out to the ends:
use_pts = (1:1:(yr_length(year,30)-centres(end))+(centres(1)))';
ust_fill = [Ustar_th_all2(end); Ustar_th_all2(1)];
x = [1; use_pts(end)];
ust_interp = interp1(x,ust_fill,use_pts);
centres_tmp = [1; centres; yr_length(year,30)];
Ustar_th_all_tmp = [ust_interp(yr_length(year,30)-centres(end)+1); Ustar_th_all2; ust_interp(yr_length(year,30)-centres(end))];
Ustar_th_interp = interp1(centres_tmp,Ustar_th_all_tmp,(1:1:yr_length(year,30))');
Ustar_th(data.Year == year,1) = Ustar_th_interp;
ctr = ctr+1;
clear centres_tmp Ustar_th_all_tmp Ustar_th_interp ust_interp x ust_fill use_pts;
L = [L '''' num2str(year) '''' ','];
end
L = [L '''' 'Median' '''' ',' '''' 'Mean' ''''];

if plot_flag == 1
    clrs = jjb_get_plot_colors;
   f_out = figure(1);clf; 
   for k = 1:1:ctr-1
       h1(k) = plot(centres,biweek_u_th(:,k),'.-','Color',clrs(k,:));hold on;
   end
   h1(k+1) = plot(centres,Ustar_th_all,'-','LineWidth',5,'Color',[0.5 0.5 0.5]); hold on;
   h1(k+2) = plot(centres,Ustar_th_all2,'-','LineWidth',5,'Color',[1 0 0.5]); hold on;
   eval(['legend(h1,' L ')']);
%    legend(h1,'2003','2004','2005','2006','2007','2008','2009','Median','Mean')
   ylabel('u^{*}', 'FontSize',16)
   set(gca, 'FontSize',14);
%    print('-dpdf',[fig_path 'u*_th']);
% close all;
end