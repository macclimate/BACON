% function [sums] = mcm_SiteSpec_Gapfill(site, year_start, year_end, Ustar_th)
site = 'TP39';
year_start = 2003;
year_end = 2009;
Ustar_th = 0.325;
%% mcm_FCRN_Gapfill.m
%%% This function fills NEE data using the prefered Site-Specific protocols,
%%% using a scaled logistic RE-Ts function (scaled by SM),
%%% and a scaled Michaelis-Menten (scaled by Ta, Ts, )
%%% GEP-PAR function.
%%% Depending on the site and the years of interest, a time-varying parameter
%%% may be applied (if flux data is continuous).
%%% Created in its current form by JJB, March 8, 2010.
%%% usage: mcm_SiteSpec_Gapfill(site, year_start, year_end, Ustar_th)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Revision History
%
%
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%

%% Rules for site-specific filling:

%%% Method A: Continuous datasets:
% TP39: [all years], TP74 [2008--2009], TP02 [2009]
%%% variables: all available
%%% parameterization: single-year
%%% fixed SM relationship?:  yes - if necessary.

%%% Method B: Non-Continuous datasets:
% TP89: [2003--2007], TP74 [2003--2007], TP02 [2003--2008]
%%% variables: all available
%%% parameterization: all-year
%%% fixed SM relationship?:  yes.

close all;

%% Make the model flexible to different amount of input information
%%% Set Ustar threshold (if empty)
if nargin == 3 || isempty(Ustar_th)
    Ustar_th = input('Enter u* threshold: ');
end

%%% Set Ustar threshold and years (if empty)
if nargin == 1
    Ustar_th = input('Enter u* threshold: ');
    year_start = input('Enter start year: ');
    year_end = input('Enter end year: ');
end

%%% Set years (if empty)
if isempty(year_start)
    year_start = input('Enter start year: ');
end
if isempty(year_end)
    year_end = input('Enter end year: ');
end

%% Pre-defined variables, mostly for plotting:
test_Ts = (-10:2:26)';
test_PAR = (0:200:2400)';
clrs = [1 0 0; 0.5 0 0; 0 1 0; 0.8 0.5 0.7; 0 0 1; 0.2 0.1 0.1; ...
    1 1 0; 0.4 0.5 0.1; 1 0 1; 0.9 0.9 0.4; 0 1 1; 0.4 0.8 0.1];
test_VPD = (0:0.2:3)';
test_SM = (0.0:0.005:0.25)';

global SM_coeff;
global GEP_scalar_coeff;
%% Paths:
ls = addpath_loadstart;
load_path = [ls 'Matlab/Data/Master_Files/' site '/'];
save_path = [ls 'Matlab/Data/Flux/CPEC/' site '/Final_Calculated/'];

%% Load gapfilling file and make appropriate adjustments:
load([load_path site '_gapfill_data_in.mat']);

%%% Calculate VPD from RH and Ta:
data.VPD = VPD_calc(data.RH, data.Ta);
data.VPD(data.VPD< 0) = 0;
%%% Make a single SM index from a and b pits - use Pit A first, since at
%%% all sites it is the more dependable pit:
SM(1:length(data.SM_a),1) = NaN;
SM(isnan(SM),1) = data.SM_a(isnan(SM),1);
SM(isnan(SM),1) = data.SM_b(isnan(SM),1);
data.SM = SM; clear SM;

%%% Estimate std associated with each measurement of NEE:
data.NEEstd = NEE_random_error_estimator(data, [], Ustar_th);
close all;

%%% trim data to fit with the years selected:
data = trim_data_files(data,year_start, year_end);

%% Site- and Year-specific fixes to the data:

%%% For TP02 in 2008, incorporate the OPEC data:
switch site
    case 'TP02'
        try
            ind = find(data.Year == 2008);
            if ~isempty(ind)
                data.NEE(data.Year == 2008 & isnan(data.NEE) & data.dt < 190) = data.NEE_OPEC(data.Year == 2008 & isnan(data.NEE) & data.dt < 190);
                data.Ustar(data.Year == 2008 & isnan(data.Ustar) & data.dt < 190) = data.Ustar_OPEC(data.Year == 2008 & isnan(data.Ustar) & data.dt < 190);
            end
        catch
        end
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% Part 1: Respiration %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
resp_day_constraints = [0 367];
%%%% Method 2: Group data together for all years for parameterization:
[RE_model2 Rraw RE_rw_model2 RE_coeff_model2] = ...
    Ts_SM_RE_logistic(data, data.SM_a, data.NEEstd,Ustar_th, 'all', resp_day_constraints);
% Save the coefficients for all-years SM response:

SM_coeff = RE_coeff_model2(1,4:5)';

%%%% Method 1: Run for individual years, but with a fixed SM response:
ctr = 1;
for year = year_start:1:year_end
    ind_param =find(data.Year == year & data.Ustar >= Ustar_th & ~isnan(data.Ts5) ...
        & ~isnan(data.NEE) & data.PAR < 20 & data.NEE > -5 & data.Ts5 >= -5  & ~isnan(data.SM)  & ~isnan(data.NEEstd) ...
        & data.dt >resp_day_constraints(1) & data.dt < resp_day_constraints(2));
    [RE_coeff_model1(ctr,:),junk1,junk2,junk3] = fitmain([10 .3 10], 'fit_RE_Ts_fixed_SM', [data.Ts5(ind_param,1) data.SM(ind_param,1)], data.NEE(ind_param,1),data.NEEstd(ind_param,1));
    RE_model1(data.Year==year,1)=((RE_coeff_model1(ctr,1))./(1 + exp(RE_coeff_model1(ctr,2).*(RE_coeff_model1(ctr,3)-data.Ts5(data.Year==year))))) ...
        .* (1./(1 + exp(SM_coeff(1)-SM_coeff(2).*data.SM(data.Year==year))));
    ctr = ctr+1;
    clear ind_param junk*
end

%%%% Still need to run the Ts-RE relationship to fill holes in the above
%%%% models (for times when we don't have SM data):
[RE_Ts_model1 junk1 junk2 RE_Ts_model1_coeff] = Ts_RE_logistic(data, data.SM, data.NEEstd, [], Ustar_th, 'single', 'off', resp_day_constraints,[]);
[RE_Ts_model2 junk3 junk4 RE_Ts_model2_coeff] = Ts_RE_logistic(data, data.SM, data.NEEstd, [], Ustar_th, 'all', 'off', resp_day_constraints,[]);
clear junk*

%%%% Fill blanks in model1 and model2 with RE-Ts predictions:
RE_model1(isnan(RE_model1),1) = RE_Ts_model1(isnan(RE_model1),1);% This is the indiv-years parameterization
RE_model2(isnan(RE_model2),1) = RE_Ts_model2(isnan(RE_model2),1);% This is the all-years parameterization


%%% Calculate Time-varying-parameters:
rw_model1 = jjb_AB_gapfill(RE_model1, Rraw, [],200, 10, 'off', [], [], 'rw');% This is the indiv-years parameterization
rw_model2 = jjb_AB_gapfill(RE_model2, Rraw, [],200, 10, 'off', [], [], 'rw');% This is the all-years parameterization

%%% Adjust modeled RE by TVP:
RE_tvp_adj1 = RE_model1.*rw_model1(:,2); % This is the indiv-years parameterization
RE_tvp_adj2 = RE_model2.*rw_model2(:,2);% This is the all-years parameterization

%%% Plot the relationships for RE-Ts for each year:
figure('Name', 'Annual RE vs Ts,SM');clf;
ctr = 1;
for year = year_start:1:year_end
    test_Ts_y1 =    (RE_coeff_model1(ctr,1))./(1 + exp(RE_coeff_model1(ctr,2).*(RE_coeff_model1(ctr,3)-test_Ts)));
    test_Ts_y2 =    (RE_coeff_model2(1,1))./(1 + exp(RE_coeff_model2(1,2).*(RE_coeff_model2(1,3)-test_Ts)));
    subplot(1,2,1);
    h1(ctr,1) = plot(test_Ts, test_Ts_y1,'-','Color', clrs(ctr,:)); hold on;
    plot(test_Ts, test_Ts_y2,'-','Color', [0.5 0.5 0.5],'LineWidth',3);
    title('Re-Ts')
    ctr = ctr+1;
end
legend(h1,num2str((year_start:1:year_end)'));
%%% Plot the RE-SM relationship:
subplot(1,2,2);
test_SM_y1 = (1./(1 + exp(SM_coeff(1)-SM_coeff(2).*test_SM)));
plot(test_SM, test_SM_y1,'-','Color','k','LineWidth',3)
title('Re-SM')

%%% Plot estimates with raw data:
figure('Name','RE - raw vs. modeled');clf;
plot(Rraw,'k');hold on; plot(RE_model1,'b'); plot(RE_model2,'r');
legend('raw','model1','model2');
figure('Name','RE - raw, modeled, adjusted - model1');clf;
plot(Rraw,'k');hold on; plot(RE_model1,'b'); plot(RE_tvp_adj1,'r');
legend('raw','model1','tvp-adj1');
figure('Name','RE - raw, modeled, adjusted - model2');clf;
plot(Rraw,'k');hold on; plot(RE_model2,'b'); plot(RE_tvp_adj2,'r');
legend('raw','model2','tvp-adj2');
figure('Name','RE - raw vs adjusted');clf;
plot(Rraw,'k');hold on; plot(RE_tvp_adj1,'b'); plot(RE_tvp_adj2,'r')
legend('raw','tvp-adj1','tvp-adj2');

%%% Calculate stats for each:
[RE_stats(1,1) RE_stats(1,2) RE_stats(1,3) RE_stats(1,4)] = model_stats(RE_model1, Rraw,'off');
[RE_stats(2,1) RE_stats(2,2) RE_stats(2,3) RE_stats(2,4)] = model_stats(RE_model2, Rraw,'off');
[RE_stats(3,1) RE_stats(3,2) RE_stats(3,3) RE_stats(3,4)] = model_stats(RE_tvp_adj1, Rraw,'off');
[RE_stats(4,1) RE_stats(4,2) RE_stats(4,3) RE_stats(4,4)] = model_stats(RE_tvp_adj2, Rraw,'off');


%%% display stats on screen:
disp('Stats for Each RE Model:');
disp('RMSE    |    rRMSE     |     MAE     |       BE ');
disp(['modeled-indiv:      ' num2str(RE_stats(1,:))]);
disp(['modeled-all:      ' num2str(RE_stats(2,:))]);
disp(['tvp-adjusted-indiv: ' num2str(RE_stats(3,:))]);
disp(['tvp-adjusted-all: ' num2str(RE_stats(4,:))]);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% PHOTOSYNTHESIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Two types of GEP will be created:
%%% GEPraw(:,1) - RE(indiv-years) - NEE;
%%% GEPraw(:,2) - RE(all-years) - NEE;
%%% We'll run each of 3 methods for both input RE data -- this will result
%%% in 6 separate GEP estimates.


GEPraw = [RE_tvp_adj1 - data.NEE RE_tvp_adj2 - data.NEE]; % GEPraw is 2 columns
GEPraw(data.PAR < 15) = NaN;
GEP_model = NaN.*ones(length(GEPraw),2);

%%% This is not ideal, but at some points we have gaps in SM data that
%%% leads to gaps in the estimated GEP.  So, for such situations, we'll
%%% make SM = 0.1, which should effectively remove any negative influence
%%% from SM.  What else can you do?
data.SM_filled = data.SM;
data.SM_filled(isnan(data.SM_filled),1) = 0.1;

%% Loop through both RE estimates, and make corresponding GEP estimates
%%% using each estimate:
for RE_ctr = 1:1:2
    switch RE_ctr
        case 1; RE_in = RE_tvp_adj1;
        case 2; RE_in = RE_tvp_adj2;
    end

    %% Run the parameterization for all years, then we'll save the scalar
    %%% parameters to run indiv years, fixed scalars:
    GEP_day_constraints = [0 367];
    Ustar_th_GEP = 0.1;
    [GEP_model3(:,RE_ctr) junk1 junk2 GEP_coeff_model3(ctr,:)] = ...
        PAR_Ta_Ts_VPD_SM_GEPmodel(TP39.data, RE_in, TP39.data.SM, ...
        TP39.data.NEEstd, Ustar_th_GEP, 'all', GEP_day_constraints);
    clear junk*
    %%% Coefficients for scalars for all-years:
    GEP_scalar_coeff = GEP_coeff_model3(ctr,3:10)'; %SM coeffs are 9:10
    GEP_SM_coeff = GEP_coeff_model3(ctr,9:10)';

    %% Run parameterization for individual-years, using fixed scalars
    ctr = 1;
    for year = year_start:1:year_end
        %%% index for useable data - right now, we are setting 0.1 as a
        %%% daytime-threshold, to avoid very calm early-morning and early night
        %%% conditions:
        ind_GEP_param = find(data.PAR > 20 & ~isnan(data.Ts5) & ~isnan(GEPraw) & ...
            data.Ustar > Ustar_th_GEP & data.VPD > 0 & ~isnan(data.VPD) & ~isnan(data.PAR) & ~isnan(data.Ta) & ~isnan(data.SM) ...
            & data.dt >GEP_day_constraints(1) & data.dt < GEP_day_constraints(2) & data.Year == year & ~isnan(data.NEEstd));
        %%% Estimation of parameters and GEP with all scalars fixed
        [GEP_coeff_model2(RE_ctr).out(ctr,:) junk1 junk2 junk3] = fitmain([0.03 25], 'fit_GEP_fixed_scalars', ...
            [data.PAR(ind_GEP_param) data.Ta(ind_GEP_param) data.Ts5(ind_GEP_param) data.VPD(ind_GEP_param) data.SM(ind_GEP_param)], ...
            GEPraw(ind_GEP_param,RE_ctr), data.NEEstd(ind_GEP_param));

        GEP_model2(data.Year == year,RE_ctr) = (GEP_coeff_model2(RE_ctr).out(ctr,1)*GEP_coeff_model2(RE_ctr).out(ctr,2)*data.PAR(data.Year == year)./(GEP_coeff_model2(RE_ctr).out(ctr,1)*data.PAR(data.Year == year) + ...
            GEP_coeff_model2(RE_ctr).out(ctr,2))).* (1./(1 + exp(GEP_coeff_model2(RE_ctr).out(ctr,3)-GEP_coeff_model2(RE_ctr).out(ctr,4).*data.Ta(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model2(RE_ctr).out(ctr,5)-GEP_coeff_model2(RE_ctr).out(ctr,6).*data.Ts5(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model2(RE_ctr).out(ctr,7)-GEP_coeff_model2(RE_ctr).out(ctr,8).*data.VPD(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model2(RE_ctr).out(ctr,9)-GEP_coeff_model2(RE_ctr).out(ctr,10).*data.SM(data.Year == year))));
        %%% Estimation of parameters and GEP with only SM fixed, and all other
        %%% scalars free to vary:
        [GEP_coeff_model1(RE_ctr).out(ctr,:) junk4 junk5 junk6] = fitmain([0.03 25 1.12 0.15 1.4 0.7 -2 -.8], 'fit_GEP_fixed_SM', ...
            [data.PAR(ind_GEP_param) data.Ta(ind_GEP_param) data.Ts5(ind_GEP_param) data.VPD(ind_GEP_param) data.SM(ind_GEP_param)], ...
            GEPraw(ind_GEP_param,RE_ctr), data.NEEstd(ind_GEP_param));

        GEP_model1(data.Year == year,RE_ctr) = (GEP_coeff_model1(RE_ctr).out(ctr,1)*GEP_coeff_model1(RE_ctr).out(ctr,2)*data.PAR(data.Year == year)./(GEP_coeff_model1(RE_ctr).out(ctr,1)*data.PAR(data.Year == year) + ...
            GEP_coeff_model1(RE_ctr).out(ctr,2))).* (1./(1 + exp(GEP_coeff_model1(RE_ctr).out(ctr,3)-GEP_coeff_model1(RE_ctr).out(ctr,4).*data.Ta(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model1(RE_ctr).out(ctr,5)-GEP_coeff_model1(RE_ctr).out(ctr,6).*data.Ts5(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model1(RE_ctr).out(ctr,7)-GEP_coeff_model1(RE_ctr).out(ctr,8).*data.VPD(data.Year == year)))) .* ...
            (1./(1 + exp(GEP_coeff_model1(RE_ctr).out(ctr,9)-GEP_coeff_model1(RE_ctr).out(ctr,10).*data.SM(data.Year == year))));


        clear junk*
        ctr = ctr + 1;
    end
    
%%% Plot the estimates, so that we can get an idea of what the estimates
%%% look like:    
figure('Name', ['GEP estimates for RE model ' num2str(RE_ctr)]);clf;
plot(GEPraw(:,RE_ctr),'r'); hold on;
plot(GEP_model3(:,RE_ctr),'k');
plot(GEP_model2(:,RE_ctr),'b');
plot(GEP_model1(:,RE_ctr),'Color',[0.2 0.56 0.32]);
legend('raw','model3','model2','model1');
end




% 
% %%
% figure('Name','GEP-PAR relationship');clf
% ctr = 1;
% for year = year_start:1:year_end
%     %%% Index of good data to use for model parameterization:
%     ind_param_GEP = find(data.Ts5 > 0.5 & data.Ta > 2 & data.PAR > 20 & ~isnan(GEPraw) & data.Year == year);
%     %%% use M-M function to get coefficients for GEP-PAR relationship:
%     [GEP_coeff(ctr,:) GEP_pred GEP_r2 GEP_sigma] = hypmain1([0.01 10 0.1], 'fit_hyp1', data.PAR(ind_param_GEP), GEPraw(ind_param_GEP));
%     %%% Estimate GEP for the given year:
%     GEP_model(data.Year == year) = GEP_coeff(ctr,1).*data.PAR(data.Year==year,1).*GEP_coeff(ctr,2)./...
%         (GEP_coeff(ctr,1).*data.PAR(data.Year==year,1) + GEP_coeff(ctr,2));
%     %%% GEP relationship for plotting:
%     test_PAR_y = GEP_coeff(ctr,1).*test_PAR.*GEP_coeff(ctr,2)./...
%         (GEP_coeff(ctr,1).*test_PAR + GEP_coeff(ctr,2));
%     %%% Plot relationships:
%     plot(test_PAR, test_PAR_y,'-','Color', clrs(ctr,:)); hold on;
% 
%     clear GEP_pred GEP_r2 GEP_sigma test_PAR_y;
%     ctr = ctr+1;
% end
% legend(num2str((year_start:1:year_end)'));
% 
% %%% Clean up any problems that may exist in the data:
% GEP_model(data.Ts5 < 0.5 | data.PAR < 15) = 0;
% 
% %%% Calculate Time-varying-parameter:
% pw = jjb_AB_gapfill(GEP_model, GEPraw, [],200, 10, 'off', [], [], 'rw');
% %%% Adjust modeled GEP by TVP:
% GEP_tvp_adj = GEP_model.*pw(:,2);
% 
% %%% Plot estimates with raw data:
% figure('Name','GEP - raw vs. modeled');clf;
% plot(GEPraw,'k');hold on;
% plot(GEP_model,'b');
% plot(GEP_tvp_adj,'r')
% legend('raw','model', 'adjusted')
% 
% %%% Calculate stats for each:
% [GEP_stats(1,1) GEP_stats(1,2) GEP_stats(1,3) GEP_stats(1,4)] = model_stats(GEP_model, GEPraw,'off');
% [GEP_stats(2,1) GEP_stats(2,2) GEP_stats(2,3) GEP_stats(2,4)] = model_stats(GEP_tvp_adj, GEPraw,'off');
% %%% display stats on screen:
% disp('Stats for Each GEP Model:');
% disp('RMSE    |    rRMSE     |     MAE     |       BE ');
% disp(['modeled:      ' num2str(GEP_stats(1,:))]);
% disp(['tvp-adjusted: ' num2str(GEP_stats(2,:))]);
% 
% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%  Final Filling & Output  %%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %%% Clean NEE (ustar filtering):
% NEE_raw = data.NEE;
% NEE_clean = NEE_raw;
% NEE_clean(data.PAR < 20 & data.Ustar < Ustar_th,1) = NaN;
% 
% %%% Fill RE - Use raw data when Ustar > threshold; otherwise, use model+tvp
% RE_filled(1:length(Rraw),1) = RE_tvp_adj;
% RE_filled(~isnan(Rraw) & data.Ustar > Ustar_th,1) = Rraw(~isnan(Rraw) & data.Ustar > Ustar_th,1);
% 
% %%% Fill GEP:
% GEP_filled = GEPraw;
% GEP_filled(data.PAR < 15 | data.Ts5 < 0.5 | GEP_filled < 0) = NaN;
% GEP_filled(isnan(GEP_filled),1) = GEP_tvp_adj(isnan(GEP_filled),1);
% 
% %%% Fill NEE:
% NEE_filled = NEE_clean;
% NEE_filled(isnan(NEE_filled),1) = RE_filled(isnan(NEE_filled),1) - GEP_filled(isnan(NEE_filled),1);
% 
% 
% %% The final loop to calculate annual sums and check for holes remaining in data:
% ctr = 1;
% for yr_ctr = year_start:1:year_end
%     holes(ctr,1) = yr_ctr;
%     try
%         %%% Special fix for 2003 -- we lost 8 datapoints due to UTC timeshift:
%         if yr_ctr == 2003;
%             NEE_filled(1:8,1) = NEE_filled(9,1);
%             RE_filled(1:8,1) = RE_filled(9,1);
%             GEP_filled(1:8,1) = GEP_filled(9,1);
%         end
% 
%         NEE_sum(ctr,1) = sum(NEE_filled(data.Year== yr_ctr,1)).*0.0216  ; % sums is annual sum
%         GEP_sum(ctr,1) = sum(GEP_filled(data.Year== yr_ctr,1)).*0.0216  ;
%         RE_sum(ctr,1) = sum(RE_filled(data.Year== yr_ctr,1)).*0.0216  ;
%         holes(ctr,2:4) = [length(find(isnan(NEE_filled(data.Year == yr_ctr,1)))) ...
%             length(find(isnan(RE_filled(data.Year == yr_ctr,1)))) ...
%             length(find(isnan(GEP_filled(data.Year == yr_ctr,1))))] ;
%     catch
%         disp(['something went wrong calculating sums, year: ' num2str(yr_ctr)]);
%         NEE_sum(ctr,1) = NaN;
%         GEP_sum(ctr,1) =  NaN;
%         RE_sum(ctr,1) =  NaN;
%         holes(ctr,1:3) = NaN;
%     end
% 
%     ctr = ctr+1;
% end
% 
% sums = [holes(:,1) NEE_sum(:,1) RE_sum(:,1) GEP_sum(:,1)];
% disp('Number of NaNs outstanding in data: Year | NEE | RE | GEP ');
% disp(holes);
% disp('Annual Totals: Year | NEE | RE | GEP ');
% disp(sums)
% 
% %% Compile data and save:
% master.data.Year = data.Year(:,1);
% master.data.NEE_raw = NEE_raw(:,1);
% master.data.NEE_clean = NEE_clean(:,1);
% master.data.NEE_filled = NEE_filled(:,1);
% master.data.GEP_filled = GEP_filled(:,1);
% master.data.RE_filled = RE_filled(:,1);
% 
% master.data.RE_model = RE_tvp_adj;
% master.data.GEP_model = GEP_tvp_adj;
% master.data.sums = sums;
% 
% save([save_path site '_FCRN_GapFilled_' num2str(year_start) '_' num2str(year_end) '_ust_th = ' num2str(Ustar_th) '.mat'],'master');
% disp('done!');
