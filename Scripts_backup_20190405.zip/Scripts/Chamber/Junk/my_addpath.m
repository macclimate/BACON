function[] = my_addpath

%addpath C:\HOME\Matlab_data\ -end;
%addpath C:\HOME\Matlab_scripts\ -end;
addpath C:\Documents and Settings\Geo McMaster\My Documents\matlab class\ -end;
path
datestr(now)

%cd C:\HOME\Matlab_scripts\
cd C:\Documents and Settings\Geo McMaster\My Documents\matlab class