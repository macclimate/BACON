%this script has been designed to load and plot the chamber data as scatter
%plots
%designed Feb 17, 2009

chamber_data = dlmread('C:\DATA\chamber_data\hhour_all3updated.csv');
