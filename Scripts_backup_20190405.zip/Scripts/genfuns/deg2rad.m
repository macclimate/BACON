function [rads] = deg2rad(degs)
rads = degs.*pi()./180;
