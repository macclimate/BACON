function [HH mm] = HHmm_to_HH_mm(HHmm)

HH = floor(HHmm./100);

mm = HHmm - HH.*100;
