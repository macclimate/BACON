function [] = auto_test()

diary('/1/fielddata/Matlab/test.txt');
disp('hello, I am trying');
4+4

diary off
% matlab -r auto_test -nodesktop -nosplash
