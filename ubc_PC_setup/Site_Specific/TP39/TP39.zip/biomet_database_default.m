function pthDatabase = biomet_database_default()
     pthDatabase = 'd:\met-data\Database';
